# Ocean Delivery Agent 工程团队准备包

2026-10-10，基线 `8e9a7cc`。已有浏览器地图原型和 Flutter 架构；Flutter 工程、原生运行、性能和发布尚未完成。本次只交付工程 skills、分工和后续任务准备，未开发产品、构建或发布 GitHub issues。

团队由一个主控按阶段调度职能 Agent，用任务合同、依赖、文件责任和真实证据推进。职能不等于永久占一个 Agent；不另外开发多 Agent 平台。

## 职能与能力

| 职能 | Skill | 处理 | 能力 / 输出边界 |
| --- | --- | --- | --- |
| 主控 | [agent-engineering-team](../../.agents/skills/agent-engineering-team/SKILL.md) | 新建 | 拆分、派发、集成、修复和状态恢复；不自签全部验收 |
| Harness 工程 | [harness-engineering](../../.agents/skills/harness-engineering/SKILL.md) | 新建 | 执行环境、机械边界、观察反馈、门禁、恢复和评测；不代签业务验收 |
| 需求提取 | [engineering-requirements-extract](../../.agents/skills/engineering-requirements-extract/SKILL.md) | 新建 | 可追溯需求 ID 和合同；不扩展产品 |
| 提 Issue | [engineering-issue-authoring](../../.agents/skills/engineering-issue-authoring/SKILL.md) | 新建 | 粒度、依赖、验收和关闭证据；不实现功能 |
| Flutter 开发 | `flutter-app-workflow` | 复用已安装 | 模型→数据→状态→UI 的业务链及必要回归 |
| Flutter 测试 | `flutter-testing`，必要时 `dart-add-unit-test` / `flutter-add-widget-test` | 复用已安装 | 测试替身、风险覆盖、故障回归；不改低验收要求 |
| 格式/分析 | `flutter-quality-gate` | 复用已安装 | 可复现宿主检查，不替代设备运行 |
| 平台构建 | `flutter-build-verify` | 复用已安装 | debug APK / simulator app 和 hash，不是正式发布 |
| 原生验收 | [flutter-native-acceptance](../../.agents/skills/flutter-native-acceptance/SKILL.md) | 新建 | 用户流程、真实进程恢复、设备证据与缺陷 |
| Flutter 性能 | [flutter-performance](../../.agents/skills/flutter-performance/SKILL.md) | 新建 | 真机 profile、启动/帧/内存、可复现基线 |
| 提交与交付 | [engineering-release-handoff](../../.agents/skills/engineering-release-handoff/SKILL.md) | 新建 | 门槛、产物/签名、升级恢复、目的地回执 |

需求提取确定行为，提 Issue 将合同转为工作单。开发者写必要测试；测试职能独立补风险；验收看用户流程；性能看硬件预算。各自输出不能互相冒充。

通用开发/架构 skill 不覆盖本项目已选的轻量 MVVM、构造函数注入和纯 Dart 模型；不因示例强加 Freezed、DI 框架或领域层。`flutter-app-workflow` 列出的未安装 specialist 不算已具备能力。

七个新通用 skills 保存在仓库 `.agents/skills/`，逐文件安装一致性见 [安装清单](installed-skill-manifest.json)。项目事实放在此包，不绑定通用 skill 到工作树或私人邮件。新会话重新发现安装技能；当前会话可直接读取路径，不假称目录自动刷新。

## 调度与启动

```mermaid
flowchart LR
  R[需求提取] --> I[Issue/任务合同]
  I --> C[主控:接口/依赖]
  C --> X[Harness:环境/机械门禁/恢复]
  X --> D
  X --> T
  C --> D[Flutter 开发]
  C --> T[测试与故障回归]
  D --> Q[集成/质量 gate]
  T --> Q
  Q --> A[原生验收]
  Q --> P[真机性能]
  A --> H[提交与交付]
  P --> H
  X --> H
  A -->|缺陷| D
  P -->|trace 支持的修复| D
```

四个 slot 默认主控＋两名工作 Agent＋一名测试/审查 Agent。需求完成后岗位转开发，设备可用后转验收/性能。共享配置和同设备操作串行，接口未冻结的工作不强行并行。

准备模式的岗位只做准备任务：P01 资料提取/职能盘点，P02 Issue 草稿/任务合同，P03 独立行为试跑/结构验证。`backlog.yaml` 的 E00–E10 与 X00–X04 是未来实施图，当前全部 planned，不把它们派成业务执行任务。

当前准备模式提示词：

```text
使用 $agent-engineering-team，读取 docs/agent-team，核对原型与架构。
只更新技能能力、职责、任务图和本地 issue 草稿，不写产品代码或向外发布。
```

后续实施提示词：

```text
使用 $agent-engineering-team，按 docs/agent-team/mission.md 推进 Flutter 客户端。
核对环境和契约，按 backlog.yaml 调度开发、测试、验收和性能 Agent。
自主完成范围内实现、修复、集成和本地交付，保留各门槛原始证据。
不扩展功能，不将 fake 称为真实上传。外部发布依本次明确授权的目的地执行。
```

它们是后续调用示例，本轮没有启动实现。Skill 不提供常驻进程/自动唤醒，恢复靠任务记录与下一次实际运行。无协作工具时顺序执行职能，明示缺少独立 Agent 评审。

## 任务包

- [mission.md](mission.md)：来源、17 条行为/工程合同、数据/transport 配置。
- [backlog.yaml](backlog.yaml)：16 个可派发任务、依赖和文件责任。
- [harness-audit.md](harness-audit.md)：八项能力差距、当前生产 no-go；准备完成不解锁上线。
- [issue-drafts.md](issue-drafts.md)：重点环节草稿与关闭标准，没有真实 GitHub 编号。
- [decisions.md](decisions.md)：已确认、工程默认和外部依赖。
- [skill-validation.md](skill-validation.md)：实际 skill 验证和行为试跑记录。
- [preparation-manifest.json](preparation-manifest.json)：本次未提交准备文件的来源版本和 SHA-256 指纹；不是产品候选。

生产质量按 G0–G6 积累证据；商业联网还依赖真实服务/权限/适用数据与地图条件，不以演示通过代签。此准备包可交另一名主控继续，不能证明 Flutter 已实现或已上线。
