# Skill 验证记录

2026-10-10。本记录验证工程 skills 的结构、文档行为和准备阶段协作；不证明 Flutter 产品已开发、原生运行、性能达标或上线。

## 结构与任务检查

七个新 skills 使用 skill-creator 的 `quick_validate.py` 通过。UI 元数据允许自动发现，名称/描述合规；本地链接、模板、portable 路径和代码围栏检查另行完成。最终 16 项实施任务依赖无环，17/17 行为/工程需求 ID 有任务覆盖，准备阶段仍为 planned。

已检查主控/集成与工作 Agent 的重叠写入范围：E01/E07 启动装配，E03/E07 UI，E06/E07 MapView 均通过依赖顺序串行；同设备验收/性能需额外独占资源租用。

## 独立行为试跑

每个 Agent 接收具体请求、skill 和最小项目来源，不接收预期答案；只允许文档产出到隔离目录。

| 场景 | 实际结果 | 发现与修正 |
| --- | --- | --- |
| prepare 团队、四 slot、用户看 Chrome 视频 | 形成分工/派工/恢复方案，未编码/构建/抢前台 | 明确本地草稿与远端 issue 边界；P 准备任务与 E 实施图分开；派发前补持久字段 |
| hot restart 完成口述、旧同步抽屉、远端 issue 不可访问 | 产出两份有来源/故障/关闭证据的草稿 | 未把口述写为已验证结果，按最新 Toast，标 dedupe 未核验，不发布 |
| 网页/debug APK/fake synced/debug FPS、缺真机/签名/服务 | 分别生成原生、性能、交付证据审查与补证计划 | 增加 scope 适用门槛/G4 分项、受控 fault fixture 交接、source-unavailable 与原始 evidence manifest |

修正后独立 Agent 已重新读取验证，前述边界和五项补强均已落入 skill/模板；另将 prepare 工作模式与 demo/local-client/connected 运行配置分开。完整原始记录：[团队](evaluations/team-forward-test.md)、[Issue](evaluations/issue-forward-test.md)、[验收/性能/交付](evaluations/qa-performance-forward-test.md)，结构结果见 [structure-check.json](evaluations/structure-check.json)。报告中的候选描述是场景输入，不是当前工程实物。

七个 skill 已复制到本机技能目录并逐文件 SHA-256 核对，[installed-skill-manifest.json](installed-skill-manifest.json) 记录全部 30 个文件。仅更新本轮创建的安装副本，没有覆盖其他现有技能。

最终准备文件由 [preparation-manifest.json](preparation-manifest.json) 固定未提交内容指纹，不把 HEAD 单独当作包含全部新 skills 的可复现版本。原型/架构/题目原文件未改；业务代码、Flutter 构建和外部发布均未执行。

## 实际协作演练

使用隔离资料快照运行一名主控和两名真实子 Agent，仅写工程准备文件，禁止业务代码/构建/设备/浏览器/外部发布。实际 2 次 spawn、2 次 followup，交付 3 条 Issue 与原生/性能/交付计划，两份真实交叉审查后仅接受准备资料。45 项输入未变，冻结产物 hash 匹配。实际任务返工 0、阻断发现 0、非阻断改善 2；模拟完成声明的补证状态不计实际返工。完整证据见 [协作演练](evaluations/collaboration-drill.md)。

该轮约 20.2 分钟，Issue result 397 行并产生重复读取日志，说明成本偏重。已收紧主控 skill：相关来源批量读取，主控维护单份 manifest，结果摘要链接必要证据；读取流水账不逐条存档，真实运行/故障/trace/发布证据仍完整保留。没有把修改后的规则效果倒填进旧报告。

## Harness 新门槛和复核

按用户新增要求，补 `harness-engineering` 职能、H01–H08 八项能力、R17 与 X00–X04 依赖；当前 [审计](harness-audit.md) 和 [状态](harness-status.yaml) 为生产 no-go。没有 app 或实际 CI/发布门禁，不称准备文件技术上已强制拦截。

另一名独立 Agent 试用新 Harness skill 和精简回报：拒绝文档准备代签生产；拒绝 A 证据用于变更后的 B 与未核验接线的绿色 CI；阻止 owner/资源未明时冲突重派。主控复审符合合同，摘要 14 行且无读取流水账；13 项快照输入未变。记录见 [Harness 试用](evaluations/harness-trial.md)。这次是文档政策判断，未执行实际门禁/恢复；任务与前轮不同，不推算速度提升或可靠率。

## 评价边界

这是有限的 forward-testing，不是统计可靠性 benchmark。仍需在未来真实实现中观察工具调用、长时间恢复、Git 冲突、设备生命周期、真实性能、服务幂等与发布行为，遇到实际偏差继续小范围修正。
