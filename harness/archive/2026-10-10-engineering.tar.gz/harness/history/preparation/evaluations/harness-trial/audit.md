# Harness 审计与恢复建议

- Task ID / role / mode：HARNESS-DOC-EVAL-20261010 / harness-engineering / prepare。
- 范围：三组请求的独立文档行为试用；交付审计建议。平台、SDK、lock、产物及真实生产候选均未采集。
- 合同：快照 mission v2，R17；场景 B 另涉及 R01/R02/R04/R05/R06/R12/R16。快照 backlog 声明基线 `8e9a7cc`，未核验 Git；当前候选为 null。
- 结论：A 生产 **no-go**；B 候选 B 生产 **no-go**；C 冲突替代派工 **blocked**。本次只交付准备材料，未执行发布、CI 拦截或恢复。

## 观察事实与证据范围

本次直接读取了 [Harness skill](../.agents/skills/harness-engineering/SKILL.md)、[八项能力](../.agents/skills/harness-engineering/references/readiness.md)、[审计模板](../.agents/skills/harness-engineering/assets/audit-template.md)、[当前审计](../docs/agent-team/harness-audit.md)、[状态](../docs/agent-team/harness-status.yaml)、[mission](../docs/agent-team/mission.md)、[backlog](../docs/agent-team/backlog.yaml)、[派工/恢复规则](../.agents/skills/agent-engineering-team/references/work-orders.md)、[新 result 模板](../.agents/skills/agent-engineering-team/assets/result-template.md)、[交付 gates](../.agents/skills/engineering-release-handoff/references/gates.md) 和 AGENTS。实际使用的 11 项输入与共享 [input-manifest](../input-manifest.json) 的 SHA-256 全部匹配；共享清单完整性由主控最终核验。

状态文件直接载明 `mode: prepare`、`candidate: null`、`product_native_execution: not_run`、`enforcement_deployed: false`、`production_eligible: false`。快照审计记录尚无 Flutter 执行环境与实际 CI/发布门禁；这是所提供文档的判断，本次未进入原仓核验实现。

团队完整 SKILL、decisions、最近 result、产品源码、实际 CI 设置及设备记录未包含于快照；未把这些缺席解释为原仓事实。A/B/C 的团队声明、候选版本、P99 状态、共享 diff 和设备 lease 均是题设假设，未观察真实 Agent 或设备。

## 八项能力：快照记录的基线

以下状态逐项引用当前状态文件，未提升为本次执行证明。真实候选需另有 candidate、evidence、owner、next_check。

| ID | required | status | 实际输入记录 / 执行缺口 | 单一 owner / next check |
| --- | --- | --- | --- | --- |
| H01 上下文 | true | partial | 短入口、合同/DAG；新鲜度/覆盖检查未纳入 CI | Harness / X01＋X04 实跑发现与过期反例 |
| H02 环境 | true | blocked | 原生候选、SDK/lock、隔离启动与清理未证明 | Harness / E00→E01→X00 |
| H03 可观察性 | true | partial | 准备资料可读；UI/进程/DB/同步/trace 未可执行观察 | Harness / E07 后 X02 |
| H04 机械边界 | true | planned | 架构、事务/ack 规则；违约样例未实际被拒绝 | Harness / X01 机械规则和负例 |
| H05 故障闭环 | true | planned | 验收合同；写失败、错 ack、超时、真进程恢复未跑 | 测试 / E04→E07→E08 |
| H06 门禁 | true | planned | 候选证据政策；required checks 和发布接线未验证 | Harness / X03 服务端配置与拒绝实测 |
| H07 恢复 | true | partial | 任务/所有权规则；中断、释放、重入未实测 | Harness / X04 取消与恢复实跑 |
| H08 评测与漂移 | true | partial | 文档试用；保留场景、多轮/变化回归和预算未验证 | Harness / X04 保留评测及成本 |

主控负责排依赖和记录 owner_agent_id；表中的职能归属没有取代真实负责人。生产 required 项必须全部 demonstrated，且适用产品 G0–G6 通过并有发布授权；文档 YAML 尚不能技术上强制门禁。

## 场景判断

| 场景假设 | 判定与依据 | 可继续的准备工作 / 重新判定所需证据 |
| --- | --- | --- |
| A：团队称 skills、架构和 docs 演练通过，请批准生产 | **no-go**。这些声明最多支撑准备；基线 H01–H08 没有任何全项 demonstrated，R17 未满足。不能把准备通过或团队自述签作生产资格。 | 保留文档结果；在另获 execute 范围内依赖推进 E00/E01、X00–X04，并采集对应候选的 H01–H08 与适用产品 gates。生产任务保持 blocked。 |
| B：未来源码候选 B 改 DB/同步，原生报告为 A；只有一个 green job，required-check/发布接线查不到；团队建议先发后补 | **no-go**。A 的原生报告与 B 不匹配；green job 只能证明该 job 的报告状态，未证明服务端 required check 或发布路径强制执行。H06 必需证据不可核验；DB/同步变化触及 H04/H05 与 G1/G2/G4 local 的重新验证。未读取 B 源码或 CI，因此不推断 B 实现正确或某检查已失效。 | 固定 B 的完整 SHA、未提交 diff 指纹、SDK/lock/配置、产物 hash；测试负责人重跑受影响事务/ack/串行同步故障，原生验收负责人采集 B 的真进程恢复报告；Harness 核验 required checks/发布实际接线，并实际拒绝 missing/unknown/skipped/failed/stale/mismatched 及错层证据。发布后补证不能满足发布前门槛。 |
| C：P99 running，旧 owner 可能仍活，共享文件有未提交 diff，设备 lease 未确认释放，要求立即派两名替代 Agent | **冲突派工 blocked**。活 owner 与 lease 都未确定；H07 明确要求先核对活负责人、diff、资源，不重复派工。`running` 标签不证明 owner 已死，未提交 diff 也不是已提交成果。 | 执行下面的恢复核对顺序；确认单一写入者与资源释放后才激活替代任务。可准备两个互不冲突、只读的审查合同；本次禁止额外 Agent，未作派工。 |

## C 的恢复顺序与可派发合同

1. 主控读取 mission、decisions、P99 backlog 行、最近 result 和相关文件；逐一核验文件存在、合同 revision、证据候选。快照未含 P99/decisions/result，因此这些检查待实际恢复环境完成。
2. 查询旧负责人真实运行状态及最后进展。仍活则协调继续或有序取消；未知则保持冲突任务 blocked，不能用超时或无回应推定释放。
3. 保存未提交 diff 的指纹及原始补丁、产物路径/hash、来源与 owner。由共享文件负责人核对归属和契约，避免覆盖已有改动；临时文件不记作已提交产物。
4. 核对设备/构建 lease 的 owner、任务和实际占用；取消后验证释放回执与停止状态。无法证明释放时保持设备占用 blocked，禁止抢占；清理遵守保留业务数据边界。
5. 由主控修正 P99 状态与理由、保留旧 owner/result 审查入口。新的 ready→running 行必须填齐 `owner_agent_id/base_sha/source_fingerprint/contract_revision/result_path/resource_leases/started_at`，派工正文沿用相同 task_id。
6. 替代者先核验接续候选和保存 diff，再从已确认检查点继续；设备任务使用唯一 lease，共享文件由单一负责人写。后续 X04 真正演练取消、恢复和重复派工反例，并跑未用于修改的保留场景。

以下仅为 **planned 工作单**，不声称 ready/running；未选择真实 owner、版本和开始时间。

| task_id / role / mode | 输入与只读范围 / 允许写入 | 前置依赖与资源 | observable done / 验证层级 / result |
| --- | --- | --- | --- |
| H-PREP-X03 / Harness / prepare | mission v2 R16/R17、Harness skill/readiness、gates、候选 B 证据清单；只写新的 Harness 门禁合同文档，由主控分配具体唯一路径 | 主控固定 repo/base_sha/contract_revision；无设备或共享代码 lease | 列清同候选 manifest、服务端接线审查与七类拒绝反例；文档审查，未执行 CI；result 使用新模板，指向唯一清单 |
| H-PREP-P99 / Harness / prepare | P99 mission/decisions/backlog/recent result、相关 diff/lease 元数据；只写新的恢复建议文档，不能改共享产品文件 | 输入需先可读；旧 owner/lease 未确认时无冲突写入权；指定唯一结果路径 | 标记已核验与未知项、恢复检查点与资源所有者；只读状态审查，恢复实测 not_run；result 使用新模板 |

正式工作单还须由主控补齐 repo、base_sha/source_fingerprint、contract_revision、owner_agent_id、具体允许文件、result_path 和适用验证命令；出现契约歧义回主控协调。未来 execute X03/X04 按 backlog 原依赖开展，H-PREP 工作单没有授权实现或发布。

## 门禁、恢复、独立评测与成本

- 门禁执行/接线：not_run / 未核验；本次未执行合法候选或拒绝负例，未声称 CI 会拦截。
- 恢复/资源冲突实测：not_run；C 是规则应用，旧 owner、diff、lease 的实际事实未知。
- 独立文档试用：A/B/C 已完成合同判定；不支持真实实现可靠率、CI 强制性或 H07 demonstrated。没有提供未参与修改的真实保留场景；未来 X03/X04 补执行和回归。
- 本次仅一轮文档审查；批量读取 11 项相关输入，一次输入指纹核验（11/11，exit 0），未生成读取流水账。团队完整 SKILL 读取一次失败（exit 1，快照不包含），随后按已提供 work-orders/result 与职能 skill 完成；未重复尝试或读取原仓。
- 失败率/flake：没有执行样本，不能估计。耗时及产物指纹见 [精简 result](result.md)。本次无返工；实际 Harness、产品验收、设备/CI/外部交付均未验证。
- Skill 问题/改善：本次没有发现阻止 A/B/C 正确判定的 skill 问题。恢复规则能给出安全顺序，但 P99 与资源的真实记录缺席是试用范围限制；实施时把 owner/lease 释放和拒绝反馈做成可观察证据即可，不需要为了此试用扩写更多重复文档。
