# 实际 Agent 协作演练证据

2026-10-10，隔离快照、只交准备文档。一名主控和两名工作 Agent，实际 2 次 spawn、2 次 followup；交叉审查真实发生，准备资料接受。3 条 Issue 和原生/性能/交付计划落盘，45 项输入未变。无阻断发现、实际任务返工 0；模拟完成声明退回补证不计实际返工。

本轮耗时约 20.2 分钟，Issue result 397 行，重复读取日志偏重；随后收紧主控回报格式，未把这轮耗时当改进后的性能。新版独立试用另记。没有产品运行证据，未验证实际恢复、设备、性能或执行 Harness，生产 no-go。

- [主控原始报告](collaboration-drill/drill-report.md)
- [持久任务板](collaboration-drill/task-board.json)
- [独立 Issue 审查](collaboration-drill/reviews/issues-review.md)
- [独立验收／性能／交付审查](collaboration-drill/reviews/gates-review.md)
- [输入完整性核对](collaboration-drill/input-integrity-check.json)
- [完整快照与原始产物/日志](collaboration-drill-bundle.tar.gz)，[存档指纹](collaboration-drill-manifest.json)

原始文件保持字节不变，内部路径以存档中的 `ocean-team-drill-20261010/` 为工作根。快照是六 skill 的 drill-v1，早于主仓合同 v2 与新增 Harness skill，不能假称本轮已测新合同。
