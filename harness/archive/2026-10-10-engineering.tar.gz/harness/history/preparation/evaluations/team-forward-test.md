# agent-engineering-team 独立行为试跑

日期：2026-10-10。场景：Ocean Delivery 已有原型和架构，用户只要求工程 skills 与可自主协作的团队准备；用户正在 Chrome 看视频；可用总计 4 个 slot。本试跑只读仓库，未实际派发、未写业务代码、未构建、未操作浏览器、未向外部写入。唯一新增文件为本报告。

## 读取与版本

- 读取总控 SKILL.md、team-protocol、work-orders、task-board/result 模板，以及需求提取、Issue、交付、原生验收、性能的相关 skill/标准。
- 读取根 AGENTS.md、README、docs/agent-team/README.md、mission.md、backlog.yaml、decisions.md，核验资料列表。
- HEAD：`8e9a7cca9c4360ca07d86e8aa8d196caf88c8c42`；合同 revision=1；backlog source_baseline=`8e9a7cc`。
- 当前仓库为未提交准备变更：README.md 已修改，.agents/、AGENTS.md、docs/agent-team/ 为未跟踪。不能声称仅 HEAD 可复现这套技能与准备资料。实际派发前主控应生成输入/输出文件 hash 清单或保存 patch，并记录当前 source fingerprint；本试跑没有替主控持久化这些文件。
- 核验 `/Users/yeyufeng/.codex/skills/` 下 flutter-app-workflow、flutter-testing、flutter-quality-gate、flutter-build-verify 的 SKILL.md 实际存在；这只是存在性核验，不代表未阅读的所有 specialist 都可用。

## 场景结论

选择 **prepare**。原型和架构不是执行授权，E00–E10 全部为 planned，当前不能派发 E01–E10 开始产品实现，也不能创建真实 GitHub issues。做本地工作单和技能准备无需追加例行确认。

主控占 1 个 slot，最多同时安排 3 个工作 Agent；职能可以换岗，不为每个职能永久创建一名 Agent。本场景可以使用后台终端和文档操作，不需要 Chrome 或 native 前台步骤。保持用户视频、标签、窗口与焦点；后台不可行只阻塞相应交互步骤，不转为前台控制。

当前任务包保留现有 R01–R16：SQLite/outbox 可靠性、地图工作台、直接同步 Toast、按来源返回、真实进程恢复、真机性能和交付门槛。功能只对应已有原型；demo、local-client、connected 证据分开，历史 78/78 网页检查仅是浏览器原型证据。准备结果不构成 Flutter 运行或上线完成。

## 首批准备派工方案（尚未实际派发）

用 P 前缀将本次准备任务与将来的 E 实施任务区分。复核修订后的 README，它将 P01 定义为资料提取/职能盘点，P02 为 Issue 草稿/合同，P03 为独立行为试跑/结构验证。以下按其分类，把 P01 拆成两个互不写入重叠的子项（P01-REQ、P01-CAP），加一个独立 P03；P02 在合同审查后换岗执行。主控稍后在共享 backlog 中补录准备项，只有满足输入、责任与合同要求后标 ready。已有准备包只核查增量，不重新生成相同资料。当前报告只提供可执行派工单，不擅自修改共享状态。

### P01-REQ：核对需求与实施合同

- role/mode：requirements / prepare。
- repo：`/Users/yeyufeng/.codex/worktrees/6519/transvirtual-driver-delivery`。
- base_sha/contract_revision：上述完整 HEAD；revision=1；派发时补 source fingerprint。
- 输入：mission.md、decisions.md、backlog.yaml、根 README、原始 brief/CSV、当前 prototype/README、direct-sync-design、origin-return-design、solution-design。来源仅按需要读取，不浏览私人邮件头。
- 需求：R01–R16。可观察完成条件：每条重点链有来源、触发、可观察结果、失败/恢复、证据层级；最新直接同步/返回规则明确覆盖历史资料；demo/local-client 与后续 connected 不混淆。
- 允许写入：建议 `docs/agent-team/results/P01-REQ.md`；只能输出 delta、冲突和接口责任建议，不直接改 mission/backlog/decisions。共享合同由主控独占写。
- skill：`.agents/skills/engineering-requirements-extract/SKILL.md`。
- 依赖/资源：已有 revision=1 作为待核验输入；不占设备、构建或浏览器资源。没有产品代码写入权限，不安装 SDK/依赖，不编造未来 API 签名。
- 验证：文档逐条 trace 检查；不是 Flutter 行为测试。结果含所读文件版本、合同差异、未决项和 R01–R16 覆盖表。

### P01-CAP：能力与工具就绪检查

- role/mode：engineering-capability-review / prepare。
- repo/base_sha/contract_revision：同 P01-REQ；派发时补 source fingerprint。
- 输入：团队 README、总控与工程 skills、现有 Flutter skills、当前运行环境可用协作工具 schema。
- 需求：R15、R16，以及所有任务的职能/工具映射。可观察完成条件：每岗位只有收敛的职责；输出/越界/替代方式明确；实际存在的技能与缺失 specialist 分开；运行时派发/回报/恢复字段可实现。
- 允许写入：建议 `docs/agent-team/results/P01-CAP.md`；仅读取技能本体，发现问题交主控，不与技能作者同时改同一文件。
- skills：`.agents/skills/agent-engineering-team/SKILL.md`；审核实际存在的被引用 Flutter SKILL.md，不假称未安装 specialist 已加载。
- 依赖/资源：与 P01-REQ 并行，因为它核验能力而非改产品合同；不借设备，不构建、不安装、不向外发布。
- 验证：路径存在、相对链接、职责/授权/证据语义、工具 schema 可达性；能完成结构校验则保留命令/退出码。本试跑只确认前述 4 个复用入口存在，完整能力审查留给实际 P01-CAP。

### P03：独立测试、验收与性能准备

- role/mode：testing-and-gate-review / prepare。
- repo/base_sha/contract_revision：同 P01-REQ；revision=1 为暂定输入，P01-REQ 被接受后复核其 delta。
- 输入：mission R01–R16、decisions、backlog、架构可靠性边界、原生验收/性能/交付标准。
- 需求：重点 R01–R06、R12–R16；同时检查 R07–R11 的 UI/用户链证据。
- 可观察完成条件：正常、事务失败、错配/重复 ack、双击、超时/暂停、真正终止进程后重开均有验证设计；区分 unit/widget/integration、模拟器、真机 profile/release；未定设备/预算被记录为 provisional 或 not_run，不能判通过。
- 允许写入：建议 `docs/agent-team/results/P03-gates.md`，不写 app/test、不跑构建、不改业务需求。
- skills：`/Users/yeyufeng/.codex/skills/flutter-testing/SKILL.md`；对应门槛按需读取 `.agents/skills/flutter-native-acceptance/SKILL.md`、`flutter-performance/SKILL.md`、`engineering-release-handoff/SKILL.md`。
- 依赖/资源：与 P01-REQ/P01-CAP 并行进行 revision=1 的风险审查；最终结论需 P01-REQ delta 复核。没有候选包/设备时只准备方法，不假称已经验收。
- 验证：需求到测试、原生验收和性能证据的矩阵；共享设备/构建串行租用规则；缺设备/真实服务/签名只阻塞对应未来 gate。

### 主控的串行整合与换岗

1. 三项工作收到结构化 result 后进入 review，不按 Agent 口头“完成”接受。
2. 主控审阅每份文件和输入版本；让 P01-CAP 职能审阅 P01-REQ/P03，P03 职能审阅 P01-CAP。任何一个岗位不自签自己的成果。实际阶段若独立审查者不足，明示审查层级，不能伪造独立评审。
3. 主控独占更新 mission、backlog、decisions；确认 revision 与 affected consumers。若 P01-REQ 修改合同，P03 回到 review/rework 复核关联门槛。
4. 释放一个工作 slot 后安排 P02 Issue 草稿整理，依赖 accepted 的 P01-REQ/P03（能力影响由 P01-CAP 解决）。技能为 `.agents/skills/engineering-issue-authoring/SKILL.md`，只写自己的 result/草稿文件；主控合入 issue-drafts.md。Issue 使用本地稳定 E ID，需求 ID/来源/依赖/负责职能/验收/关闭证据完整。无法读取真实仓库 issue 清单时标 `dedupe 未核验`；不凭空写真实 issue 编号、不创建 GitHub issue。
5. 按 engineering-release-handoff 形成准备 manifest：六个新建技能、复用能力、任务图、未定设备/SDK/预算/地图许可/签名/服务条件、后续启动提示词。G1–G6 仍无对应 Flutter 证据；不写“生产级已交付”。

后续收到实现授权时先重新核对版本与环境，从 E00 冻结平台、配置与接口责任；E01 单一负责人锁 SDK/依赖并完成最小启动；E01 accepted 后并行 E02 数据、E03 UI、E04 独立测试。这是未来调度预案，本次不会执行。设备验收 E08 与性能 E09 若共享硬件需串行。复核修订后的 E10：E07 accepted 后可准备文档/manifest；发布级 accepted 仍要 E08/E09 和适用门槛通过，准备文档不等于发布门槛通过。

## 恢复方法

1. 新主控先读 AGENTS、mission、decisions、backlog、最近 result，识别当前用户是 prepare、execute 还是 resume；不得把旧聊天或本实施提示词当新授权。
2. 比对 base SHA、source fingerprint、当前 diff、产物 hash 与文件存在性。当前准备文件未提交，先找出保存的 patch/hash/结果文件，不能仅凭 HEAD 认定同版。
3. 查询当前实际 Agent/任务状态（使用环境真实 collaboration 工具；本试跑没有查询或调用派发）。对 running 任务核实 Agent ID、工作目录、写入范围和租用；活着的唯一写入者继续等候或 followup，不能再派第二个写者。
4. Agent 不存在或状态不能确认：收集其已有 result/diff；有可审证据进 review，证据不足进 rework；无产物保留 planned/ready 并写清中断原因。running 不直接 accepted，不把临时文件当提交产物。
5. 主控确认合同 revision、依赖 accepted 和共享文件所有权后重新派发。所有租用失联先确认设备/构建操作实际已结束，释放后再启动下一位。
6. 集成串行，受影响消费者重新核验；失败按最短复现、实际/预期、环境、证据回开发。两次同路径失败让另一职能检查，第三次无新证据停止该路径并记录解除条件，独立任务继续。
7. 无协作工具时顺序执行同样合同，并明确没有并发或独立 Agent 评审；无 ready 任务时收口，不不断重新规划。

## 实际技能表现与歧义

**表现通过（文档级试跑）**：模式边界清楚；原型/架构不自动启动实现；四 slot 调度、单写入责任和设备串行规则可直接使用；独立验收与 evidence 层级区分可靠；后台共存可让本场景完全不碰 Chrome；恢复要求能避免中断后双写；无需常驻 Agent 平台即可准备团队任务包。

**需澄清但未阻止试跑**：

1. 初读总控步骤 3 的“只有发布已授权时才向仓库写入”字面也可能包括本地仓库文件，与步骤 2 更新任务包、prepare 交付本地草稿冲突。已将发现反馈主控，随后重读已修订 SKILL.md：现在明确本地 issue 草稿与获授权的远端 GitHub 等服务创建/更新；歧义已解决。本试跑没有外部写入。
2. 初读 backlog 全是 E00–E10 实施项，没有 P 准备任务，可能让新 Agent 误以为可派 E01。主控修订后，SKILL.md 明确 prepare 只派资料提取/能力/草稿/行为验证，已有准备包只检查增量；README 已列 P01–P03 并标 E00–E10 为未来实施图。重读验证通过，授权混淆已解决。P 任务仍需要实际主控入共享板并记录状态，本方案遵循当前 README 分类。
3. ready 的定义要求“依赖 accepted”，现有 revision=1 合同尚未见 accepted 记录。本方案把它标为待核验输入，让独立审查并行；最终整合在 P01-REQ accepted 后。如果希望 P03 强制依赖已接受的合同，则 P03 第一波仅做方法/工具审查，合同覆盖延后，不能靠默许跳依赖。
4. 初读 backlog 任务字段有 role/write_scope/done_when，但没有 owner ID、base/source fingerprint、结果路径和资源租用，派发正文与持久板如何关联不够明确。主控随后修订 work-orders.md，本评估者再次只读核验：planned 可暂不指派；真正从 ready 到 running 前必须在该任务行补 owner_agent_id/base_sha/source_fingerprint（未提交输入时）/contract_revision/result_path/resource_leases/started_at，派工正文与行使用同 task_id。修订已解决持久字段与计划 backlog 的关系；模板仍未自动校验，属于使用者执行责任，不是此次准备交付阻断。
5. “release”相关 gates 为文档真实分层，但缺平台/设备时 G0 合同仍未完全冻结。当前只能接受准备交付，不接受 G0–G6 的产品通过状态；这套技能可指导实施，并不能证明 Agent 团队已经实际完成自主开发。

总体：技能足以形成可 review 的首批准备工作、未来依赖调度与恢复方案。试跑发现的两个主要措辞问题已由主控修正，并经本评估者重读验证解决；小项均可由派发初始化完善，不阻断准备交付。本报告没有验证真实派发、原生能力或工程生产结果。

## 最终重读验证追加

本节将本评估者最后回报里的复核结论持久到报告，避免仅在聊天汇报里留下证据。

- 已重读修订后的 agent-engineering-team/SKILL.md 和 docs/agent-team/README.md：本地草稿与远端 Issue 创建/更新的授权边界清楚；prepare 只派准备任务，P01–P03 与未来 E00–E10 明确分开，已有完整包只检查增量。因此最初两项主要歧义均已解决。
- 已重读修订后的 backlog.yaml E10：depends_on 为 E07；可先准备文档/manifest，但发布级 accepted 仍需 E08/E09 和适用门槛，未以文档准备代签产品发布。
- 已重读新 work-orders.md，并同时对照 team-protocol.md、task-board.yaml 和 backlog.yaml：planned 允许暂缺 owner；ready 先满足已接受依赖、可访问输入、合同版本和文件责任；实际推进 running 时必须补齐持久字段并关联同 task_id。现有 E00–E10 全为 planned，未填写运行字段是合法的计划快照，不能解释成可恢复的已执行状态。
- 恢复依据现在能从 backlog 行定位真实 owner、源码/未提交输入、合同、result、资源租用及开始时间，再核验实际存活 Agent 和证据。设备/构建无需租用的纯文档任务也应显式记录空租用列表，不能把省略字段当“已核验无需资源”。
- 未发现新的阻断问题。remaining 限制是规约由主控执行、模板无自动 schema 校验，以及真实协作/设备行为未执行；不把文档级通过提升成运行时或生产工程证明。

只读核验命令包括 cat、rg、shasum，退出码均为 0；没有构建、测试产品、浏览器交互或外部写入。以下是最终核验内容的 SHA-256 快照，便于确认被审版本；未来文件变化必须重新评估相关差异：

```text
99102e6a4384e20f1c6a85569ff3e51201654d02bd888442555f6ad361a4a9ac  .agents/skills/agent-engineering-team/SKILL.md
6c5d5db5f90a767fb0aba23542030e5e141d6e53f4396411577499595125f558  .agents/skills/agent-engineering-team/references/work-orders.md
747d304109128d58eff5469edb023883e7e5726cc9fb24b0ea7e9e76f6cb93f9  docs/agent-team/README.md
31b61cec7744912a4ef1af31c09752c952e66de7504883b44027089dd0708060  docs/agent-team/backlog.yaml
```
