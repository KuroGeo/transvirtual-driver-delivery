# Ocean Delivery 验收、性能、交付 Skill 独立前向试跑

日期：2026-10-10。执行者：qa_perf_skill_eval。模式：只读静态试跑。

## 结论

该候选不能签为“Flutter 原生验收通过”“生产性能通过”或“已发布”。本次实际完成的是三职能的证据审查、测量准备和交付门槛报告，未运行 app、设备、浏览器、构建或发布。

现有三个 skill 能正确挡住网页测试、hot restart、fake synced、模拟器 debug 平均 FPS 和 debug APK 五类证据混用；未发现会导致本场景错误放行的实质矛盾。它们也允许继续本地准备，无需为每项缺口重复请求发布或前台权限。

注意：以下候选描述来自试跑输入。仓库当前 HEAD 为 `8e9a7cca9c4360ca07d86e8aa8d196caf88c8c42`；仓库任务包明确尚无 Flutter 工程。这个 HEAD 不能被填写为假设候选的版本或 APK 的源码身份。候选源码、APK、日志和 trace 未提供，因而构建成功等描述也只能记为 reported/unverified。

## 输入证据登记

| ID | 输入 | 能支持的层级 | 本次可确认程度 / 缺口 |
| --- | --- | --- | --- |
| E1 | 网页 78/78 | 浏览器原型历史行为 | 非 Flutter 证据；未收到对应原始报告/版本 |
| E2 | debug APK | 若核实文件/构建日志，可支持该配置本地构建 | 当前只有描述；缺源码指纹、hash、版本、平台、SDK、依赖、构建与安装日志 |
| E3 | 模拟器 hot restart 流程 | 若核实，可支持部分模拟器调试行为 | 不证明杀进程后从原数据库恢复；缺设备/OS/app ID/原始步骤 |
| E4 | FakeTransport 显示 synced | 受控 demo 的模拟确认 UI | 未证明结果/outbox/确认落盘；不证明真实服务收到客户结果 |
| E5 | 模拟器 debug 平均 60 FPS | 开发定位线索 | 缺版本、刷新率、工作负载、窗口、帧时间与原始 trace；环境不满足正式性能结论 |

## 按 flutter-native-acceptance 填写的验收报告

Candidate SHA / artifact hash / contract revision：候选身份和产物 hash 均 unknown；本次审查用仓库 `docs/agent-team/mission.md` 的 R01–R16 合同，不代表候选已经实现该合同。

Device / OS / Flutter / build mode / app ID / dataset / transport / map source：仅报告“模拟器、debug、fake transport”；其余 unknown。合同首版为 30 条测试数据，但候选实际数据集未确认。

| Requirement ID | Flow | Expected | Observed | Outcome | Evidence/log | Limitation |
| --- | --- | --- | --- | --- | --- | --- |
| R01/R04/R05 | 导入、结果/outbox 同事务、确认落盘 | 失败无部分提交；确认匹配且落盘才移队列 | 只给出 fake synced UI | not_run | E4，无存储/原始日志 | 未执行数据库故障或恢复；不能以 UI 文案签数据正确 |
| R02/R03 | 终态拒改、双击、失败原因/Other 说明 | 至多一笔结果和 outbox；校验失败保留输入 | 无 Flutter 证据 | not_run | E1 仅网页历史 | 非已观察功能失败 |
| R06/R11 | 串行同步、暂停/失败、直接同步 Toast | 不启动第二个循环；失败保留；正确反馈 | 只给出 synced 文案 | not_run | E4 | 未覆盖正常/失败/恢复链及顺序 |
| R07–R10/R14 | 地图/列表/查询/距离/按来源返回/系统适配 | 与当前原型和修正规则一致 | 无版本匹配原生步骤 | not_run | E1/E3 | SafeArea、键盘、文字缩放、语义等未执行 |
| R12 | 离线多结果 → 结束进程 → 保留安装数据重开 | 结果、原因、operationId、队列、设置保持；按配置恢复 | 只有 hot restart | not_run | E3 | 证据方式不符合进程恢复验收；不能推出产品实际失败 |
| R13 | 无底图/缓存缺失与业务保存隔离 | 无底图仍能浏览/保存；清地图缓存不清业务 | 无证据 | not_run | 无 | OS 断网与应用内离线需分开取证 |
| R12 connected 子场景 | 真实同步 | 服务持久接受与幂等、客户端确认写入可核对 | fake synced | blocked | E4 | 缺真实服务/凭据；demo/local-client 合同可不要求此能力，不能假称上传 |
| R15 真机功能子项 | 硬件原生关键链 | 目标真机实际执行通过 | 无真机 | blocked | 无 | 只阻塞硬件依赖项 |

Process stop/relaunch method and evidence：not_run。不得把 hot reload/hot restart、重建 Widget、网页刷新填入此栏。后续在已许可的 app/设备上保留数据终止原进程，重开同一安装，核对前后业务数据和 outbox；按设备能力记录 PID/进程日志。

Defects and reproduction：没有足够证据形成“产品功能 failed”缺陷。已形成补证任务：候选身份、数据库提交/确认、真实进程恢复、原生用户链。只有实际/预期分歧被复现后再交开发修复，验收者不改业务代码。

Simulator / hardware / live service / signing / delivery：模拟器描述未独立核验；硬件 blocked；live service blocked（若进入 connected 范围）；正式签名 blocked；发布 not_run。

Reviewer and coordinator decision：review / evidence_required；不 accepted 原生验收。网页、debug 构建、fake 和模拟器证据分别留在各自层级。

## 按 flutter-performance 填写的性能报告

Candidate SHA / device / OS / refresh rate / SDK / mode：unknown / simulator reported / unknown / unknown / unknown / debug reported。

Dataset size / viewport / provider / network / cache / workload：unknown；合同采用 30 条业务数据作为首版工作负载起点。未授权地图压测，不请求公共瓦片。

Budget owner / budget status / method / count：预算负责人待主控指定；测量合同 provisional；无有效 profile trace；实际样本数 unknown。候选正式性能 verdict=blocked，不是 measured_fail。

| Metric | Budget | Baseline | Candidate | Sample count/window | Raw evidence | Verdict |
| --- | --- | --- | --- | --- | --- | --- |
| UI/raster 帧 | 按目标设备刷新率分别计算；60 Hz 约 16.7 ms、120 Hz 约 8.3 ms；允许慢帧比例仍需合同确认 | 无 | debug simulator average 60 FPS reported | unknown | 无 | blocked |
| 冷启动到业务可操作 | 起止点先冻结；暂未批准绝对阈值 | 无 | 无 | 0 次有效采样 | 无 | blocked |
| 地图可用时间 | 与业务可操作分开；缓存命中/缺失分开 | 无 | 无 | 0 次有效采样 | 无 | blocked |
| 内存趋势 | Dart heap/external/RSS 分开；稳定空闲残留与缓存预算待确认 | 无 | 无 | 0 次有效采样 | 无 | blocked |
| 导入、结果/outbox、确认 I/O | 场景/队列规模与预算待确认 | 无 | 无 | 0 次有效采样 | 无 | blocked |

计划而非测量结果：目标真机 profile；以同一候选、30 条受控业务数据和受控地图来源固定网络/缓存/后台负载。先记录 5 次独立进程冷启动的单次值/范围；各关键拖缩、列表、搜索、保存/同步工作负载拟做 3 个 30 秒窗口，保存 UI/raster 原始 trace 和慢帧定义；来回流程拟做 5 轮，观察回到稳定空闲后的各内存趋势。以上采样量是可调整的启动计划，不是已批准 SLA，也不据 5 次启动生成可靠 p95。采样完成后在 release 配置复核实际体验。

Hotspots and trace events：未取得 Flutter 候选源码和有效 trace，不能诊断具体热点、估算优化收益或派发实现改动。可先准备对稳定 MapController、局部订阅、排序失效、dispose、缓存和空闲任务的审查清单；清单存在不构成性能通过。

Correctness / memory tradeoffs：未改实现，无可归因比较。

Hardware/release checks not performed：全部；当前不申请或触发前台操作。未来若某项确需前台步骤，再说明具体需要并等待授权；设备后台任务也须有该实际执行任务的权限和独占窗口。

## 按 engineering-release-handoff 填写的交付记录

Scope / configuration / revision / source：本次仅本地试跑报告；产品配置须由主控固定为 demo 或 local-client，不能仅凭 fake 宣称 connected。候选版本 unknown。

SDK / dependencies / platform / data and map source：均缺候选实证。仓库合同/架构只用于准备。

| Gate | Status | Version-matched evidence | Remaining dependency |
| --- | --- | --- | --- |
| G0 合同 | not_run（候选绑定） | 本地 R01–R16 合同可用；候选范围/配置未绑定 | 主控确定平台、配置与合同 revision，绑定候选身份 |
| G1 代码质量 | not_run | E1 不属于 Flutter 格式/分析/行为/故障测试 | 对应源码、日志与必要测试结果 |
| G2 原生功能 | not_run | E3 不能代替真实进程恢复 | 独立原生用户链、原存储重开和证据 |
| G3 硬件/性能 | blocked | E5 不合正式测量条件 | 目标真机、profile、预算、release 复核 |
| G4 数据与资源 | not_run / 外部许可子项待确认 | E4 不证明事务和持久确认 | 本地故障/恢复证据、适用升级、地图/数据/依赖许可 |
| G5 正式发布准备 | blocked | E2 仅 debug APK 描述 | 目标 release、正式签名、版本/渠道/hash、安装运行说明 |
| G6 外部交付 | not_run；本次报告范围不要求 | 无成功回执 | 未来明确发布目的地与授权后执行；本次不发布 |

Artifacts / SHA-256 / signing / version / channel：debug APK 仅 reported，未收到文件，不能填写或猜 hash；正式签名不可验证。没有产物实际存在的证据，不自称“本地客户端交付完成”。

Exact run/install commands / target：未提供 app ID、设备 ID、入口、SDK，不生成看似可执行的命令。

Upgrade/data recovery：要求保留结果、待发事件与 operationId；有历史 schema 才运行相应升级场景。不能为通过验收清数据；回滚兼容性/前滚恢复须按实际 schema 编制，本次没有已验证方案。

PR / CI / merge / deployment / live verification：均 not_run，无远端变更。外部授权/回执：不存在；本次无发布动作。

Known limitations / support owner / next action：主控接收本报告。下一步先补候选 manifest 与有效源码/产物，再派独立测试/原生验收；硬件、真实服务、正式签名和外部交付分别作为资源依赖，不能阻塞所有本地任务。

## 可继续推进的任务，不扩展产品实现

| Task | Owner | 输入 / 写入范围 | 完成证据 |
| --- | --- | --- | --- |
| QP-01 候选绑定 | 主控/交付 | 真实源码/产物/日志；仅本地 manifest | SHA 或 patch fingerprint、artifact hash、SDK/lock、配置、平台可核对 |
| QP-02 原生补证工作单 | 独立验收 | R01–R14 合同；仅验收计划/报告 | 正常/故障/恢复步骤、数据身份、预期、证据路径准备完成；执行仍待 actual target |
| QP-03 fake 确认补证 | 测试/验收 | 对应候选与受控 fake 日志 | UI、业务结果、不可变 outbox、ack 落盘相互核对；不写真实上传结论 |
| QP-04 性能合同 | 性能负责人/主控 | 目标设备与受控数据/地图合同；仅测量计划 | 明确刷新率、指标、预算状态、采样、工具、原始证据存放位置 |
| QP-05 发布依赖清单 | 交付 | scope、签名、服务/许可与目的地条件；仅 handoff | 各子项 owner、适用范围、阻塞条件；本地成果可审阅，无上传或发布 |

本次已经准备这些工作单的输入、目的和关闭证据；没有实际派工、开 GitHub issue、写产品代码或承诺设备执行完成。

## Skill 问题与建议（只报告，未修改）

1. **交付门槛的适用范围缺少结构字段，容易让主控误把全生产门槛当本地交付前提。** `engineering-release-handoff/SKILL.md:24,28` 明确允许本地客户端/演示交付和仅准备；但 `references/gates.md:3–11` 与 handoff 模板只有统一 G0–G6，没有 `required_for_scope` / `not_applicable_reason`。这是可解读的一致规则而非实质冲突，但自治执行时应显式记录 demo/local-client/connected、所需平台与本轮交付层级；G6 不适用本地准备，不能逼出无授权发布。建议增加“当前范围要求/判定/未满足依赖”字段。

2. **G4 把本地可靠性和外部资源许可合并，阻塞容易扩散。** `references/gates.md:9` 合并事务/恢复/许可，而 `SKILL.md:24` 将服务、数据/地图条件列为外部门槛。建议让报告记录 G4-local（事务/恢复）、G4-resource（数据/地图/依赖许可）及 connected 服务子项；最终生产判断仍全部满足适用要求。这样没有商业地图合同不会掩盖已完成本地事务补证，也不会误称整体通过。

3. **原生故障验收缺少测试能力交接说明。** `native-flows.md:17–20` 要求模拟数据库/outbox/确认写失败、丢响应等，但没有说明验收者应从测试职能接收哪类 fixture/故障注入入口及安全数据环境。任务合同与职责原则足够明确，实际执行仍可能因无法安全重现故障而 blocked。建议规定输入包含“受控故障配置/已知结果/数据回收方式/目标支持范围”，没有注入能力则转为补测能力任务；验收者不得自行改业务代码或清用户数据。

4. **“没有真机时执行代码/重建风险分析”需要候选源码缺失分支。** `flutter-performance/SKILL.md:14` 在本场景无法照字面完成候选代码分析；需求资料可支撑测量准备，但不能支撑具体代码热点。建议明确：缺源码先记录 source-unavailable 并索取/登记候选依赖，完成可做的测量计划，性能保持 blocked，不从原型/架构补造热点。这不是 production gate 放宽。

5. **模板缺少原始证据清单的身份与存储合同。** 三份模板要求 evidence/trace/hash，却未要求 evidence 文件 hash、采集者/时间、源文件与摘要的绑定关系；面对 E1–E5 的描述式证据仍需评审者自行补 `reported/unverified`。建议统一轻量 evidence manifest 字段（ID、path、candidate、collector、time、kind、raw/summary、hash），避免“报告引用报告”的循环证明。敏感数据仍遵守 handoff 的不含凭据/客户详情要求。

已正确覆盖且不需改动：不以测试数量判定交付、hot restart 不替代进程恢复、fake 与真实服务分开、debug/simulator 与真机 profile/release 分开、保留用户数据、后台共存、不降低门槛、不越职能修改业务代码、不未经授权发布、不把资源缺失蔓延为全工程停工。

## 本次检查范围与来源

只读取仓库三个目标 skill 的 SKILL.md、references、assets，以及 agent-engineering-team/SKILL.md、docs/agent-team/mission.md、README.md 和 Git 状态。无外部检索。未修改 skill 或仓库文件。唯一新输出是本报告。

## 复测：五项补强后的同场景前向试跑

日期：2026-10-10。重新读取了三个目标 skill 的 SKILL.md、references 和 assets；以下判定来自本次实际读取的内容，不按主控描述默认修正成功。仍未操作 app/设备/browser、修改仓库、发 issue 或执行外部动作。

### 改动核验

| 原问题 | 实际观察 | 同场景行为变化 | 复测判断 |
| --- | --- | --- | --- |
| 门槛适用范围缺字段 | `engineering-release-handoff/references/gates.md:3` 明确 scope、平台、交付层级及 required_for_scope/not_applicable_reason；模板第 7 行有对应列 | 本次 prepare 报告可完成；G6 无授权/回执不阻塞本地准备。目标候选尚未通过的 G2/G3/G5 仍保留，不能靠改 scope 签为生产就绪 | 已补强；未降低生产要求 |
| G4 混合本地和外部阻塞 | `gates.md:17` 明确 local/resource/connected，要求当前范围所需子项全部通过才能整体 passed | 事务/恢复补证可继续；缺真实凭据只影响适用的 connected 子项；地图/数据/依赖权利仍按 scope 核验，demo 不自动豁免权利 | 已补强；子项结果不会互相冒充 |
| 原生故障入口交接不明 | `flutter-native-acceptance/SKILL.md:14` 明确测试职能交接 fixture、预期、支持范围、数据回收；模板第 12 行有输入字段 | 未取得安全注入配置时数据库/确认故障项 blocked，并生成补测能力工作单；普通原生正常/恢复链不自动一并 blocked。验收者不越界写业务代码或清数据 | 已补强；职责闭环成立 |
| 性能源码缺失分支不明 | `flutter-performance/SKILL.md:16` 明确 source-unavailable | 本场景标 source-unavailable，只准备测量合同/依赖；不从 prototype/架构猜 MapController、isolate 等已存在的实际热点 | 已补强；没有产生猜测式优化任务 |
| 描述式证据和原文件绑定薄弱 | 原生 skill 第 24 行、性能 skill 第 34 行有 reported/unverified 与 manifest 规则；三个模板都增加原始 manifest | E1–E5 保留 reported/unverified；path/hash/collector/time 未提供写 unavailable，不能借本报告或旧摘要补造 raw evidence | 已补强；证据来源更容易追溯 |

### 同场景的新报告增补字段

- Controlled fault fixtures / supported targets / data cleanup：未提供。受控数据库、outbox、ack 写失败等注入项判 blocked，owner=测试职能；请该职能交付安全 fixture 包后再由独立验收执行。其余未运行原生用户链保持 not_run，不报告功能 failed。
- Performance source status：source-unavailable；测量合同 provisional；正式候选性能 verdict=blocked。模拟器 debug average 60 FPS 仍为定位线索，既不是 measured_pass，也不足以判 measured_fail。
- 本次交付 scope：prepare/report。候选未来采用 demo/local-client/connected 的哪一种尚待主控冻结；不能擅自选择 demo 来豁免用户要求的 connected 或生产交付。

| Gate/subgate | Required for本次prepare报告 | 当前候选状态 | 不适用理由 / 后续依赖 |
| --- | --- | --- | --- |
| G0 准备合同/试跑范围 | yes | 本报告范围、输入、输出和限制可追溯；候选绑定仍 not_run | 准备完成不表示候选合同/版本已绑定 |
| G1 / G2 | no（对准备成果）；yes（未来客户端验收） | not_run；故障注入能力缺失项 blocked | 网页 78/78 与 hot restart 不替代 Flutter 质量和进程恢复 |
| G3 | no（对准备成果）；yes（生产功能/性能判定） | blocked | 没有目标真机/profile/release 实测 |
| G4-local | no（对准备成果）；yes（可靠客户端验收） | not_run；受控故障补证 blocked | fake UI 不证明事务/确认落盘 |
| G4-resource | 仅准备依赖登记 | not_run / 条件待确认 | 当前不运行或压测地图；实际使用前核实适用权利 |
| G4-connected | no（本次）；connected 交付时 yes | connected 目标下 blocked | 缺服务/凭据；若最终明确为 demo/local-client，则记录 not_applicable_reason，不能声称真实上传 |
| G5 | no（本次prepare）；正式发布准备时 yes | blocked | debug APK 无法代替 release/正式签名/版本/hash |
| G6 | no（本次本地prepare） | not_run，且 required_for_scope=false | 本次没有外部目的地、发布授权或动作；不产生授权等待流程，也不虚构回执 |

原始 evidence manifest（本次候选输入）：

| ID | path | candidate | collector/time | kind | raw/summary | SHA-256 | credibility |
| --- | --- | --- | --- | --- | --- | --- | --- |
| E1 | unavailable | unknown | unavailable | web test claim | summary only | unavailable | reported/unverified；非 Flutter |
| E2 | unavailable | unknown | unavailable | debug artifact claim | summary only | unavailable | reported/unverified |
| E3 | unavailable | unknown | unavailable | simulator hot restart claim | summary only | unavailable | reported/unverified；不是进程恢复 |
| E4 | unavailable | unknown | unavailable | fake synced claim | summary only | unavailable | reported/unverified；不证明真实服务 |
| E5 | unavailable | unknown | unavailable | simulator debug FPS claim | summary only | unavailable | reported/unverified；不是发布性能依据 |

本试跑报告实际存在，可作为 skill 审查成果；它不是产品测试原始数据。源码/产物 hash 仍不从仓库 HEAD、skill 文件 hash 或报告 hash 推导。

### 新冲突与残余注意项

本次未发现新实质冲突。`fault fixtures` 的 blocked 路由、`source-unavailable` 的准备路由和 G4 子项均将依赖缺失收敛到对应职能，未要求额外产品开发、前台访问或发布。修正后可完成本地可审阅报告，同时保持候选原生/性能/正式发布条件未满足。

有一个轻微术语注意：gates 的 scope 枚举将 prepare（工作模式）和 demo/local-client/connected（运行配置）放在同一行；模板另外还有 configuration，所以当前可以清晰填写 `scope=prepare, configuration=unknown`。主控应保持这两个维度，而非把准备状态当成产品运行配置。该表述未在本场景造成错误判定，不是阻塞修订项。

### 本次实际读取的补强文件指纹

以下只标识审查时的 skill 文本，均不是假设 Flutter 候选的 fingerprint：

| File | SHA-256 |
| --- | --- |
| `.agents/skills/flutter-native-acceptance/SKILL.md` | `61585aaef90c5ce1a95256d1ce6073e3d984a55a57892dcb7c10cd5f1b67c3c2` |
| `.agents/skills/flutter-native-acceptance/assets/acceptance-template.md` | `5632afa07cc7d8f91171ed1256d1ad84d88eb1403de175a1e5b7169b15189609` |
| `.agents/skills/flutter-performance/SKILL.md` | `420c61e4958dbbfdebd4b402fc1e59a5ae361d87b3f5e38188413604aac5bf99` |
| `.agents/skills/flutter-performance/assets/performance-template.md` | `c729f84ea9e9e956afe54888c20c8ea57c84dee1057d28ea913723bc4510b7c0` |
| `.agents/skills/engineering-release-handoff/references/gates.md` | `6f1bf3fd9f6747af7da89966f59702471723c61c09b19aaf22740585d12d2d1e` |
| `.agents/skills/engineering-release-handoff/assets/handoff-template.md` | `07fcba262631e622e625eaba5a3ddb94612ddedf9fc7888f1382f09116736482` |
