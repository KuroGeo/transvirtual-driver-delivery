No product requirements in this runtime fixture
