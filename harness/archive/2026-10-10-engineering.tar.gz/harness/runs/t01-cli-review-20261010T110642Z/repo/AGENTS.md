Isolated harmless CLI review fixture
