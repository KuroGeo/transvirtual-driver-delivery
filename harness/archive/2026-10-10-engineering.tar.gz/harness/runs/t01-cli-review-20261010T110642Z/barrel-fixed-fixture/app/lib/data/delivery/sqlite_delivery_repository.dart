class SqliteDeliveryRepository {}
