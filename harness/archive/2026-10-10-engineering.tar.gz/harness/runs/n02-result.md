# N02 Flutter 本地客户端与原生可靠性探针

- Task: N02
- Contract: revision 3 (`harness/contracts.md`)
- Base: 8e9a7cc
- State: implementation complete; host checks passed; ready for independent review/native execution
- Production verdict: no-go; this work does not sign production release

## Implemented scope

正式 `app/lib/main.dart` 原生装配 sqflite factory + CSV asset loader，注入 Repository 和 SyncCoordinator 到 ChangeNotifier ViewModel。正式入口明确使用 UnavailableTransport。

列表从 Repository 加载全部站点，计数来自真实 stops/outbox；显示详情、终态状态与原因。pending 可提交 completed 或 failed，failed 原因必填。保存失败保留文本和 pending 状态；保存成功回到列表并提示本地已保存、待服务。同步入口使用 unavailable 传输，失败保留队列。保存已经成功但刷新失败单独提示已保存，并只提供重试加载。

独立 `app/lib/harness_probe.dart` 原生测试入口用同一 SqliteDeliveryRepository + CSV 业务，但独立 `ocean_delivery_harness.sqlite`；没有正式 main 引用。它在业务库目录原子写 `harness-probe.json`、`harness-probe-manifest.json`。三个 native OS 进程阶段分别 saved/recovered/confirmed；首进程保存完成与失败两项的原 operationIds/seq/三身份/reason；第二进程先验证原 queue=2、站点原身份/原因，再 fake 串行确认后 queue=0；第三进程验证原终态和原因保留、不重发。报告包含 phase/pass、processId、operationIds、queueCount、before/after、reason、发送/ack/仓库/协调器事件、失败详情。

## Actual host commands

All run with Flutter 3.44.2 / Dart 3.12.2. Test data is a host memory Repository fixture; sync tests use the real SyncCoordinator with UnavailableTransport. No native plugin/process/device evidence is claimed here.

| Command | Exit | Result |
| --- | --- | --- |
| `dart format app/lib/main.dart app/lib/app app/lib/ui app/lib/harness_probe.dart app/test/ui app/test/widget_test.dart` | 0 | 7 Dart files formatted; 5 changed |
| `cd app` then `flutter test test/widget_test.dart --reporter expanded` | 0 | 8/8 passed, approximately 1 second test time |
| `cd app` then `dart analyze lib/main.dart lib/app lib/ui lib/harness_probe.dart test/ui test/widget_test.dart` | 0 | No issues found |
| `dart format --output=none --set-exit-if-changed app/lib/main.dart app/lib/app app/lib/ui app/lib/harness_probe.dart app/test/ui app/test/widget_test.dart` | 0 | 7 files, 0 changed |
| `git diff --check` | 0 | No whitespace errors in tracked working diff; new authored Dart files separately formatter-checked |

Widget assertions cover initial 30-stop rendering/local service wording; completion and unavailable sync retaining outbox; failed-reason validation, preserving text after storage error and retry; completion error and retry; initial data and database bootstrap errors/retry; persisted save followed by refresh failure; keyboard/inset scrolling without overflow at 390 × 844.

## Bounded review

Reviewed authored UI/model/bootstrap/probe/test paths against revision 3. SQLite/schema/CSV parsing remain data owner responsibility. No data implementation, pubspec/lock/assets, platform folder, CI, external destination, commit, dependency installation or native build/device operation was performed by N02. No counters or new framework remain. ViewModel depends only on Repository and SyncCoordinator contract; test-only fake is isolated from formal main.

## Pending evidence / handoff

- Root owns native build, simulator OS launches and report extraction. Native `saved`, `recovered`, `confirmed` have not been executed by N02.
- Root must match expected report phase per process and preserve the application data; old report files cannot count as the next process result.
- Real service, map product, physical-device interaction/performance and production Harness gates remain outside this local baseline.
- `app/README.md` documents exact filenames, staged native assertions and evidence limits.
- No commit was made; shared worktree changes are handed to root for integration/review.

## P2 lifecycle rework after independent review

The original `close()` could close storage before active initialization/read/submit/transport continuations settled, allowing the auto-initializing repository to reopen. Added retained controlled-completer regressions in `app/test/ui/delivery_view_model_lifecycle_test.dart` before changing the ViewModel: all 4 failed with actual `reopenCalls=1` (test process exit 1), recorded in `n02-lifecycle-before/before-fix.log` and `result.json`.

The final ViewModel records its three owned operation futures before observable work, stops new actions when closing, pauses the coordinator, suppresses refresh at each asynchronous boundary, waits owned futures to settle, and only then disposes/once-closes storage. Repeated close callers join the same future. A subsequent reentrant-notification regression also reproduced a dispose-during-notify assertion/new send before its fix (`n02-lifecycle-reentrant-before/before-fix.log`, exit 1); final disposal is deferred past notifications and business entry rechecks closed after notify. No generic lifecycle framework, data/schema/shared/native source changes were added.

Final actual run uses `state.lease(['app-workspace'])`; the prior attempt while root's native lease was active exited 75 without running host tools. After release, `n02-lifecycle-final-v2/` records: `flutter test --no-pub test/ui/delivery_view_model_lifecycle_test.dart test/widget_test.dart --reporter expanded` exit 0, 13/13 passed (5 lifecycle + 8 widget); the scoped `dart analyze` exit 0/No issues; formatter and format check exit 0/0 changed. The lease is released. Earlier `n02-lifecycle-after` had two informational analyzer findings; the final run removed them. Raw before/after results are retained separately.

Rework state: corrected and ready for independent re-review; root must rebuild/reverify the stable candidate as appropriate. No native result or production qualification is signed by N02.
