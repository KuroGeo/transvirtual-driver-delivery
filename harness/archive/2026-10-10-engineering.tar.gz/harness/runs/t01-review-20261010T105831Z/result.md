# T01 implementation result

Implemented `state.lease`, `state.validate_resume`, and `gate.evaluate` using Python stdlib and OS flock only. Contract revision 3; base HEAD `8e9a7cc`. Changes are limited to the four assigned source/test files and these ignored run records.

Final check: `python3 -m unittest discover -s harness/tests -p 'test_*.py' -v` — 22 test methods passed, exit 0, 0.147 seconds reported by unittest. Raw log: `after-fix.log`; command/exit code/source hashes: `result.json`.

Real subprocess drill: PID 9088 acquired a lease; a second acquisition raised BusyError and resume rejected both its live PID and held flock. SIGKILL exited -9. The child left active JSON metadata, but its OS lock was released; matching-source resume and reacquisition succeeded. Changing the source fingerprint rejected reuse of completed stages. These observations are in `after-fix.log`.

Review found and reproduced one gap: a second unsigned release artifact could be chosen by a delivery receipt because the original gate only checked membership among artifact hashes. New regression failed before repair (test command exit 1, `before-fix.log` / `before-fix.json`). The repaired gate requires every release artifact and delivered hash to match a passed production signature report; full rerun passed.

Negative cases also cover every missing H01–H08 / G0–G6 entry, 90 invalid-status cases, stale source/entry/raw-report identity, absent files and hash mismatch, unenforced CI/release, browser or host native claims, hot restart, debug/emulator/simulator performance, fake connected transport, debug signatures, absent authorization, wrong destination and wrong artifact.

This validates the local tooling and evidence schema. Synthetic passing fixtures are not actual device, service, signature, required-check, delivery or product evidence. Production remains no-go until real external enforcement and applicable product evidence exist. No app/global configuration/foreground interaction/external publishing/commit occurred in this task.
