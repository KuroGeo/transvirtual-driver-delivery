# N01 data reliability baseline

- State: review; production remains no-go.
- Base: `8e9a7cca9c4360ca07d86e8aa8d196caf88c8c42`; contract revision: 3.
- Scope: `app/lib/models/`, `app/lib/data/delivery/`, `app/test/data/`, `app/test/sync/` and this ignored run report/logs. Shared configuration, UI, native app build, device/browser operation, publishing and commits were not performed by N01.

Implemented immutable pure Dart models and the agreed Repository/Transport/Coordinator API. SQLite schema version 1 persists dataset/stop/operation identities. Initial CSV is fully validated before a transactional batch import; a reopened file skips source loading. Terminal submission conditionally changes one pending stop and inserts its immutable outbox snapshot in one transaction. A matching three-identity acknowledgement writes the stop confirmation and removes only its outbox row in one transaction; operation identity, terminal status and reason remain on the stop.

`SyncCoordinator.sync()` returns the same in-flight future to repeated triggers, sends in seq order, persists each ack before rereading the queue, stops on failure, and releases its running flag after completion/failure. Pause allows in-flight confirmation to finish and prevents the next send. The default transport is unavailable. The fake is explicit and local to tests/probe. Optional event sinks expose only stage, operationId and count; observer failures do not alter committed business outcomes.

Public constructors use named arguments. `submit` returns `Future<void>`; invalid pending/failed-reason input throws `ArgumentError`, unknown stop/terminal change throws `StateError`, and invalid CSV throws `FormatException`. Sync transport, mismatch and ack persistence failures propagate to the caller. N02 was notified of these signatures and retained operationId semantics.

## Executed verification

Workdir for all commands: `app/`.

| Actual command | Exit | Raw output |
| --- | --- | --- |
| `flutter test --no-pub test/data test/sync --reporter expanded` | 0 | [n01-tests.log](n01-tests.log), [exit](n01-tests.exit) |
| `flutter analyze --no-pub lib/models lib/data/delivery test/data test/sync` | 0 | [n01-analyze.log](n01-analyze.log), [exit](n01-analyze.exit) |
| `dart format --output=none --set-exit-if-changed lib/models lib/data/delivery test/data test/sync` | 0 | [n01-format.log](n01-format.log), [exit](n01-format.exit) |

Final results: `+39: All tests passed!`; `No issues found!`; 7 formatted files, 0 changes. The initial analyzer run reported 9 lint findings; they were fixed before the recorded final runs.

The 39 retained regression/specification tests use isolated temporary FFI SQLite files with teardown, the real 30-row asset, and controlled SQLite triggers. They cover whole-import validation/retry and insertion rollback; historical missing reasons; stable identities/outbox snapshots across file close/reopen; repeated/concurrent/terminal submission rejection; new failure reason validation; outbox insert rollback; all three wrong ack identities and duplicate ack; confirmation-write and outbox-delete rollback; default unavailable; strict serial/coalesced triggers; rereading newly queued results; pause/resume; transport and acknowledgement failure with finally/retry; and telemetry privacy/observer failure.

This evidence is host Flutter tests over actual FFI SQLite files. File close/reopen is not OS process termination evidence, and these runs do not demonstrate native plugin/device behavior or production service acceptance. The native probe/OS lifecycle task and independent review remain with the main controller.

## Source SHA-256 at final verification

```text
7a4fa3547ff411385b20275feda7a21e4aee8acb6ed577d6b8c3638860711a3e  app/lib/models/delivery.dart
130efdea6f381b3369a8aeb65a76277ba17195332cefe3cd8158760f8b6d99b2  app/lib/data/delivery/delivery_repository.dart
cc085ac4a55b7dfb08fc05ef933ebf0cfff72c6936c26663df5f6ff25826df18  app/lib/data/delivery/sqlite_delivery_repository.dart
b0a1ff9c6625e12595a92aa491094354fddbcfc97646634fba4e00a1042966b1  app/lib/data/delivery/sync_coordinator.dart
6ed00f560ba9419db57e71521e54934954445d3f3d28e8c6212ca925abddd729  app/test/data/repository_fixture.dart
fa1af77101621fad0e469a090f8e9db498a8e52edd14f8387a141f384192ef1b  app/test/data/sqlite_delivery_repository_test.dart
3d32c45ee1a57781b6f0696b05330220510e80800477e027027d65074df80ccf  app/test/sync/sync_coordinator_test.dart
```
