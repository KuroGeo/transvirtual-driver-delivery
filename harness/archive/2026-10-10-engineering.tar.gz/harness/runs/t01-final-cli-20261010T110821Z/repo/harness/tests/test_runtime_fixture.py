from pathlib import Path
import json,os,signal,time,unittest
class RuntimeFixture(unittest.TestCase):
    def test_runtime(self):
        rt=Path(__file__).resolve().parents[2]/'.runtime'
        mode=json.loads((rt/'control.json').read_text())['mode']
        if mode=='ignore-term':signal.signal(signal.SIGTERM,signal.SIG_IGN)
        (rt/'child.json').write_text(json.dumps({'pid':os.getpid(),'mode':mode}))
        if mode!='pass':time.sleep(60)
        self.assertTrue(True)
