No product assertions
