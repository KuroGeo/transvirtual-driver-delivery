Harmless isolated CLI review
