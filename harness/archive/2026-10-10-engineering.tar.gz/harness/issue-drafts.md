# 本地重点 Issue 草稿

以下是可审阅正文，尚未发布或查询远端去重。E00–E10、X00–X04 是 [任务图](backlog.json) 的本地 ID，不是 GitHub 编号。发布前 Issue 职能查现有工作单，补实际环境并更新真实依赖链接。

## E02：离线结果与 outbox 原子落盘，文件数据库重开后恢复

类型：engineering / feature。来源：R01–R05、架构第 4 节。

当前只有浏览器原型，没有 Flutter SQLite 实现。实现纯 Dart 模型、整份导入、条件终态提交、不可变 outbox 与匹配确认事务，保证结果和未确认记录一致。排除真实后端、登录及同步调度。依赖 X00（E01 后）与冻结 Repository 契约；数据开发 owns schema，测试职能补 E04。

验收：非法/重复提交不改结果、不加队列；初始失败原因缺失与新提交必填区别处理；outbox 插入失败整体回滚；文件库关闭重开后原因/operationId/队列不变；确认写失败保留原项，未知/重复确认不改其他项；导入失败无半批次，冷启不覆盖数据。关闭需对应 SHA、命令/退出码和文件库故障日志；真实进程恢复另由 E08 验收。

## E05：同步串行处理匹配确认，暂停和超时保留结果

类型：feature。来源：R05/R06/R11/R12、架构第 5 节。

依赖 E02。同步开发负责协调器/transport，通过 Repository 而非直接 SQL；一个 seq 串行循环，确认持久化才移队列。范围包含受控 fake/mock、unavailable、超时/分类错误、暂停、重复触发与重试，真实认证/HTTP 后续。

验收：多个入口至多一个循环；暂停不发下一条；错配 ack 不移队列；确认写失败恢复沿用原 operationId；unavailable 等待；finally 释放运行标志。关闭需同 SHA 确定性协调器测试及各配置记录，不称真实上传完成。

## E08：原生离线多结果在真实进程重开后恢复

类型：verification。来源：R12 与原题关键流程，R01–R14 用户链一并复核。

依赖 X02（E07 后）；非对应实现者的验收 Agent 独占目标设备，不改业务代码。离线完成 A、失败 B，记录两条身份；真正终止进程并保留数据，重开结果/原因/operationId/队列不变；demo online 逐条模拟确认，local-client online 保持待服务。复核终态拒改、来源返回、直接同步 Toast、底图失败和键盘/文字缩放。

关闭需设备/OS/app ID、候选 SHA/hash、终止/重开记录、截图/录屏与逐需求验收表。hot restart、网页刷新不关闭本项；缺设备保持 blocked。

## E09：约定真机与负载下建立 Flutter 性能结果

类型：verification / performance。来源：R15、架构第 7/8 节。

依赖 X02（E07 后）；先记录最低设备/刷新率/容量和预算状态。profile 测量冷启、拖缩/聚合、滚动/搜索、保存反馈和多轮内存，release 复核。优化另提有 trace 的修复任务，不强行换框架/地图 SDK。

验收：业务可操作与地图可用时间分开；UI/raster 和超预算帧分别统计；稳定态内存趋势明确；条件/原始 trace 可复现，前后同条件。关闭需硬件数据和明确预算 verdict；debug/模拟器不替代，缺预算/真机为 provisional/blocked，30 站通过不宣称数千站能力。

## E10：交付版本可复现候选、数据恢复与适用发布材料

类型：release。来源：R16/R17；G4–G6 按实际范围启用。文档/manifest 可预备，执行关闭依赖 X03/X04/E08/E09 与适用门槛。

交付核对 G0–G5，形成源码/产物 hash、SDK/lock、数据/地图说明、签名/版本、运行命令及适用迁移恢复记录。首次发布无旧 schema 和已有版本升级分别说明。

当前不含外部发布授权/目的地。关闭本地交付需真实 manifest 及版本匹配门槛；外部发布另有目的地和回执，不以 debug APK 或 PR 合并称上线。不清库演示升级，不以公共 OSM 为商业备用服务。

生产关闭另须 H01–H08 demonstrated 与实际门禁接线/负例证据；当前 [Harness 状态](status.json) 为 no-go，不能把准备完成或本地候选改名绕过上线限制。

## X03：生产门禁实际拒绝缺证、错版本和跨层冒充

类型：engineering / verification。来源：R17、[Harness 审计](readiness.md)。依赖 X02/X01；Harness Agent owns tooling gate 与 CI，主控协调共享配置。

把候选源码/diff、SDK/lock/配置、产物 hash 和原始验收 manifest 绑定到 CI/发布路径。对必要证据 missing、unknown、skipped、failed、stale、mismatched 逐项注入反例，实际拒绝；合法候选才可进入后续发布检查。不得只添加一个总是绿色的检查脚本或要求 Agent 自觉遵守。

关闭需当前 harness 版本的正/负例日志、实际 CI 结果与服务端 required checks/发布接线核验。缺权限或发布接线不可查则对应 enforced 状态保持 blocked，不宣称技术上已阻止绕过。当前只是草稿，未实现或发布此 Issue。
