# 工程入口

这里负责把任务变成可运行、可审查的结果。[本次真实演练](rehearsal.md) 展示派工、交叉审查、返工和验证闭环。职能 skill 在 `.agents/skills/`，Flutter 客户端在 `app/`；`docs/` 保存产品题目和架构，`prototype/` 保存交互设计。

先读 [任务合同](mission.md) 和 [当前接口](contracts.md)，再从 [任务图](backlog.json) 取依赖已满足的任务。主控维护任务和决策，工作 Agent 在指定写域实现，另一职能独立审查；格式、分析、测试和候选证据由工具核验。[当前能力审计](readiness.md) 区分本地演练与生产资格。

## 可执行命令

需要 Python 3、Flutter **3.44.2**（Dart **3.12.2**）。SDK 选择记录在 `app/.fvmrc`；依赖由 `app/pubspec.lock` 锁定。首次执行：

```sh
cd app
flutter pub get --enforce-lockfile
cd ..
python3 harness/run.py check
python3 harness/run.py quality
```

`check` 检查当前文档链接、需求覆盖、任务 DAG、Dart 层次依赖和 Harness 回归。`quality` 加 SDK、格式、静态分析与全部 Flutter host/widget 测试。迭代时用 `python3 harness/run.py test --target test/widget_test.dart` 跑窄测试，仍通过同一资源锁与日志入口。错误附文件、命令、退出码和日志，修复后重跑相关检查。

macOS + Xcode + CocoaPods，安装 iOS 26.4 runtime 后：

```sh
python3 harness/run.py build
python3 harness/run.py native
```

`build` 构建正常客户端；`native` 构建独立测试入口，创建本任务专用 iPhone 17 Pro 模拟器，三次启动并真正终止 OS 进程：保存两笔 → 核对原原因/身份/队列并模拟串行确认 → 再次重启确认不重发。全程 CLI 后台操作，结束仅清理本次创建的设备。原生 JSON、业务事件和 SQLite 快照在运行目录；模拟器 debug/fake 证据仅证明该可靠性基线。

## 中断、恢复与门禁

每次执行保存 `harness/runs/<时间-命令>/report.json`、日志和 OS lease。默认逐次记录不进入 Git。SIGTERM/Ctrl-C 会终止子进程并归还锁；被杀后以内核锁状态判断资源，不凭遗留 `active` 文件猜状态。同候选恢复：

```sh
python3 harness/run.py quality --resume harness/runs/<原运行目录>
```

只复用命令、源码 fingerprint 和日志 hash 一致的已通过阶段；活 PID、持有锁、源码或证据变化会拒绝恢复。模型 Agent 的活跃状态仍由主控查询当前协作 runtime，OS PID 不能替代它。

生产检查使用单独证据 manifest：

```sh
python3 harness/run.py gate --manifest harness/runs/<交付目录>/manifest.json
```

[门禁实现](gate.py) 校验 H01–H08、G0–G6、当前候选、原始证据 hash 与原生/性能/签名/授权回执的层级。缺证失败是正确结果。正向合成 fixture 只验证 schema，不是生产证据。CI 配置见 `.github/workflows/quality.yml`；服务端 required checks 与发布路径实际启用前不记 enforced。

## 职能 skill

| 职能 | Skill | 交回的结果 |
| --- | --- | --- |
| 主控 | agent-engineering-team | 有依赖的工作单、单一写域、集成与复审 |
| 需求 | engineering-requirements-extract | 有来源的行为合同与增量冲突 |
| Issue | engineering-issue-authoring | 聚焦问题、复现、范围、依赖与验收标准 |
| 开发 | flutter-development | 可运行业务切片与必要行为回归 |
| 测试 | engineering-flutter-testing | 独立风险回归及分层证据 |
| 原生验收 | flutter-native-acceptance | 用户流程、进程与设备事实 |
| 性能 | flutter-performance | 同条件真机 profile 数据、热点与修复复验 |
| Harness | harness-engineering | 执行环境、机械边界、观察反馈与恢复 |
| 交付 | engineering-release-handoff | 对应候选的产物、门槛和真实交付层级 |

每个岗位按任务需要调用，不为岗位数量常驻 Agent。共享配置、依赖锁、schema、启动装配与 CI 各有一个写入者；设备/构建操作使用实际 lease。

准备阶段原始记录保存在 [history/preparation](history/preparation/README.md)，其中路径和 hash 指向当时快照，保持原始内容不当作当前任务入口。当前试跑结果归入 `harness/runs/`；稳定结论与可分享证据再收录到版本化演练记录。
