# 职能 skill 只读审查与前向走查

两个新 skill 重点明确：开发负责分层实现/必要行为回归/交 review；测试负责独立风险覆盖、可控故障、实际失败反馈与修复后复验。文字均指向动作和证据，没有要求堆框架、重复全部开发测试或加载整套手册。
仓库可独立入口：`AGENTS.md` → `harness/README.md` 职能表 → 对应 `.agents/skills/*/SKILL.md`，再读 mission/contracts；总控 protocol/work-orders 已区分开发、测试、原生验收和实际资源 lease。
一处操作差异：开发 skill 第14行要求“用项目 Harness 跑窄测试”，但 `harness/run.py` 的 command/参数只有整套 quality，没有测试路径选择；测试 skill 第20行的“或约定测试入口”与当前工具更吻合。无需为此新增框架，派工约定窄 Flutter 命令即可。
此次实际协作：N01/N02 在新 skill 出现前按通用 flutter-testing 和直接窄命令验证；跨职能只读审查发现关闭后刷新/重开风险，开发自测此前未覆盖，符合新测试职能的必要性。此次是工作Agent复用测试/审查职能，并未维持每岗位常驻Agent。

A 输入：用户要求实现现有失败表单且数据库偶发保存失败。
A 读取：AGENTS、flutter-development、harness mission 的R03/R04、contracts、solution-design §4.2、当前 delivery_screen/view_model、SQLite repository、widget_test 和 data回滚测试；不重读地图/性能/发布资料。
A 动作：在既定UI写域保留TextEditingController及原输入，校验空原因、禁用重复提交；只有commit成功才离开详情，保存后刷新失败单独表达。SQLite错误不靠UI另写状态/outbox；跨数据契约问题交唯一负责人。
A 验证：先检查活lease；按约定入口跑失败保存→输入仍在→重试成功widget回归；复用真实SQLite trigger的原子回滚测试，不复制实现；再跑受影响quality。设备行为交原生验收，当前走查不执行。
A 交回范例：`R03/R04｜改动理由+源码指纹｜widget/文件库实际命令、退出码和日志｜保存失败输入保留/重试结果｜native not_run｜state=review`（范例字段，不是已执行结果）。

B 输入：用户要求独立测试当前关闭窗口时数据库行为。
B 读取：AGENTS、engineering-flutter-testing、contracts、solution-design §3.3、app dispose、ViewModel close/load/submit/sync、Repository initialize/close、已有 lifecycle/widget/data 测试及相关运行lease。
B 动作：先检查现有覆盖，用Completer精确停在initialize/读取/submit/发送，再触发close或widget unmount并释放在途动作；检查close只一次、无关闭后读取/重开/通知、ack在close前收尾、下一项留队列。只补缺失风险，不改业务实现或清数据。
B 验证：unit检查事件顺序与重复close，widget检查卸载/在途操作，隔离FFI文件库检查提交后持久结果和关闭后库状态；实际OS关窗/进程终止需原生验收，host卸载不能代签。尊重lease，日志绑定候选。
B 交回范例：`生命周期｜passed/failed填实值｜复现时序、实际/预期、影响、失败日志/候选｜若失败交开发repair；修复后原回归+一项未用于修复的风险场景｜OS窗口/设备not_run`。
以上仅源文件审查和前向走查；未改源码、运行测试/设备或产生外部写入，未为评审新增产品要求。
