# N02 independent review

Verdict: one P2 lifecycle finding; read-only review of main/app/ui/probe and widget tests. No source/config/device changes.

- [P2] `DeliveryViewModel.close()` closes storage before active load/save/sync has settled (`app/lib/ui/delivery_view_model.dart:121–126`). An awaited submit can then continue into `_refresh()` (65–69); sync always refreshes in finally (98–100), and load also refreshes after initialization (44–45).
- Raw evidence: close sets `_closed = true`, invokes `pause()`, and immediately `await repository.close()`; `_refresh()` calls `repository.loadStops()`/`pendingUpdates()` without a closed check (109–114). SQLite read methods auto-initialize, so this continuation may reopen a closed DB, while future `close()` exits at 122. An in-flight transport may also try to persist its ack after storage closed.
- Requested correction: stop new actions, pause the loop, settle or cancel owned in-flight work before closing storage, and suppress post-close refresh. Add a controlled-completer lifecycle regression rather than a timer-based test.

Verified by source: failure input remains in the detail TextEditingController; failed submit returns false and does not pop (`delivery_screen.dart:155,165–176`). Buttons/input disable during saving (227,244–245), and success followed by refresh failure is explicitly distinguished (`delivery_view_model.dart:65–74`; corresponding widget regression exists at `widget_test.dart:171`).
Verified by source: main injects the native sqflite factory/asset loader and `UnavailableTransport` (`main.dart:16–28`); normal UI reports local saved/waiting, and fake transport occurs only in the explicit probe.
Probe uses a separate SQLite file, two immutable original updates, saved/recovered/confirmed phases, PID differences, full queue identity/status/reason/seq comparison, serial fake ack, retained stop identities and empty-queue restart checks (`harness_probe.dart:56–58,97–103,115–118,163–213,246–258`). It requires the controller to actually terminate/relaunch processes; source checks alone do not prove OS process termination.
No unnecessary framework or duplicate business persistence implementation found; the local list/detail baseline remains within this iteration. Full map workbench, real transport, device/native lifecycle evidence and production eligibility remain separate.

Actual evidence command: `nl -ba app/lib/app/ocean_delivery_app.dart; nl -ba app/lib/ui/delivery_view_model.dart; nl -ba app/lib/ui/delivery_screen.dart` (exit 0); follow-up numbered main/probe/fake/widget source reads (exit 0).
No test command executed: the controller's current `20261010T110054101037Z-build/report.json` records a running iOS build and active `app-workspace` lease. Existing test source was reviewed, but its runtime result is not claimed here.
