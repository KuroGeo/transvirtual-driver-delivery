# 本地缺陷工作单示例

本次只起草记录，不向 GitHub 发布/更新。已读远端全部 10 条既有 issue（均 CLOSED）及 #7/#8 正文；它们是历史计划，其关闭状态不证明当前候选已验收。下列是本轮实际复现的问题，与 [历史测试任务 #8](https://github.com/KuroGeo/transvirtual-driver-delivery/issues/8) 有关但不复用其关闭证据。

## HX-01：主控中断后活子任务必须阻止重入

类型 bug；需求 R17；负责 Harness 开发、独立审查者复验。候选与源码文件清单见 `source-manifest.json`。范围是本地命令、OS lease 和恢复；不修改模型 runtime 或产品功能。

复现：阶段运行期间 SIGKILL 主控；初版子任务继续运行，但资源锁可重取、resume 允许。保留场景再让子任务忽略 SIGTERM，初次修正仍释放 lease 而留下活子任务。预期：活任务继续占用资源；取消应终止整个任务进程组，退出后才可重入。原始证据见 `runner-original-findings.json` 和 `runner-kill-resume.json`。

验收：持锁子阶段存活时新派工/恢复非零退出；正常 TERM 与忽略 TERM 都不留活任务；进程结束后同候选恢复只复用 hash 验证过的通过阶段，变更候选拒绝。关闭依据：`runner-independent-review.json` 的实际 CLI kill/TERM/resume 与最终28项工具回归，状态 **本地修复已验收**。没有远端 issue 编号或发布回执。

## NX-01：在途数据库操作结束前不得关闭仓库

类型 bug；需求 R04/R06/R17；负责 UI 开发、数据职能独立审查、主控集成复验。范围是 ViewModel 关闭与相关回归，不改 schema/数据接口，不引入通用生命周期框架。

复现：用 Completer 停在 initialize/读取/submit/send，调用 close，再释放在途操作。初版关闭后的刷新/ack 会重新打开库；通知回调内 close 还触发 dispose 断言与多余发送。预期：禁止新操作，暂停后续发送，已有提交/确认收尾，再关闭一次；不丢原输入或队列。原始失败见 `ui-before-fix.log` 与 `ui-reentrant-before.log`。

验收：关闭后的读取/重开数为0，已有提交/确认先于唯一 close，第二项队列仍保留，重入 close 共享同一 Future；受影响正常表单仍可保存/失败重试。关闭依据：`ui-after-fix.log` 的5项生命周期＋8项widget通过，以及同候选52项最终回归，状态 **本地修复已验收**。host 证据不代签原生窗口或生产资格。
