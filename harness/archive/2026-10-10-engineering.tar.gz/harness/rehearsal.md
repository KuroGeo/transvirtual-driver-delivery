# 工程团队真实演练

**本轮通过：能够自主分工、实现关键工程切片、独立发现问题、返工并复验。** 三个工作 Agent 加主控实际执行，完成的是可推进后续工程的本地体系与可靠性基线。生产仍 no-go，不能把本次结果解释为完整配送 App 已上线。

最终候选：`89fa4461c961cc287f10665314c9e418da69bcddc721398f12e6c559683c1b25`。HEAD `8e9a7cc` 加当前未提交源码；[源码清单](evidence/rehearsal/source-manifest.json) 包含148个当前输入文件的 SHA-256，网页历史结果不计入本轮。

## 团队怎样推进

| 实际负责人 | 实现 | 交叉职能 |
| --- | --- | --- |
| native_data | SQLite 导入、终态/outbox 原子提交、三身份确认、串行同步 | 独立审查 UI，发现关闭竞态；前向走查开发/测试 skill |
| native_app | 列表/详情/失败表单、默认 unavailable、独立原生探针 | 审查数据/同步；接回 UI 缺陷并修复 |
| harness_controls | OS lease、恢复校验、生产证据 gate 与负例 | 审查主控 runner，复现缺陷与未参与修改的取消场景 |
| 主控 | 合同/写域、SDK/平台、CLI、机械边界、CI、集成 | 审阅结果、回派修复、全量检查、后台原生执行和真实 gate 判定 |

过程是“交回 review → 用具体证据返工 → 对应职能复测 → 主控接受”，不是 Agent 自述完成就关闭任务。[本轮任务记录](work.json) 是当前执行状态；[backlog](backlog.json) 保留完整产品路线与启动时的基线进展快照，不能当当前运行任务板。

## 发现问题后的表现

| 实际问题 | 修复后的可观察结果 | 原始证据 |
| --- | --- | --- |
| 签名 A 曾能替未签 B 通过交付 | 每个交付产物绑定自己的生产签名 | [前失败](evidence/rehearsal/gate-before-fix.log) / [后通过](evidence/rehearsal/gate-after-fix.log) |
| SIGKILL 主控曾留下活子任务且释放锁 | 活子阶段持有继承 lease，冲突/恢复拒绝 | [原发现](evidence/rehearsal/runner-original-findings.json) / [实测恢复](evidence/rehearsal/runner-kill-resume.json) |
| 门禁 resume 曾复用变化前的 manifest 结果 | gate 总是重验当前证据，改成未强制即失败 | [最终独立复验](evidence/rehearsal/runner-independent-review.json) |
| UI 经 barrel 曾绕过 SQLite 边界 | 转导出/条件依赖沿链检查并指出修复位置 | [最终独立复验](evidence/rehearsal/runner-independent-review.json) |
| 保留场景中子任务忽略 TERM | 等待5.081秒后整组终止，确认无活进程再恢复 | [最终独立复验](evidence/rehearsal/runner-independent-review.json) |
| 关闭时在途刷新/ack 曾重开库 | 等待已有操作，禁止新操作与后续刷新，最后关闭一次 | [原失败](evidence/rehearsal/ui-before-fix.log) / [修复后](evidence/rehearsal/ui-after-fix.log) |
| 通知回调内关闭曾触发断言与额外发送 | 关闭重入共享 Future，通知后闭锁，收尾后 dispose | [保留场景失败](evidence/rehearsal/ui-reentrant-before.log) / [修复后](evidence/rehearsal/ui-after-fix.log) |
| macOS 临时路径 /var 与 /private/var 曾误判依赖 | 路径归一化；注释/普通字符串不计 import | [前失败](evidence/rehearsal/structure-before-fix.log) / [后通过](evidence/rehearsal/structure-after-fix.log) |

[两条本地 Issue 工作单](evidence/rehearsal/issues.md) 展示复现、范围、负责职能、验收与关闭证据；已读历史 issue 去重，没有向远端发布或改关闭状态。

## 同候选结果

| 检查 | 实际结果 |
| --- | --- |
| 9个 skill | 官方 quick_validate 全部通过，32个文件安装后逐字节校验；两项新职能另有独立前向走查 |
| 仓库与 Harness | 链接/需求DAG/架构边界通过；28项工具测试通过 |
| Flutter | 52项host文件库/unit/widget通过；格式0变更，静态分析0问题 |
| 干净源码构建 | 不复用生成文件/构建输出，按 lock 解析并构建正常 iOS 入口通过；临时目录已清理，共用 pub 包缓存 |
| 原生进程 | iOS26.4专用模拟器/debug，PID16314→16327→16341；三进程全部通过；专用设备已删除 |
| 生产门禁 | 当前实际 manifest 非零退出、allowed=false，正确拒绝缺少的生产证据 |

原生事实：第一次保存 completed A / failed B 后 queue=2；真正 terminate 再 launch，原 operationIds、seq、失败原因不变；fake 串行确认后 queue=0；第三进程 queue=0、sentOperationIds=[]。原始 [保存](evidence/rehearsal/native-saved.json)、[重启确认](evidence/rehearsal/native-recovered.json)、[再次重启](evidence/rehearsal/native-confirmed.json)、[OS 命令与清理](evidence/rehearsal/native-result.json) 可核对。正式 main 仍用 UnavailableTransport，不把模拟确认显示为真实上传。

[全量质量](evidence/rehearsal/quality-report.json) 和 [干净构建](evidence/rehearsal/clean-build.json) 对应同候选；[证据保全清单](evidence/rehearsal/preservation.json) 保留原路径与字节 hash，未改写原始报告。[独立 skill 走查](evidence/rehearsal/skills-forward-review.md) 发现窄测试入口不一致后补了 `run.py test --target`，其 [实际运行](evidence/rehearsal/scoped-test-report.json) 也已通过。

## 便利与边界

后续主控从短入口找到合同，用九个职能按需派工；各自写域降低冲突，工具给具体错误，review 自动转修复任务，恢复核对活 Agent/OS进程/锁与候选。日常入口是 `python3 harness/run.py test --target ...` 和 `quality`；原生持久化实测是 `native`，无需手动拷日志或抢占用户桌面。

观察到一次实施和多轮针对性返工，没有足够样本估计可靠率；没有把全部岗位常驻为九个 Agent。完整地图工作台、完整原生用户链、真机profile、资源/发布与外部交付仍需各自完成。私有仓库保护API403，CI/发布强制路径未部署，见 [当前生产拒绝原因](evidence/rehearsal/production-gate.log) 与 [能力审计](readiness.md)。这不阻止按已验证的体系继续开发，也不授予生产发布资格。
