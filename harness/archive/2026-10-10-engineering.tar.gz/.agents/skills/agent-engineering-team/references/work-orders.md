# 派工、回报和恢复

派工包含以下具体字段，不能只说“你负责 UI”：

```text
task_id / role / mode
repo / base_sha / contract_revision
需求 ID 和可观察完成条件
输入资料及仅读取范围
允许修改的文件，明确共享文件负责人
依赖、设备/构建资源租用
需要的 skills（存在的绝对路径或仓库路径）
验证命令/层级；外部副作用边界
结果文件路径
发现契约歧义或越界需要时，返回主控协调
```

工作 Agent 回报：任务 ID、实际源码 SHA 或未提交 diff 指纹、改动、命令/退出码/日志、需求 ID 判定、设备与数据来源、未验证项、阻塞、结果文件。参考 [结果模板](../assets/result-template.md)。主控保留任务级证据，不要求 Agent 回读整个历史。

回报随任务风险和产物规模收敛，准备任务通常一页即可：任务判定、关键输入/产物指纹、未验证项及审查入口。批量读取相关资料；不要把重复 cat/rg、完整读取脚本或所有来源内容再抄进 result，也不为纯读取操作逐条创建日志。共享输入清单由主控建立并最终核验完整性，工作者核对实际使用的输入和共享指纹；无需每个角色重复审计全部无关来源。

构建/测试、故障注入、设备进程操作、性能采样和外部回执保留实际命令、退出码与原始日志/trace，result 用链接引用，不能为缩短摘要删减验收证据。长证据清单只维护一份 manifest；复审引用已有清单和相关变更，避免多份复制。

恢复只读取 mission、decisions、backlog、最近 result 和相关代码；先验证对应文件仍存在和证据版本，再决定下一步。中断后的临时文件不能当已提交产物。

计划 backlog 可以暂未指派负责人。真正从 ready 到 running 前，主控必须补齐该行的 owner_agent_id、base_sha、source_fingerprint（有未提交输入时）、contract_revision、result_path、resource_leases 和 started_at；对应派工正文与任务行使用相同 task_id。不得拿空的计划模板充当已经执行/可恢复的任务状态。

如果运行时有 spawn/followup/wait 类协作工具，直接用它们；具体参数按当前工具 schema。不要编造 `agent run` CLI 或伪造 tool ID。若缺工具，记录为顺序执行，仍使用同一任务合同。
