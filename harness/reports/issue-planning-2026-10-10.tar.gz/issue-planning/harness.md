# P02 Harness / Issue planning review

日期：2026-10-10。模式：prepare；只审计并提供 issue 交付合同，未运行 build/native/quality、未操作设备/前台、未发布 GitHub。审查基线 SHA `3e0300848fcded055abcc47448c06a165d0472d6`、contract revision 4、输入 source fingerprint `4b9b79b0d7a60dfacb0062db53568e1a7efc5fa1459357190aefd5794ef547bb`。主控正在编辑合同，后续执行需记录最终候选，不能复用这里的输入指纹代签。

已读取仓库内 `harness-engineering`、`engineering-issue-authoring` 及其 references/template，另核对团队协议、测试、原生验收、性能、交付 skill、Harness README/mission/contracts/backlog/work、readiness/status/rehearsal、run/checks/native/state/gate/CI、现有 Flutter 测试与探针。Issue 发布/去重由主控执行；本审计未查询远端 issue 清单，不能作为 dedupe 已通过证据。

## 审查结论

完整原型 Flutter 实现可以建立子 issue 进入开发；现有 Harness 具有真实本地可靠性基线，后续应复验和增量扩充。不能将 X00–X04 全部重新写成从零建设，也不能以历史 N01/N02/T01 accepted 解锁新候选的完整产品验收。当前生产 no-go：完整地图/查询/返回/直接同步用户链、正式 UI 后台驱动、目标真机功能与 profile/release、资源许可/签名/交付、服务端 CI/release 强制接线仍缺证据。

计划可以通过 issue-authoring 内容审查，但实施前需主控处理四项依赖/关闭边界：X02 输出正式 UI 执行入口而不是重复探针；X03 拆开本地机械 gate 与远端强制接线；X04 不被远端保护缺口阻止本地恢复演练；E10 准备材料与生产交付分别判定，保持生产 no-go。

## 现状与可复用证据

| 能力 | 实际源码执行面 | 后续 delta / 证据限制 |
| --- | --- | --- |
| H01 | checks.repository 检查短入口/skill 链接、R ID 覆盖、DAG、写域与 done_when 存在；fingerprint 覆盖 Flutter/Harness/skill/CI 与指定合同来源 | 需求出现不等于行为/测试覆盖；尚不核验 real issue URL/依赖联动。prototype 仅指定 md/map-config 纳入 fingerprint，app.js/index.html/其他品牌资产未自动纳入；冻结来源需保存其快照或纳入候选合同 |
| H02 | SDK 3.44.2 固定；依赖 lock；app-workspace flock；独立 SQLite fixture；任务创建专用 iOS 模拟器 | 现有入口只原生 iOS simulator debug；完整产品配置/集成入口、可接受平台、真机租用需冻结。不能默认 Android 或真机已经支持 |
| H03 | stage exit/log/hash，Repository/Coordinator business events，Widget 用户操作；三进程探针 JSON/SQLite/PID | 正式 main UI 无驱动/截图/语义观测工具，产品 map/query/native flows 和性能 trace 未实现 |
| H04 | import/export/conditional/barrel 依赖检查，模型/data/UI 边界；数据/同步真实故障回归 | map、ViewModel 查询/返回来源、可见同步反馈合同尚未冻结；按实际新依赖增量检查 |
| H05 | host SQLite 首导入/整批回滚/终态/outbox/错 ack/确认失败，串行/pause/失败重试；widget 输入保留/键盘/lifecycle | 独立完整产品回归应补缺失行为与集成风险，不能复制现有 52 个测试；host 重开不能代替 OS 进程恢复 |
| H06 | 同次执行前后 fingerprint + 原始阶段 logs/hash；G1 quality-run 深检；production gate 负例；quality CI | gate 没接 release；私有仓库保护 API 历史 403 当前未重核；G2/G3/G4 schema 对完整产品覆盖/预算/许可子项不足；hash 证明完整性，不能独自证明业务通过 |
| H07 | OS flock，stage wrapper 继承 FD，TERM→KILL，PID/锁/候选/log-hash resume 检查；实际取消负例已有归档 | 新 UI/device/trace/服务工具须维护生命周期；模型 Agent 是否仍活由 collaboration runtime 核验，不能从 JSON job 推断 |
| H08 | 独立交叉审查、保留场景、8 类缺陷修复；正式 Harness 回归 | 新合同、skill/tool、map/native/trace 改动需扩受控及 held-out 场景；样本不足不宣称可靠率 |

`harness/reports/status.json` 记录本地 reviewed-source quality：33 Harness / 52 Flutter host-widget，通过指纹与输入相同；本审计未重跑。原生报告仍属于归档指纹 `89fa4461c961cc287f10665314c9e418da69bcddc721398f12e6c559683c1b25`，状态文件明确 `native_rerun=false`，不能归给本次完整产品候选。

## 当前真实命令与选项

| 命令 | 当前执行内容 / 接受选项 |
| --- | --- |
| `python3 harness/run.py preflight` | SDK 检查 + flutter doctor -v；不是安装/启动证据 |
| `python3 harness/run.py check` | repository + Python unittest discover harness/tests |
| `python3 harness/run.py quality` | repository、tooling-tests、sdk、format(lib/test)、flutter analyze --no-pub、flutter test --no-pub 全部 host/widget |
| `python3 harness/run.py test --target test/widget_test.dart` | sdk + scoped flutter test；--target 可重复，必须是 app/test 内已存在文件/目录；不是 integration_test/native 驱动 |
| `python3 harness/run.py build` | sdk + `flutter build ios --simulator --debug --no-pub` 正式入口；不会 install/launch/截图 |
| `python3 harness/run.py native` | sdk + 同种 iOS debug build，target=lib/harness_probe.dart；native.py 创建/启动专用模拟器，保存→恢复 fake确认→不重发三个 OS 进程，再删除自己创建的设备 |
| `python3 harness/run.py gate --manifest <path>` | 生产评估；失败 exit 1，日志/候选保留；只是 evaluator，不执行发布 |
| `--resume <run-dir>` | 同 command、同 fingerprint、旧 PID 已退出、lease 可重新取得、已 passed 阶段原 logs/hash 未变才复用；gate 每次重检，不复用 old passed |
| `--timeout <seconds>` | 每阶段超时，默认 900；不是设备配置或性能预算 |

首次依赖解析入口为 `cd app` 后 `flutter pub get --enforce-lockfile`。run.py 自身没有 pub-get、`--platform`、`--device`、`--configuration`、profile/release、native-integration、截图/语义、DevTools trace 参数；issue 不得把这些写成现成支持。`native.py` 有 `--output`、`--candidate`（required），`--runtime` / `--device-type`（默认 iOS26.4 / iPhone17Pro）；run.py 未转发后两者。直接运行 native.py 不获得 run.py 的 app-workspace lease，不能作为日常并行入口。新增入口/选项由 X00/X02 先实现并测试，再由验收消费。

质量阶段 format 当前只 lib/test；新增 integration_test 不自动获得该阶段格式覆盖，默认 flutter test 也不执行 native integration。不能用 `test --target integration_test/...`：当前校验会拒绝。

## 建议子 issue 合同

下列每项仍应由主控使用 issue-authoring 模板填入真实 parent/dependency URL；未发布时沿用稳定 ID。每项说明 current→target、范围、依赖/单写者、可观察验收及关闭证据，无虚构账号/排期。

### X00：完整产品候选能通过锁定环境和隔离入口重复运行

- 类型 engineering；R16/R17，H02；复用 E01 与现有 run.py 基线。当前只有 iOS debug/probe 路径，目标为 E00 冻结的实际平台、demo/local-client 配置的可复现入口。
- 范围：SDK/lock 复核、正式构建/测试配置入口、依赖与平台 preflight、工作树/数据/端口/设备操作隔离。共享 pubspec/lock/platform/启动配置由指定唯一负责人写，Harness 职能不自行改产品入口。
- 依赖 E00/E01 的当前候选审查；开发实现输入配置，Harness 实现 CLI 合同。不要要求 full product E07 才能验证环境。
- 验收：给定干净源码与锁，按记录入口解析/检查并构建目标原生正式入口；SDK 错配/配置缺失明确拒绝；两个竞争操作第二个拒绝并显示资源 owner；任务清理只清自己的设备/测试数据，保留业务库。
- 关闭证据：当前 source/SDK/lock/config/platform 指纹、run report 与完整 logs/hash、干净执行/冲突/清理记录。无法提供 Android/真机时准确记录支持范围，不写全平台完成。现有命令可用 check/preflight/build；新增选项必须先落地。

### X01：新产品依赖与需求→issue→测试证据联动由检查拒绝违约

- 类型 engineering；R01/R02/R04/R05/R17，H01/H04；当前依赖检查与 R ID DAG 存在，目标是接纳完整产品新增接口/依赖和已发布 issue 图。
- 范围：checks.py 与 test_checks.py，增量模型/data/UI/map 边界、实际 parent/subissue 和稳定 ID 关联、需求/测试计划覆盖、来源冻结。事务/身份行为依靠 E04/开发测试，不用字符串匹配 SQL 证明事务。
- 依赖 X00、E02/E04 当前合同；主控维护 project/*，Harness 仅消费这些文件。pubspec/接口变更按消费者复验。
- 验收：有效项目 check 通过；故意 cycle/missing issue-link 或 demand ID/缺测试计划、barrel/conditional concrete-storage 绕过均失败，报告文件/违约/修复入口；关键业务故障 fixture 实测拒绝终态/部分提交/错 ack。
- 关闭证据：check report/logs、违反样例前后结果、需求/测试表、独立审查。不能把计划表中的 planned 测试记录成已执行。

### X02：Agent 在后台驱动正式产品 UI 并读取同安装的持久结果与进程恢复

- 类型 engineering；R07–R14/R15/R17，H03/H05；当前探针只证明 SQLite slice，目标是正式产品后台 native UI + 业务观测支持面。
- 范围：harness/native.py 或最小独立模块、任务支持入口/原生驱动、结构化 logs/错误/截图或语义记录、进程与持久数据采集、trace 获取通路。产品受控 observability/fault hooks 缺失退回 E07 开发，不越界实现业务。保留现有 probe 作为 reliability 层。
- 依赖 E07 + X00 当前支持的原生入口。测试职能提供 fixture/injection 合同；此 issue 提供工具，不自签 E08 业务/ E09 性能结论。
- 验收：任务创建/租用独立设备；不激活 Simulator.app/用户窗口；通过正式 UI 保存一完成一失败→记录原 PID/operationIds/reason/queue→真实终止→同安装重开读取 UI与业务库；原始采集含候选/设备/配置/collector/time/hash。离线/底图失败与 demo/local-client 各可按合同控制，不伪造连网/上传；工具缺失明确 blocked。
- 关闭证据：实际后台驱动命令、UI 原始输出、业务 event/store、PID与操作回执、失败诊断、lease清理记录。只有探针通过不得关闭 X02。确需前台仅阻塞该步骤并依项目规则等授权。

### X03：完整产品生产 gate 拒绝缺覆盖、错层、旧候选和未强制接线

- 类型 engineering；R16/R17，H06；当前 evaluator + G1 原始日志核验成立，但完整产品要求/预算/G4 子项未机械校验，CI只quality。
- 建议拆 X03-local（机械 evidence contract + gate/负例）与 X03-enforcement（实际 CI/发布强制路径），分别独立判断。单个 X03 如不拆，必须整体保持 blocked，不能以本地 evaluator 通过关闭远端强制要求。远端部分依服务能力/目的地，而不是要求改公开仓库或购买套餐。
- X03-local 依赖 X01/X02 的实际报告 schema；测试/验收/性能/交付提供报告消费者合同。范围 gate.py/test_gate.py，CI/release共享文件指定一人写。
- 验收：G2 原始 native report 包含 R01–R14 适用 acceptance IDs 和逐项结果，probe-only/不全/blocked 不可标全产品通过；G3 查目标真机 profile 原始trace/工作负载/预算与release复核，而非只有 `real/profile` 字段；G4 分开 local/resource/connected（适用时）证据，不以局部通过掩盖许可/迁移缺口；G1 原始 quality report 全阶段与当前候选/hash持续检查。
- 反例：missing/unknown/skipped/failed/stale/mismatched/hash变更、web→native、debug/simulator→真机profile、fake→connected、probe→全产品、未覆盖需求、超预算、许可缺失、artifact/signature/authorization/destination错配必须拒绝。合成正向 fixture 只证明 schema。
- X03-enforcement 验收：读取当前服务端保护/可用发布控制状态；允许范围内部署可用路径；真实 failing check/缺证候选不能合并/发布，真实 passing 对应候选才解除。保存服务设置/运行回执。历史私有保护 API 403 只作历史约束，未经查询不可称当前已确认；未部署 `enforcement_deployed=false`。
- 关闭证据：local 正负例 logs＋schema审查；enforcement 要实际服务端状态/故意失败阻断/release路径证据。脚本/工作流文件存在与 manifest 的 `enforced=true` 自述均不等于执行强制。

### X04：新增 UI/device/trace 操作真正取消后可安全恢复且不重复派工

- 类型 engineering；R17，H07/H08；已有 Python lease/resume取消回归，目标只补新操作生命周期和团队恢复。
- 依赖 X02、新的 X03-local contract；不要硬依赖尚 blocked 的远端 enforcement 才能进行本地演练。生产仍依赖完整 X03。
- 范围 state/tests + 最小 runner支持；只由主控更新 work.json/核验 collaboration 活 Agent。不会另造调度器。
- 验收：在 UI启动/采集/安装/trace具体阶段真实 TERM或KILL主控，确保活子进程仍持 lease或被停止；新任务拒绝冲突；恢复核对活 Agent/PID、diff/fingerprint、日志hash、设备归属，不重派相同文件/设备；恢复不清业务库、不将旧 passed 保留给变动候选；新场景含至少一个未参与修改的独立场景。
- 关闭证据：中断前/后/恢复原日志、PID/lease/设备/Agent状态、重复派工拒绝、成本/样本数/失败与修正及held-out复验。只读历史板/文档写 resume 不够。

### E04：独立风险回归覆盖完整工作台而复用已验可靠性

- 类型 verification / test engineering；R01–R14 的相关 host/widget 风险。原依赖仅 X00 容易把“准备fixture”与“对最终实现运行”混一起：设计可在 E00/X00 后 ready，关闭必须消费 E02/E03/E05/E06/E07 最终候选。
- 范围新 app/test/reliability 与 support；read-only复用 repository_fixture 与已存测试，不重复写开发者文件、不代改业务。正式故障入口交 X02/E07，不由验收临时改程序。
- 验收：查询搜索/状态/等待取交集与不同总数、Haversine与tie-break、返回来源/滚动、Other说明、map状态/聚合/视口、Toast生命周期/保存后刷新失败、队列变化驱动查询，以及已有持久化/ack并发风险；Completer/SQLite trigger 等受控注入，缺陷保留最短复现并修复后跑相关正常链和held-out风险。
- 关闭证据：对应 R ID 正常/失败/恢复表、最终 `test --target ...`/quality raw report/exit/loghash、缺陷前后证据及未测 native项。测试设计完成不等于 E04 最终通过。

### E08：独立验收正式原生完整用户链与同安装真实进程恢复

- 类型 verification；R01–R14；依赖 E07/G1质量与构建、E04 fixture、X02正式UI执行面。验收者与对应实现者独立，写域 runs/E08，只输出证据与缺陷。
- 验收：30站首启24pending/3completed/3failed，地图落点/聚合/列表最近项查询一致；完成/失败/Other、保存失败输入保留/重试、初始失败来源；列表来源返回原搜索筛选滚动，地图/最近项回地图，系统返回一致；直接同步各配置Toast/重复触发/暂停/错误；离线多结果→真实终止→重开原因/身份/queue保留→demo fake匹配确认/local-client待服务；无底图/缓存缺失/视口恢复与清瓦片业务不丢；SafeArea/键盘/文字缩放/语义/减少动效。
- 关闭证据：逐 R/acceptance ID passed/failed/blocked/not_run 原始native动作/UI/store/event/PID/时间/hash、实际SDK/设备OS/build/config、失败复现与回测。OS断网和应用内开关分别记录。缺适用目标真机项保留blocked，不用probe/Web/hot restart代签。工具缺失交X02，业务缺陷交开发。

### E09：目标真机按明确预算 profile 并以 release 复核工作台性能

- 类型 verification；R15；依赖 E00 device/capacity/预算冻结、E07候选、X02 trace/后台资源操作。不能用代码/模拟器猜性能。
- 范围 runs/E09，性能reviewer输出热点证据与开发修复单；不改接口/pubspec/SDK。
- 验收：指定最低设备/OS/刷新率，30站及约定容量、地图受控来源、网络/缓存一致；独立冷进程启动到业务可操作/地图可用分开测；地图拖缩聚合/列表搜索/保存同步Toast UI与raster帧、内存heap/external/RSS可得项、重复循环与稳定闲置趋势；真机profile原始trace，release体验复核；明确预算和样本数，足样本才报p95，超预算修复后同条件重测。
- 关闭证据：设备/候选/config/工作负载/采样协议/trace hash/指标摘要/预算判定/release记录/热点回归。预算临时值provisional、缺真机或缺trace blocked，不写measured_pass。公共瓦片不能用于无授权批量压测。

### E10：保留数据升级/资源许可与候选交付材料可复现，生产关闭另受硬门禁约束

- 类型 release-handoff / verification；R01/R13/R16/R17，G4/G5/H准入；依赖 E08/E09/X03/X04 当前候选证据。
- 建议拆 E10-preparation（说明/许可/迁移/manifest准备）与 E10-production（实际签名与授权目的地交付）。用户目前仅授权本轮真实issue发布，不由计划/skill自动获取发布产品、签名账户、购买地图服务、发他人等授权。原有生产任务不能改名为local交付来关闭。
- preparation验收：记录demo/local-client与connected边界、测试数据与服务权利、地图署名/tiles/offline条件/依赖许可；适用schema升级用已有结果/outbox旧库、不中途清库，回滚兼容或前滚恢复明确；README按锁复现，manifest将每个scope与证据层级/缺口如实填写。
- production验收：所有必需 H01–H08 demonstrated + 适用G0–G6实际passed；同候选release产物hash/production签名/版本渠道、安装运行、有效授权目的地及匹配交付回执；执行gate成功且真实发布路径强制调用。任何partial/blocked/not_run/stale/未接线均no-go。
- 关闭证据：准备交付可独立接受其真实材料；生产仍要当前manifest/gate原始logs、签名/hash/回执与外部实测。不可因CI/PR合并、本地包/上传请求或合成fixture成功关闭生产issue。

## 最小联动与派工顺序

1. 主控/requirements-extract 冻结 E00 的完整产品平台、demo/local-client、来源/候选版本、接口单写者、预算状态；issue-authoring 将需求→稳定ID→真实Issue URL写回同一backlog，不另造平台。
2. development 为 E02/E03/E05/E06 建必要测试；testing E04 并行设计独立故障和UI/查询风险；Harness X00/X01 增量提供入口/机械反馈。共享pubspec/schema/navigation/主题/CI由指定人串行写。
3. 主控 E07 集成当前候选，quality/build在lease下串行；X02先交正式native后台观测；E08独立从用户链验收，E09取得真机和预算后同设备串行profile/release。缺陷回development，工具缺口回Harness，证据不足补采不改业务冒充。
4. X03-local并行校验报告schema/负例，X04实取消恢复；X03-enforcement核验外部控制能力并实接线，未满足保留blocker。每次改变skill/工具/合同触发相关held-out回归。
5. release-handoff E10固化当前候选与原始 evidence index；主控仅据raw logs/hash/独立结果accepted。生产部署前H01–H08/G0–G6及真实强制路径全部具备；当前no-go继续有效。

每条子issue包含：来源R ID、parent、depends_on/blocks真实链接、负责skill→消费者skill、单写域/lease、可用或待实现命令、验证层级/闭合证据、blocked解除条件。Github subissue父子关系不自动满足工程depends_on；共享任务板ready只由依赖accepted+合同冻结+资源可用决定。
