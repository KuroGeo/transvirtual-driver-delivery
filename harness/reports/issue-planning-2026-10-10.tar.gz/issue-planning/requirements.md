# P01 需求增量与 Issue 拆分审查

角色：requirements-review；mode=prepare；只审查并建议，不实施、不构建、不发布远端 issue。审查基线：`3e0300848fcded055abcc47448c06a165d0472d6`，合同 revision 4。协作时 `work.json` 已由主控更新为本次 issue-planning；其余判断来自上述基线源码。

实际使用仓库 `engineering-requirements-extract`、`engineering-issue-authoring` 及提取/Issue 标准、模板；按主控 2026-10-10 指令保留 18 个子项：E00–E12（新增 E11/E12）与 X00–X04。主控负责冻结合同、共享任务图、Issue 正文和发布。

## 审查输入与证据边界

- 当前用户范围、AGENTS、`harness/README.md`、`harness/project/{mission.md,contracts.md,backlog.json,work.json}`、`harness/reports/{readiness.md,status.json}`。
- `docs/assignment/brief.en.txt` 与实际 CSV；`docs/solution-design.md`（尤其 1.1、3–5、7–9）。
- `prototype/{README.md,map-design.md,feedback-design.md,direct-sync-design.md,origin-return-design.md,index.html}` 以及 index 实际加载的 `assets/{app.js,map.js}`；不以历史图片或测试数量推断实现。
- `app/pubspec.yaml`、模型、SQLite、协调器、启动装配、ViewModel、列表/详情、现有 host/widget 测试与 README。
- 对 `KuroGeo/transvirtual-driver-delivery` 做了只读 `gh issue list --state all --limit 100`：#1–#10 全部 CLOSED；正文是旧 take-home 设计/时间盒/暂停编码/同步抽屉方案。它们是历史范围关联，不能按关闭状态判定当前完整原型已交付。后续新 Issue 用“替代旧范围/关联历史 #N”解释增量，勿重开旧题目或复制已作废的限制。
- Memory 只用于定位“网页证据不能代签原生”既有规则，已用当前原型/架构/源码复核。来源：MEMORY.md:50–54；thread IDs `01a121f6-ebdf-7343-91fa-bb3ec87f93ac` / `01a12295-94c6-7c22-aa83-3413de674ab1`。

当前质量档案记录 52 Flutter host/widget、33 Harness 回归和 PR #13 CI 通过；这批审查未运行测试。历史原生探针为 iOS simulator debug、独立 fake、3 个真实 OS 进程；它没有验证当前完整地图产品入口，不能用于关闭 E08/E09/E12。当前生产 `no-go` 保留。

## 源冲突与合同决议

1. 最新 `direct-sync-design` + `origin-return-design` 优先：左侧按钮直接同步、Toast、最近站点入口、详情按进入来源返回；旧 map/feedback 文档中的同步抽屉、Recently synced、底部 Map/Sync 页签不进入新实现。
2. 图标采用最新第一版橙底圆环箭头，不采用反馈旧稿的折线路径箭头。鲜橙/奶油白/深棕、本地字体与状态符号沿用原型；现有 Flutter 蓝灰主题是基线，尚未一致。
3. `Waiting only` 在当前 index/app.js 没有产品控件；它由架构 §7.1 和 R08 提出。按主控决议保留为明确标注“架构增量”的过滤条件，勿声称是原型已有 UI。与状态、搜索取交集；总队列数不得变成过滤匹配数。
4. 原型 Offline 是应用内演示开关，与 OS 网络、地图可用、真实服务独立。demo/take-home 明示 fake、固定参考位置/朝向；local-client 保持 unavailable，联网不伪确认，不发送样本到真实服务。
5. 原型完成/失败后保持当前详情，显示终态结果与依来源返回按钮。现有 Flutter `_submit` 成功自动 pop 不符合该行为，需要 E11 修正。失败表单取消回详情；保存失败保留选择和输入；已经 commit 后刷新失败应重读恢复，不把已保存结果当成失败。
6. 原型不保存视口，架构明确要求跨冷启恢复最后落盘的有效视口；这是架构增量。会话内搜索/筛选/滚动保留，冷启进入地图、All、Waiting only 关闭、搜索清空，临时 Toast 和 busy 不恢复。
7. 原型在切 Offline 后丢弃未落盘 fake 返回；架构允许已发送的匹配确认完成收尾，再停止下一项。原生以架构的可靠确认语义为准；须在 E05/E08 注明在途 ack 例外及后续发送停止，不复制浏览器 timer/token。
8. 旧 #1–#10 的 4–6 小时、固定面试设备、旧 event_id/wakeRevision/独立 mock DB 都不是当前完整产品默认约束。性能设备/容量/预算待 E00 冻结；真实后端、账号、路线/ETA、Agent、照片/签名、持续后台上传不进本次功能范围。

## 字段与缺失行为：必须写进 E02/E11

- 实际 CSV 包含 `time_window`。现有 parser 忽略此列，Stop/SQLite 无对应字段。完整原型显示时间窗；保存来源值，不编造配送日期，缺失值明确显示来源未提供。升级旧 v1 库时不清库/重导；要明确是否按已识别来源 reference 安全补全旧站点时间窗，否则保留缺失及来源说明。
- 失败选择为 `Recipient unavailable`、`Business closed`、`Address not found`、`Other`。前三项使用选择作为 reason，trim 后 optional note 独立保存；Other 用 trim 后非空说明作为 reason，原型独立 failureNote 为空。未选择原因/Other 空白不提交，不改变 stop 或 outbox；初始 failed 缺原因保持来源未提供。
- 现有 Stop 与 PendingUpdate 只有 reason，没有 note/timeWindow/发生时间、确认时间的可读投影或 Dataset 来源元数据；SQLite 有 acknowledged_at，但不投影到 Stop。E02 应冻结所需最小字段和 schema 迁移，保护已存在 stopId/datasetId/operationId/seq/结果/队列。不可恢复的旧 note 不补造。
- 新 note/发生时间必须随结果与不可变 outbox 同事务；retry 不重新从 UI/可变 Stop 拼 payload；ack 仅记录原结果确认。选择/草稿属会话，持久结果属业务；临时输入无需跨进程恢复。
- settings 提供少量配置（demo Online/Offline、有效视口），地图不持有 SQLite；业务库与可清瓦片缓存分离。强杀恢复以最后 commit 值为准；设置写失败不得先改变连接/视口的持久承诺。

## R01–R17 覆盖与复用

| ID | 当前基线可复用 | 完整客户端仍缺 / 主子项 |
| --- | --- | --- |
| R01 | 整份 CSV 校验、原子 seed、文件库 reopen 不重导 | time_window/note/来源/settings 新 schema 与旧库迁移；E02/E04/E08/E10 |
| R02 | Repository pending 条件更新、逻辑终态拒绝、原子防重复 | 新详情保持终态/来源返回，变化字段不破坏守护；E02/E11/E04 |
| R03 | trim reason 必填、初始失败来源未提供、保存失败保输入 | 原型四选项、Other/optional note、表单返回/键盘；E02/E11/E04/E08 |
| R04 | stop+outbox 同事务，commit 后反馈；rollback 回归 | 扩展 note/时间不变量，地图/详情只能在 commit 后更新；E02/E11/E07/E04 |
| R05 | 稳定 operationId，三身份 ack 验证、确认/出队同事务 | 新 payload 投影/时间展示、设置/升级不改身份；E02/E05/E04/E08 |
| R06 | single Future、seq 串行、pause、错误 finally 释放 | 实际未完成 Future 的超时约束、Online/Offline 自动触发/恢复、进度语义；E05/E04/E07/E08。当前测试仅主动抛 TimeoutException，不证明挂起请求会超时 |
| R07 | 存在原坐标字段 | 地图主页、聚合及计数/语义、状态符号、点击和工具；E06/E07/E08 |
| R08 | 全量 stops/outbox 可读 | case-insensitive customer/address/reference 搜索、状态/Waiting only 交集、地图/列表/最近项一致、global vs matched counts；E03/E06/E07/E08 |
| R09 | 原坐标已导入 | 固定参考箭头/35°、Haversine、不变源顺序、reference tie-break、距离单位；E03/E06/E08 |
| R10 | 基线 Navigator 返回列表 | 显式 list/map 来源、列表搜索/筛选/滚动/焦点、map/nearest 直接回地图、系统返回；E11/E03/E07/E08 |
| R11 | 手动 sync 和简单 text 错误反馈 | 地图左按钮+无队列/离线/进度/中断/写确认失败/完成 Toast，不抢焦点/镜头、不加抽屉；E05/E07/E08 |
| R12 | 历史独立 probe 3 真进程保存/恢复/确认 | 产品正式 demo/local 入口真实用户链、Online 保存、note/timeWindow/视口/相同队列恢复；E05/E08/X02 |
| R13 | 业务本身无地图依赖 | 无底图标记/列表/保存可用、重试、有效视口/caches、清图缓存保业务；E02/E06/E08/E10 |
| R14 | 基本 SafeArea/键盘滚动、部分 widget/lifecycle 测试 | 原型品牌/图标/字体/轻动画、SafeArea/缩放/无溢出/减少动效/系统返回/Toast避让；E01/E06/E11/E07/E08 |
| R15 | 无完整产品/真机基线 | 设备/刷新率/容量/启动帧内存预算先冻结，profile+release 实测；E00/E09/X02/E12 |
| R16 | SDK/lock、host+CI质量，release说明基础 | 候选绑定原生/许可/升级/产物文档、local handoff 和生产门槛分开；E01/E07/E08/E10/E12/X03 |
| R17 | CLI/lease/fingerprint/hash/负例/真实取消恢复已有 | 产品 UI/trace 可观察、更新机械规则、CI/发布强制门禁、完整用户链；X00–X04/E07/E08/E12 |

## 建议 18 个独立验收子 Issue 与缺失验收句

下表是每个 Issue 的行为增量及建议依赖，正文仍须逐项使用 issue-authoring 模板填写来源/当前情况/共享边界/验证/关闭证据。同名 E/X 稳定 ID 延续；原已完成基线记录为 reuse，不能把新完整范围直接标 accepted。

| ID / 结果 | 依赖建议 | 必须补入正文的验收与关闭证据 |
| --- | --- | --- |
| E00 冻结完整客户端输入与接口 | 无 | 18 子项覆盖 R01–R17、源码/合同版本、demo/local-client、目标平台、设备/容量/预算状态；冻结 Query/Navigation/Settings/MapConfig/Sync progress；需求/来源冲突逐项决议，不以准备资料宣布产品通过 |
| E01 增量原生装配、地图依赖与品牌资产锁定 | E00 | 保留现有原生壳/3.44.2 SDK；实际解析地图/聚合/坐标/版权链接依赖与 lock、新入口配置隔离、本地品牌/font/icon 接线；新候选目标构建，不声称真机通过；pubspec/lock/平台/主题/入口负责人唯一 |
| X00 可复现完整客户端执行环境 | E01 | 保留既有 CLI/专用模拟器/lease；验证新依赖、新 demo/local 入口、隔离业务容器、后台执行与只清任务资源；未确认设备/许可保持明确阻塞，不挡独立 host 开发 |
| E02 字段、settings 与保数据升级 | X00 | 上述 time_window/note/最小来源/确认投影；v1→新 schema 真实文件库升级保护 IDs/seq/原因/outbox、迁移失败可重试；settings 写失败一致；Stop 与 outbox 新快照事务一致；旧测试继续通过并加迁移/新字段 rollback |
| E03 统一查询、列表与最近站点 | X00（消费 E00 冻结的新模型替身，接线依赖 E02） | 搜索 trim/case规则，status+架构 Waiting only+搜索交集；全局队列/全局状态数/匹配数区别；地图/列表/最近项共用 result，无匹配为空，30站基线 Silverline 2.4km、Redwood 2.5km、Skyline 3.5km，reference稳定tie-break；排序不改原始数组；查询/位置变化才失效 |
| E11 详情、失败表单与来源返回 | X00（消费 E00 契约，整合依赖 E02/E03） | list/map/nearest 显式来源；关闭/箭头/终态主按钮/system back一致；列表保搜索/筛选/滚动与焦点，保存后被筛除时有稳定 fallback；完成/失败留详情，terminal无写动作；四选项+optional note/Other必填，取消回详情、保存失败保草稿；widget与原生证据分开 |
| E04 独立关键故障与行为回归 | X00 | 复用已有真实 SQLite fixture，扩展 v1迁移/new fields/settings写失败/挂起超时/在途暂停/查询返回/保存后刷新失败；隔离测试文件，覆盖 R03/R08/R09/R10/R11/R13，不只数据；先写合同，E07对真实新实现执行，fail→rework |
| E05 demo/local 配置与同步生命周期 | E02 | 明示受控 demo fake/Unavailable，Online状态先落盘再生效；启动恢复 offline不发、切online自动 drain、新保存自动触发、重复触发一个串行循环；timeout实际释放、stableIDs、匹配确认落盘才降数量；pause只阻止下一项；typed progress/error供E07；无真实后端承诺 |
| E06 地图聚合、视口/缓存与原型品牌 | E03/E01（地图 settings 接线依赖 E02） | 原坐标/状态+数量+语义/聚合点击展开；zoom/fit-matching/locate/nearest入口；固定参考箭头明示，no GPS；有效 dataset/provider范围视口重开，坏视口fallback；加载/无网/瓦片坏/重试仍能列表保存；仅清图缓存保业务；原型第一图标/橙奶油/本地font、SafeArea/键盘/文字放大/减少动效；许可provider标识与缓存策略实施核验 |
| X01 更新机械边界与需求覆盖 | X00/E02/E04（产品 UI/Map/同步规则最终运行依赖 E03/E05/E06/E11） | 更新UI/数据/模型/Map边界、单写者、schema/settings与不可变payload规则；违规fixture真正被拒绝；不靠简单源码字串声称所有业务通过；需求DAG与真实Issue映射有效，日志具体 |
| E07 真实接线、直接同步反馈与候选质量 | E02/E03/E04/E05/E06/E11/X01 | 串行整合唯一Repository/Coordinator；直接左按钮+所有Toast状态/位置避让/无抢焦点镜头/无抽屉；进度不重建地图控制器/反复排序；commit后刷新失败重读；实际业务事件/受控入口供X02；精确候选quality+target build，公开版本/fingerprint日志，后续更改重验 |
| X02 完整产品原生UI/进程/trace观测 | E07 | 驱动产品入口的实际操作与可读语义/业务事件/持久快照/PID，而非只跑独立probe；可导出相同候选/设备信息；后台自动化无法完成才记具体foreground阻塞；性能trace准备但不冒充E09；不反改产品，缺入口交E07返工 |
| E08 独立原生用户链与进程恢复 | X02/E04 | 从实际UI offline→多项完成/失败+note→真terminate→same container relaunch→相同IDs/seq/结果/settings→online串行确认；地图列表/最近详情返回、空/Other错误、禁网底图/清缓存、缩放键盘/减少动效、local unavailable保队列；候选/设备/OS/截图与原始记录，simulator只计G2对应范围 |
| E09 真机性能基线与热点回归 | X02/E00 | 先明确设备/刷新率/容量/密集点/预算；首次业务可操作与底图时间分开；profile UI/raster/内存、缓存命中/缺失、drag/zoom/search/list/save/sync组合+release复核；受控tiles负载；缺真机blocked，不复制30站/debug指标 |
| X03 当前候选门禁与实际强制路径 | X01/X02 | local/production要求真实区分；原始quality report/hash与新产品原生证据绑定；缺失/旧版/错层/fake→connected/未签/无授权实际拒绝；private保护403作为外部条件，明确可用替代强制路径需实跑，不称已enforced |
| X04 新完整客户端中断恢复和独立评测 | X02/X03 | 保留既有flock/SIGTERM/KILL回归，追加新UI/构建/原生工具重入与候选变化；实际取消后重派检查活负责人/diff/资源；独立未参与优化的失败链→修复→重验，量化工具成本；不能用合成绿色正例代替能力证明 |
| E10 local/demo 交付与运行材料 | E07/E08（本地适用Harness/许可/恢复证据齐全；不硬依赖E09/X03生产enforcement） | 当前候选源码/lock/原件hash/升级测试/地图SDK字体图标许可/在线provider限制/精确入口与目标命令/质量及G2原始证据；演示与服务待接入界限；产物hash/实际解包复核（若打包）；明确真机/生产仍no-go；不得自行外部发布 |
| E12 生产发布就绪与上线门槛 | E08/E09/E10/X03/X04 | H01–H08/G0–G6按delivery配置实际证据、商业数据/地图授权、签名release/hash、授权目的地/真实回执/现场验证；缺真机/服务/强制接线/授权blocked；本Issue只准备/核验，不把用户本次“提Issue”当上线授权 |

## DAG 与所有权注意

- 主链：E00→E01→X00；X00 后 E02/E03/E11/E04 可以按冻结替身并行；E02→E05；E01/E03→E06；X01/E02/E03/E04/E05/E06/E11→E07→X02→E08/E09；X01/X02→X03→X04；E07/E08→E10；E08/E09/E10/X03/X04→E12。
- 若板只支持硬 `depends_on`，E03/E11/E06 的合同替身阶段与真实接线需用正文里程碑区别；不要让E02整个存储实现阻塞先写独立UI，也不要在E07之前声称实线已验收。
- E02 owns models/schema/settings/Repository；E05 owns coordinator/transport；E03 owns query/ViewModel，只在明确冻结后消费 E02；E11 owns 详情/表单/导航调用；E06 owns MapView/viewport events；E01 owns pubspec/lock/主题/平台/启动装配；E07 归还写域后整合启动与 ViewModel。现有 E02 write_scope `data/delivery` 与 E05 同步文件有重叠、E03 `ui` 与 E06 地图/E11 详情有重叠：派工前收紧具体文件写域或安排串行。
- 主题、导航、settings接口和schema都是共享边界，不能让UI/Map各自行定义；合同修改须由单一负责人通知消费者并触发X01/E04复验。
- 每个Feature Issue关闭需要开发版本与独立E04验证；E08/E09独立验收对应原生/真机层；E10交付材料不代签生产，E12仍保持当前no-go直到实际证据齐全。

结论：资料足以直接起草并发布父Issue+18子Issue。最重要的增量是时间窗/note/升级、完整查询与地图、终态留详情/来源返回、明示demo自动同步/直接Toast，以及把local交付和生产上线门槛拆开。没有产品实施或上线完成声明。
