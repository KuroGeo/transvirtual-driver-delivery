# P04 独立 Issue / Harness 审查

2026-10-10，prepare；审查 revision=5、19 条 `harness/project/issues/*.md`、backlog/mission/contracts 及当前 run/checks/native/gate/state/CI 支持。只读检查 + 本结果文件；未 build/native/foreground/GitHub/新增 Agent。

结论：条件通过，发布前澄清下面 B1 并补齐 B2 的实际文件；其余计划命令、依赖、单写边界、证据层级与 Skill 接力满足可执行 Issue 标准。主控负责真实父/子/依赖 URL 回填；本结果不证明远端已创建或任何功能已交付。

## 发布前修正

- **B1：X02 缺真机不得隐式堵住本地交付链。** X02 验收“缺工具/真机/需要前台权限明确 blocked”，而 E08/E10 必须等 X02 accepted；E09 又明确缺硬件不阻塞 E10。请明确 X02 本地验收为后台 iOS simulator 正式 UI/进程/持久数据可操作，提供 trace 入口/采集协议；真机实际 profile/release 与性能判定交 E09。不能因缺真机将已经通过的本地 X02 整体 blocked；正式 UI 后台工具缺失则 X02 本地确实 blocked，不能用旧 probe 关闭。
- **B2：mission/contracts 已链接 issue-plan.md，但读取时该文件不存在。** 主控发布前生成并使链接检查通过；属于入口可发现性缺口。若主控正在生成，完成后复核即可。

## 核验结果

- JSON 读取检验 19 稳定 ID；DAG 无循环/悬空依赖，所有 draft 都包含对应 depends_on。通过传递依赖检查，未发现允许并发且写域重叠的任务。E01→E07 装配、E02→E05 services、X00→X02→X04 工具/test/native、E04→E07 integration support、E10→E12 README 都有串行路径；派工仍须真实归还写域/lease。
- X03 本地 validator → X05 实际强制路径清楚分开；X04 仅依赖 X02/X03，不依赖 X05。E10 的本地 demo/client 与 E12 生产原责任明确；E12 依赖 E10/E09/X05，生产硬门槛保留。历史保护 API403如实标历史，不称当前已验证。
- 现有 run.py 的 preflight/check/quality/build/native/test/gate 与 --target/--resume/--manifest 命令均正确；所有新增 test 目录/native UI/trace 标注待实现。未虚构 --device/--configuration/profile/release 参数。`test --target`只app/test、native仅probe、多处明确不能关闭E08/E09；完整UI入口由X00/X02先交回。
- E08 必须正式用户UI + 原生同安装三 PID/store/events/R01–R14 matrix；probe/Web/hot restart不可代签。E09 指定真机profile、刷新率/容量/缓存/网络/预算、样本和raw trace，release复核；debug/simulator不可代签。
- X03 补 G2 acceptance coverage、G3 trace/预算、G4 local/resource/适用connected/升级，保留原 G1 quality-run 阶段日志核验；合成正向fixture只证明schema。X05要求真实服务端治理与故意失败阻断，不以workflow文件/manifest true代签。
- Skill生产者/消费者可追踪：E02模型/设置→E03/E05/E06/E11；E03查询/来源→E06/E11；E05进度→E07；E04测试fixture→X01/E07/X02/E08；E07诊断→X02；X02 UI/进程/trace→E08/E09/X03；X01覆盖→X03；X03本地→X04/X05；原生/恢复→E10，真机/强制→E12。缺业务入口返工E07，工具问题回Harness，验收不越界改业务。

## 实施时需保留的判定约束

1. X03 的“当前范围”用于哪些资料适用，不授权降低现有 production evaluator。保留 `test_scope_name_cannot_bypass_production_requirements`，任何 local/demo 标签不能把 G3/G5/G6、H06 强制接线从生产 pass 要求中删掉；本地 X03 accepted 是拒证能力通过，不是 allowed=true 真实生产资格。
2. E04 先在组件合并候选运行 G1，交 E07集成重跑；E04 accepted 不代表最终 E07同候选的独立测试结果已生成。最终质量报告必须属于 E07装配后的精确候选，原生/性能消费该版本。
3. E09/X05/E12 JSON目前 status=planned 且带blockers，正文说明 blocked。由于本轮全部是计划，未视为发布阻断；真正执行时 work.json 状态必须按实际 blocked，不可ready派发缺硬件/权限/授权任务。
4. Issue 来源链接固定基线 SHA，其 mission/contracts 是历史 v4，而正文声明本轮revision5待E00冻结；执行者须消费已发布/提交的revision5计划。发布后应补当前合同/issue-plan可访问入口并注明基线用于既有实现，不将旧链接误读为最新失败备注/返回规则。
5. 尖括号run路径必须先替换实际路径；X00/X02新增入口帮助/命令纳入README及Issue关闭记录。背景步骤无法执行时只阻塞该资源步骤，不抢用户前台。

审查没有将任何开发/原生/真机/远端发布判为通过；生产 no-go 持续有效。

## P04 修正后最终判定

已核对当前 X02/E07 草稿、backlog 与新建 `issue-plan.md`。B1 已修：X02 关闭以后台 iOS simulator 正式产品 UI/真进程观测为准，trace 提供接口/协议；缺真机只阻塞 E09/E12，不堵住 E08/E10；必需模拟器 UI 工具或前台步骤不可用仍如实 blocked。B2 已修：issue-plan.md 实际存在，mission/contracts 的链接目标已补齐。E07 已加独立 E04 职能在精确集成候选重跑新增 Toast/导航/配置故障，组件历史通过不代签。

**最终判定：通过，可由主控发布并回填真实父子/依赖回执；无剩余发布阻断。** X03 不得以 local/demo/scope 标签跳过 production 必需项和强制接线，建议主控补为显式 Issue 验收并保留 scope-bypass 负例。该建议不改变本次通过判定；生产 no-go 仍有效，所有实现和实测需后续按合同执行。
