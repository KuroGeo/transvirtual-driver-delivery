# P03 独立 Issue 需求审查

审查角色：independent-issue-review；mode=prepare。基线源码 `3e0300848fcded055abcc47448c06a165d0472d6`；审查输入为正在准备的合同 revision 5、`harness/project/backlog.json` 与 `harness/project/issues/*.md` 的 19 个子项，修订后追加核对 `issue-plan.md` 与 EPIC。对照 P01 需求审查、实际 prototype index/app.js/map.js、最新直接同步/按来源返回文档、架构以及仓库 issue-authoring 标准。

仅写本结果；没有实现、构建、原生运行、远端写入或额外 Agent。只读 Python 检查了 DAG/字段一致性，不把它当业务或 Harness quality 证据。

## 当前判定

**终审 accepted（仅 Issue 准备与发布范围），没有未解决的发布阻断项。** 初审 3 处合同缺口已经由主控修改，已逐条回读当前正文与 backlog acceptance 核验；下文保留发现与修正依据。19 子项 DAG 及正文/JSON acceptance 一致性再次通过，无须新增子项或修改 E04→E07 的正确依赖。

### 1. X02 缺真机会意外阻塞本地交付

位置：`harness/project/issues/X02.md:31` 与 backlog X02 acceptance。

现文为“UI/截图/trace 操作只能走实际可用后台工具；缺工具/真机/需要前台权限明确 blocked”。X02 是 E08 和 X03/X04 的前置，E10 依赖 E08/X04，因此设备只缺真机也会被按文字判 X02 blocked，间接阻塞已有 simulator 能完成的本地 demo/client。

修正：X02 的可关闭结果明确为完整产品 **iOS simulator UI + 实际 OS 进程恢复 + 可读原始证据**，所需后台 UI 工具/该目标访问确实缺失时才阻塞此子项。真机性能 trace 的实测由 E09 验收；X02 可交接口/采集命令与适用条件，缺真机记录在 E09/E12，不阻塞 simulator 的 X02/E08/E10。不要削弱原生用户操作/真进程门槛，也不要声称提供 trace 接口等于取得性能证据。

复验：已明确 X02 基于后台 simulator 正式产品 UI/真进程关闭，trace 提供接口/协议；缺真机仅阻塞 E09/E12，simulator 必需工具/前台依赖只阻塞对应步骤。**已修复。**

### 2. E06/E08 漏了已有地图工具和底图重试行为

位置：`harness/project/issues/E06.md:28–32`、E08 验收及对应 backlog acceptance。

实际 index 的地图控件包含 Zoom in/out、Show all matching stops、Show my location，以及错误状态下 Retry map background。E06 只约束 fit/recenter 不能乱执行，未要求这些可达控件存在或正确工作；E08 没有逐项操作。按当前正文可以缺这些原型已有功能仍关闭“地图原型功能一致”。

修正：补给定已有匹配集合→zoom +/- 改变缩放且不改业务数据；fit 在可用面积展示匹配站点；locate 将镜头移到明示的固定测试参考箭头；受控底图失败→Retry→恢复底图，原业务结果/队列/查询仍保留；正常查看无需自动抢镜头。用 widget 受控源与 E08 原生实际控件操作分别取证。参考方向是现有 map-config 的 35°，无设备 GPS/罗盘承诺。

复验：E06 已补 Zoom +/-、fit 当前匹配/无匹配稳定行为、locate 固定参考箭头、错误 Retry/受控恢复；E08 已补实际原生操作和底图恢复重试，原业务/数据保持约束仍保留。**已修复。**

### 3. E07 缺少独立集成回归的显式关闭条

位置：`harness/project/issues/E07.md:33` 及 backlog E07 acceptance。

contracts 说明 E04 先审组件、E07 集成后重跑，但 E07 正文仅要求 quality/build 和泛化的独立职能签层级。E04 在 E07 之前关闭，不能验证后来新增的真实装配和直接同步 Toast。若只沿用已关闭 E04 或让集成者自跑 quality，独立联动不完整。

修正：E07 明写“由独立测试职能在本次精确集成候选重跑 E04 关键业务/故障回归，并补真实接线的地图→查询→列表→详情、终态来源返回、direct sync/Toast 及确认失败链；提交版本/fingerprint、原始日志、需求判定与独立审查结论后才能 accepted”。保持 E04 组件回归先关闭，E07 依赖 E04 的传递关系，无须增加 E04 depends_on E07，避免循环。

复验：E07 已增加独立 E04 职能在精确集成候选重跑关键用户链及新增 Toast/导航/配置故障，明确旧组件通过不能代替集成复验；原始候选证据通用关闭条保留，DAG 无环。**已修复。**

## 已核对并可接受

- 19 子项是 E00–E12 与 X00–X05；只读 DAG 实际通过，无悬空 ID、无环。拓扑顺序：E00→E01→X00→E02/E03→E05/E11/E06→E04→X01→E07→X02→E08/E09/X03→X05/X04→E10→E12。
- R01–R17 全有消费者和验收职能；R01–R14 均覆盖 E04/E08，R15 由 E09 真机层闭合，R16/R17 明确 local/production 区别。每个 backlog acceptance、Skill 和写域均存在于对应 Issue 正文，未发现草稿/JSON 内容不一致。
- 复用已有 baseline，明确地图/查询/新迁移/配置入口仍未实现；所有正文为待实施/待验证。合同 revision 5 的未来 API 名由 E00 冻结，现有 source revision 4 的 Runner/native 限制有明示，未把计划接口当作已存在。
- 原型四原因、预设 optional note、Other trim 必填、time_window、v1 保身份/结果/outbox 升级、保存后终态留详情、list/map/nearest 来源返回、系统返回均已写入；最新 direct sync/圆环图标优先旧抽屉/旧图标。
- Waiting only、跨冷启视口均标明架构增量。demo fake/固定参考与 local unavailable 分开；实际挂起 Future timeout、pause 在途 ack、tail wakeup、失败不无限重试均可验收；没有新真实后端/账号/路线/Agent承诺。
- X03 本地 validator 与 X05 实际远端强制接线拆分合理；X05/E09 不在 E10 本地依赖链中，E12 保留生产 no-go/直接授权/签名及目的地真实回执。
- E04 已依赖组件 E05/E11/E06，X01 消费 E04，E07 再集成；任务状态和独立检查是实际 evidence 层，不以 Issue 关闭/PR 合并直接解锁。
- 共享写域均按依赖可串行归还：E02 的 data/services 与 E05 demo_transport；E03 ViewModel 与 E07；E04 integration_test/support 与 E07；X00/X02/X04 的 runner/native/tests；E10/E12 README。派工仍须实际 owner/lease 核对，不能把文件夹约定当自动保护。

结论：当前父 Issue 与 19 个子 Issue 可以发布，并按当前 DAG/单写者/Skill-Harness 接力推进。该审查不签 Flutter 实现、原生验收、性能或生产发布通过。
