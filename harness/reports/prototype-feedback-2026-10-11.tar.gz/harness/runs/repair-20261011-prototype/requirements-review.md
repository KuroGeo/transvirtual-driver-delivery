# 2026-10-11 原型四项 UI 修复需求提取

状态：只读需求提取，未实施、未执行 SDK/设备/浏览器、未签新候选 G1/G2。采用 `engineering-requirements-extract` 及 `references/extraction.md`。来源优先级为本轮用户明确指令 → 当前原型及最新直接同步/来源返回修正 → 旧实施合同。历史交付证据不证明这轮四项已经修复。

## 结论与冲突决议

| 修复 ID | 已确认要求 | 当前 Flutter 差异/证据边界 | 相关原需求 |
| --- | --- | --- | --- |
| UI-R01 | 左侧地图工具出现时始终按一列排列；包含 Sync，不在详情状态变成两列 | `_toolbar()` 当前两行各两项，Sync 占88px。原型自身有详情两列例外；用户新要求明确覆盖它及合同的2×2约定 | R07/R14 |
| UI-R02 | 可操作地图区域支持实际双指向外/向内缩放，保留单指平移 | Flutter 已设置 `InteractiveFlag.all & ~InteractiveFlag.rotate`，包含 pinch；静态不能据此证明实际可用或归因为禁用 flags | R07/R14 |
| UI-R03 | 顶部状态 Tab 点击在更新匹配集合后显式 fit 地图，包括重点击当前 Tab | `_status` 仅 `model.setStatus`；同查询 `_setQuery` 直接返回，且没有 fit。现 fit 只包围 stops，不含固定参考点；空结果不动作 | R07/R08/R09 |
| UI-R04 | Browse stops 使用原型底部整宽 sheet、固定标题/关闭、紧接连续站点行的层级与视觉 | 现面板相对 map area 左右8/top112（compact12）内缩、没有 grip、标题 Stop list、重复长搜索/筛选控制块，行把 reference 放在 customer 前。现行已连续分隔而非独立卡片，不应误报 | R08/R10/R14 |

用户没有要求修改 SQLite/outbox/ACK/设置持久化、最近排序、来源返回、直接同步或生产门槛。旧合同 `harness/project/contracts.md:97` 的“两列2×2工具+整宽Sync”应由主控更新；同段“query updates 不移动镜头”需要明确：**用户点击顶部状态 Tab 是显式相机动作；搜索输入、队列/ACK、通知和后台刷新仍不应自动 fit/focus**。Waiting 是架构扩展，不能说它来自原型，也不能因视觉对齐删除其功能。

## UI-R01：工具 CSS 的真实覆盖顺序

`prototype/index.html:1` 的样式顺序为 Leaflet/MarkerCluster → app.css → refined.css → map.css，因此最后的 map.css 覆盖必须纳入。

- `map.css:3`：工具起初 flex-column、43×43；背景 `#fffaf4`、边线 `#e7d8c5`、圆角14；加减25px、SVG19px；分隔线1px，横向留9px。
- `map.css:9`：移到左侧13px；列表 drawer 可见时隐藏工具。
- `map.css:27–29`：最终常态/搜索时 top365，详情 top250。这些坐标相对整个原型 phone，而非 Flutter 去掉 header/footer 的 map area。
- `map.css:47–49`：最后的详情可见选择器改成 `display:grid;grid-template-columns:repeat(2,43px)`，Sync 跨两列宽86px。**原型并非所有状态都是单列**。此次用户明确取消这个例外。
- `index.html:11` 顺序：Zoom in → Zoom out → 分隔 → Fit all matching stops → Locate → 分隔 → Sync（队列标记）。列表打开隐藏地图工具是原型现有行为，不等于要求工具盖在列表上。

建议验收：map、search、pending/terminal detail、tile-error/notice、常规和大系统字号下，只要工具显示，各按钮中心 x 相同、顺序不变、Sync 不跨列；每项真实目标至少44px（保留现 Flutter 可访问性合同，不回退43px）。工具必须处于实际安全/地图区域且不遮 Close、所选标记或反馈。五项44px单列加两分隔约222px，比旧约133px高；现 `toolbarTop=12` 和 compact `fitPadding.top=170` 不能不经测量照用。工具出现时的实际布局高度应参与 fit/focus/overlay 预算。

## UI-R02：双指缩放的原型与当前实现事实

`map.js:7` 原型使用 Leaflet，范围9..19、zoomSnap .25、滚轮启用，没有覆盖 `touchZoom`。锁定本地 `prototype/vendor/leaflet/leaflet.js:5` 合并默认 `touchZoom:Browser.touch`，注册 TouchZoom；触摸开始要求恰好两个 touches，然后按两点距离比例更新 zoom/center。因此原型在支持 touch 的浏览器走真实双触点手势，不是两个工具按钮代替 pinch。

当前 `delivery_map_workspace.dart:458` 包含 pinchZoom/pinchMove，且源中未发现包住整图的 AbsorbPointer/顶层 GestureDetector。业务 overlay 覆盖哪些实际区域、两个 pointer 是否同时抵达 FlutterMap、现依赖的手势阈值与竞争仍需真实复现；这里不推定故障原因。现产品合法持久 zoom0..22 不因原型9..19静默改写，这是旧可靠性合同，应保持。

建议验收：在真实可见、未被工具/详情/列表覆盖的 map 区域，两触点同时按下并分别移开/靠近，观察有限 camera.zoom 明确增/减；一指平移继续有效。只用 +/-、轮滚、单点 drag 或 directly moving controller 都不能签本项。检查 query/results、selected origin、业务数据库/outbox/ACK 无意外变更；地图手势仍按现设置规则保存 viewport。操作录据需保留两触点序列及前后真实 camera/OS 图面。单列工具改变可用手势区域，UI-R01 与本项要在同一根布局候选联测。

## UI-R03：Tab → 匹配集合 → fit 的精确链

`index.html:7` 四个 Tab 均调用 `setFilter`；`app.js:99` 同步更新 filter、关闭 detail，下一 tick 执行 `syncMap()` 后 `MapWorkspace.fit()`。没有相同 filter 的 early return，故重点击当前 Tab 也会重置镜头。它保留 search；现有 listOpen 不被此函数清除，列表打开时过滤列表并更新其后方地图。详情被 Tab 关闭属于此显式切换行为，不应混同按来源 Back。

`app.js:49/58`：status 与 customer/address/reference 搜索相交，所有匹配 stops 先按固定位置 Haversine 排序（R6371000），同距离按 reference；fit 不是只看当下镜头里的 pins。

`map.js:106–112`：收集 **所有 filteredStops + 固定参考位置**，`fitBounds` 左/右22，上正常260或 mapFailed350，下 `max(215,实际runOverview高度+65)`，maxZoom14、**animate:false**；若没有匹配站点，唯一参考点分支调用 locate（zoom14、投影偏移[0,35]，animate 随 reduced-motion）。这与点击 cluster 的 TL38/205、maxZoom15、可动画 fit 不是同一动作；不要混用。

当前差异：`delivery_screen.dart:624–646` 只改状态；`delivery_view_model.dart:103/122–128` 查询相同不通知；`map_workspace:294–315` fit 空结果 return，坐标仅 stops、maxZoom15。只加“查询变化时监听自动 fit”会错误移动保存/ACK/搜索镜头，也漏重复点击。

建议主控冻结消费合同：Tab 点击显式更新共享 query，按原型关闭当前 detail（保留已有 list 面板），待匹配和对应布局实际更新后发一次显式 fit；同 Tab 也发起。fit 所有当前交集和固定参考点，空匹配有确定 locate/fallback，不抛错。Flutter padding 使用其实际 map area、安全区域和可见覆盖层换算，不能把 phone 的 top260 与 Flutter header高度重复扣除。普通 fit 不动画；cluster/locate 可按真实 iOS reduceMotion / disableAnimations 规则保持现动效语义。两指缩放后的手动视口可由 Tab 明确重设；后台同步不得重设。

建议验收：先 pan/zoom 到排除匹配点的远处，点击 All/Pending/Completed/Failed，所有匹配点和参考点进入合适可见区域；再手动 pan 后重点击同 Tab 仍 fit。附带搜索交集、Waiting 架构扩展、零匹配、tile 503、list打开、detail打开分支；保留原全局队列计数，且后台 ACK/Toast 不触发相机动作。用真实 camera+投影位置+overlay rect 校验，不能只断言 callback 被调用。

## UI-R04：Browse sheet 和 row 的精确原型

`index.html:13` 的 sheet 仅在 listOpen 且 !detailOpen 且 page=stops 显示。`app.js:104` 打开只关闭详情并打开列表，不清 search/filter。`map.css:7/25/44` 最终整宽 left/right0、bottom0、height530、max-height `calc(100% - 260px)`、padding-bottom29；不是早期 bottom94/height470/max扣215/205。背景 `#fff9ee`、顶部圆角23、上边线 `#dccaaf`、轻上阴影；顶部 grip 的最终尺寸来自 refined.css:6 的32×3、map.css:7 将 margin 覆盖为10 auto8/颜色 `#d9c3a3`。在390×844原型 frame 常规字下是声明530px底部 sheet；未用浏览器测量，本报告不声称 OS 实际像素已一致。

固定 header padding9/20/18，标题 **Stops on the map**（22px/500/-0.7），副标题 **N stop(s) · Nearest first**（13px、上距5），关闭在右侧；只有下方 `.drawer-scroll` 滚动，底部留16，overscroll contain。原型 Close38×40，Flutter 修复应继续至少44。sheet 原动画 enter .32s、leave .2s，transform100%→0，reduced-motion CSS 禁用动效；不能为了截图等待用固定 sleep 替代实际完成观察。

row 是整宽可点的连续行，顶部1px `#ebddc8` 分隔，背景 `#fffaf3`、padding17×20、min-height112、左右内容gap12。左侧30px状态图形，客户名称为首标题（16px/550/1.5/-0.3），地址14px/1.5、上距4。metadata 上距9、字号13/1.5、gap纵5横12，顺序 **距离 → time_window（hyphen显示为en dash）→ 状态 → 若queued则Waiting to sync**。距离小于1000米显示整数m，否则一位km；尾部14px chevron。客户和地址允许折行；Completed圆形绿色、Failed圆角8红棕、Pending橙环。reference 用在 row identity/aria/customer+reference/search，不在原型可见首标题。空态为 No matching stops / Try another status or search term。

当前 `_StopRow` 已是整宽且 top separator，Haversine距离/编号同距排序和 waiting 语义也已复用；这些不是重写目标。主要差异：

1. 根 overlay 悬浮内缩且起点不同，未贴底整宽；无 grip。
2. 固定 heading 为 Stop list；未在原型 header 放 matched count + Nearest first。
3. `_queryControls` 重复 Search/4 status/Waiting/总queue文字，排在行之前，正常和大字都占据大量滚动空间；原型 sheet 无这一块，查询在顶部 map header 共用。
4. 行多 reference首行；customer weight600；metadata先 badge/status 后distance/window，与原型顺序和轻文字不同。不能将已存在 top-separator 行误称独立卡片。
5. 当前 compact将完整标题移进同一个 Sliver滚动，仅Close/Sync固定；大系统字号需要保留能读/滚/点击的自适应预算，不能以复制固定530高度使标题/rows完全无空间。

建议视觉合同：常规字号恢复 grip + 固定客户列表 heading/count/Close + 连续行，客户优先；共享 query 功能保持。若移动重复控件回原型 header，必须仍能使用搜索/status/Waiting，并保持可访问性，不能只删控制入口。直接 Sync 是已接受扩展，可用紧凑44px action但不能恢复旧抽屉。原型无可见reference首行；若保留编号展示的旧实施约定，应降为不抢客户标题的次要metadata/语义，由主控显式决议，不让它改变原型层级。

来源返回不变：`app.js:64–67`/`origin-return-design.md:5–8`，列表 row → detail → Close/terminal Back to stops/平台返回恢复原 query、scroll offset、所选 row focus；若当前不再匹配则Close焦点fallback。地图或nearest详情则回地图。打开 Browse 不擅自归零已有 listSession，不能以视觉修复制造“每次第一行”来掩盖 lazy list 恢复问题。Row排序一直按当前交集最近优先，不能按CSV顺序。

## 最小任务拆分与验收依赖（建议，未写共享板）

- 根装配/UI负责人：UI-R03 顶部明确意图/typed面板更新与 fit 时序；UI-R01/UI-R04 改变尺寸后重算真实 overlay/padding。共享 VM/API如需变化由单一根负责人冻结。
- 地图负责人：UI-R01单列、UI-R02实际手势链、fit参考点/空匹配/上限语义；避免重建 MapController/瓦片 provider 来“修复”摄像机。
- 列表负责人：UI-R04 sheet/row层级；保留 stable row keys、query/scroll/focus/无Navigation所有权；根同时只改装配区域，禁止双方写同文件。
- 独立测试先检查源码/布局及不变量，所有作者冻结后由主控 fresh quality；再在正式集成候选做真实双指、Tab fit、Browse/详情返回和普通/大系统字体图面。现34 native checks是否覆盖新pinch/反复Tab应由主控增补trace，不能把旧case存在当本轮已验收。

本轮不运行或重签现历史 CI/native/archive。原型网页数据/录屏只作设计输入，不能当 Flutter 修复已通过。

## 本次读取身份

读取 HEAD `68dcbabec7460e0ce2724b176b24213641158b8b`；记录时间 `2026-10-11T07:02:54.055757+00:00`。这些是读取时的源字节，不保证其他受托作者后续冻结字节相同。

```json
[
  {
    "path": "prototype/index.html",
    "bytes": 36444,
    "sha256": "c73848cce9368998b92759574df34083678abbff58cdd84058f48db816ff4000"
  },
  {
    "path": "prototype/assets/app.js",
    "bytes": 12573,
    "sha256": "707b71f93f347389b2f113b50267e4d922272e463272a73591eff229fa7a01ca"
  },
  {
    "path": "prototype/assets/map.js",
    "bytes": 7167,
    "sha256": "988e021e13ad0fc2fceec99b351a6a5c0423e7bf4687fe669e9d806b1740603b"
  },
  {
    "path": "prototype/assets/map.css",
    "bytes": 16861,
    "sha256": "81d6a4db7f283027e105d5f0e51ec3dc2301de34fd6297b500e32d03310d6c7e"
  },
  {
    "path": "prototype/assets/app.css",
    "bytes": 17937,
    "sha256": "5bb374710ac6c8dbc8e576139daf4b4ff3872264e29b8abc369d2c8f3887d2c7"
  },
  {
    "path": "prototype/assets/refined.css",
    "bytes": 22743,
    "sha256": "bbe58de2f720e3bd58017c8b1552c47713f84a394441603ba469d64ed66911d8"
  },
  {
    "path": "prototype/vendor/leaflet/leaflet.js",
    "bytes": 147552,
    "sha256": "db49d009c841f5ca34a888c96511ae936fd9f5533e90d8b2c4d57596f4e5641a"
  },
  {
    "path": "prototype/assets/map-config.json",
    "bytes": 413,
    "sha256": "4edf1af7fd1767684212383b9dca28fc982d717581954ec571c3102052adbf21"
  },
  {
    "path": "prototype/direct-sync-design.md",
    "bytes": 3526,
    "sha256": "17371d0236d1c1c95139a1d8351b84f9fcc937a9f197db72121cb9207e821b18"
  },
  {
    "path": "prototype/origin-return-design.md",
    "bytes": 1427,
    "sha256": "a256b49c9a40230b8ca4e4c57684d5bdbe5483cc145b64375af38a2c3b47fe61"
  },
  {
    "path": "app/lib/ui/delivery_screen.dart",
    "bytes": 39107,
    "sha256": "6ba05432c8123540b0de9b8d9d13b97d88bcdaafc9095565cea2a788b0a6feb9"
  },
  {
    "path": "app/lib/ui/delivery/map/delivery_map_workspace.dart",
    "bytes": 32823,
    "sha256": "57f8b9c8dfa7eb914fb0b12051206c35558eda8f03e8c75bd1101bb764834970"
  },
  {
    "path": "app/lib/ui/delivery/list/stop_list_workspace.dart",
    "bytes": 25024,
    "sha256": "6ad384b02e00cf363ce6302424d98d31bedb245f4c7344fd40de57d2a2519a0a"
  },
  {
    "path": "app/lib/ui/delivery_view_model.dart",
    "bytes": 18196,
    "sha256": "07bc5b1431b3d732e152f57f262f39e168471d233ed5e6fb48f8bfa83f78aee9"
  },
  {
    "path": "app/lib/ui/delivery/query/workbench_query.dart",
    "bytes": 3790,
    "sha256": "8094a43fc8b142817f213c2d65956950bea563ad9d9f57baa16385b7f0dbb477"
  },
  {
    "path": "harness/project/contracts.md",
    "bytes": 26888,
    "sha256": "3e4b6cd5bb3c5e739a9f584ebfad5d78461c5c70cd7ce98cdf1182c6a311a466"
  }
]
```
