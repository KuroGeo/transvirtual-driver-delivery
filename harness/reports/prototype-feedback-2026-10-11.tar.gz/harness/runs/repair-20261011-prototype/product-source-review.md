# 四项 UI 修复：独立产品源码复核

本轮职责为只读产品/合同与既有390×844原型 PNG复核；未执行 SDK/设备/浏览器、未修改产品、未自签新候选 G1/G2。工程需求按 `engineering-requirements-extract`，原始需求见同目录 requirements-review.md。

**当前判定：需返修一处确定的 notice 几何通知缺陷；另有两处明确原型分支差异等待主控决议。单点取景的初始工具交叠漏改已由主控修正，最终图面/多点 fit/真实双指仍待实际执行。**

## 确定需修复：新增 notice 预留区没有订阅 notice

`delivery_screen.dart` 新列表 height 条件读取 `model.notice.value`，根仅 `ListenableBuilder(listenable:model)`。`DeliveryViewModel.showNotice/clearNotice` 只改 ValueNotifier，不 notify model。`WorkbenchNoticeView` 自身监听 notice，因此内容更新，外层 sheet height 不更新。

可观察触发：常规字号、实际 map area≥500，Browse打开、queue0、没有现存notice → 点击 list-sync。`_requestSync(manual:true)` 的空队列分支只 showNotice('No saved updates to sync.') 后 return，根不重建。sheet仍从区域上端约12px开始；反馈也位于top12，于是反馈与 grip/标题重叠。反过来原有通知8秒自动清除也不会及时释放112px预留。此故障来自新尺寸条件，非泛化猜测。

建议根让决定 sheet 几何的 builder 订阅 notice；不必改变 Repository/VM业务通知语义。held-out场景验证空队列 list-sync 出现/自动消失的实际反馈、sheet/grip/title rect各自不交叠，匹配结果/会话/相机仍不变。

## 初始 compact 工具/标记交叠已修正；多点边界还须单独核验

当前工具5×44+1分隔=221px，left13/right57、top12/bottom233。初次diff只改无detail分支 top=min(258,H−68)，detail仍170；锁定 flutter_map8.3.2 `FitCoordinates.fit` 对单点 focus 给center=(57,(H+146)/2)，H≤364时44px标记与221px工具相交。主控现已把compact/error左右改left64/rightW−108，对**单点**center x86，44px rect64..108，52px cluster rect60..112，在工具right57和右卡left114之间。这处单点漏改静态已解决，不能继续沿用初始缺陷判定。

然而 coordinate-fit 的左右padding表示极值坐标可覆盖区，不保证**多点**都位于中心86。用锁定依赖公式+真实30行CSV、W390/H295、All+固定reference，静态Mercator计算zoom8.074127869；reference中心(93.8573,223.9924)，44px边界右115.8573，超过compact overview左114约1.86px。站点坐标极值x64/108，若未聚类其44px范围42..86/86..130；站点在此zoom通常聚类，不能以单站形状推定该原生case失败。以上是计算例，**不是实际运行结果**，实际camera rounding/cluster topology/覆盖高度须由真实图面确认。若继续保持“完整标记与overlay不交叠”旧门槛，需为多点坐标极值也留半径，或 overview fit另取可用区域；不能仅以x86单点证明All/Pending fit。

## 两处明确的原型分支差异

1. **顶部Tab从列表来源详情的去向。** 新 `_selectStatus` 调用 `model.closeDetail()`；该方法按 list origin 展开列表。原型 app.js:99 的 setFilter仅 detailOpen=false，openStop已将listOpen=false，所以此入口改Tab会回地图。已有列表正在打开时原型保留列表。用户要求 Tab像原型fit；来源返回合同约束的是 Back/Close/终态Return，不能自动据此断言Tab也必须来源返回。请主控明确采用原型显式切换语义还是说明本轮保留差异；避免无意把 fit 后地图藏在展开的sheet背后。现合同行“关闭详情”未声明目的地。
2. **零匹配Tab的locate zoom。** 新 `_fitMatches` 空匹配调用现 `_locate`，它 move(reference,max(14,currentZoom))。从zoom18点击空交集，结果仍18；原型空匹配locate固定14，当前合同的Tab maxZoom14字面也不覆盖此分支。此外 `_locate`绕过fitPadding，compact参考点在画面中央而非新leftlane，可能被右侧overview遮挡。按原型修正空匹配分支可与现手动Locate按钮合同分别处理；按钮仍disabled不影响Tab内部调用，但不能把disabled当空分支已正确。

## 其余源码一致性与真实截图对照

- 单列：zoom+/zoom−/Fit/Locate/Sync同44px宽，Sync真实动作沿用；showTools=!list保留Browse隐藏工具。原型详情2列例外已被用户新指令明确覆盖，合同已纠正，不虚称旧原型始终单列。原型有两处group divider，当前一处是轻微外观差别，不影响本轮核心single-column行为。
- 双指：flags仍all&~rotate，源级包含pinchZoom/pinchMove。没有新双指产品分支改动，也没有全层AbsorbPointer静态证据；真实双pointer事件抵达/缩放增减必须由新的集成/原生结果证明，原始配置不能签用户缺陷已解决。
- Tab：显式事件postFrame fit，不把后台query/ACK/Toast观察者改成自动fit；相同Tab也安排callback，保持搜索/Waiting交集。markers在didUpdateWidget更新，fit新result包含fixedreference、max14、CameraFit同步无动画；无需重建map/controller/provider。尚无本轮执行证据，本报告不假定callback计数等于所有点无遮挡。
- Browse真实原型 PNG已查看，390×844、SHA见下：sheet上缘约322，grip+标题 Stops on the map，副标题30 stops · Nearest first，首row客户Silverline Supplies，地址在第二层，第三层距离/window/Pending，连续整宽分隔，尾部小arrow。新list已恢复相应hierarchy/colors/grip32×3/radius23/min-row112/padding17×20及metadata顺序；reference进入Semantics，搜索仍按reference，stable row keys未变。与原型吻合方向明确，不能说已获得当前Flutter视觉截图通过。
- 新list默认隐藏长查询block，用44px显式list-query-controls展开；Sync/Close保持44px。两项是架构/直接Sync扩展，合同已明确；不是原型原本存在的三个header图标。compact保留标题在内部滚动和固定可点击动作，是大字适配，不能回退系统字号来获得像素相似。
- 外层position bottom0/left0/right0，height=min(530,max(0,actual mapH−notice reserve))；这是**地图区域**的底部，仍排除总是显示的footer，与原型整phone底部不同。原型CSS530/wholephone扣260/底padding29不是Flutter同坐标系；静态可以签整宽贴区域底，最终图面应明确这项自适应范围，不把声明常数当像素已一致。
- 列表sort/query、模型业务状态、outbox/ACK、save/restore方法未被修改；_queryExpanded没有在detail往返中重置，原query/滚动/focus恢复逻辑保留。原型同list restore后focusfallback、地图/nearest return保持区别，需新回归覆盖实际懒布局。
- StopStatusBadge新增showSymbol/textStyle默认沿用旧行为，list传false仅隐藏重复图形，仍提供Status语义，其他detail消费者没有被全局改色/去symbol。
- 根合同正确记录“user Tab是相机显式动作、后台仍保镜头”、“工具单列”、“额外query显式展开”。需补明确Tab list-origin/empty分支及notice几何订阅修正，不能在旧G1/G2当前身份上追加本轮通过。

## 证据身份与历史记录说明

读取基线HEAD为68dcbabec7460e0ce2724b176b24213641158b8b，产品diff尚未提交；主控在审查中有授权修正，以下为本报告写入时的源字节，后续修正必须重读/重新绑定。初始requirements-review.md的“当前差异”文字来自开始读取的旧产品，而末尾hash是在报告落盘时再次读取（期间作者写入了部分repair）。其产品hash不能被当作旧差异文本的同一稳定cut；本报告以实际diff和本次身份为准，不覆盖历史原件。

未运行任何SDK、format、pub、test、build、native、设备、浏览器。图片仅查看已保存原件；静态计算仅用于解释源码边界，不列作通过的测试。

记录时间 `2026-10-11T07:15:20.365757+00:00`

```json
[
  {
    "path": "app/lib/ui/delivery_screen.dart",
    "bytes": 40004,
    "sha256": "0e1f328e421c3351b295eabbe95409fb3f2372f13b85d4ed729142b88477e93b"
  },
  {
    "path": "app/lib/ui/delivery/map/delivery_map_workspace.dart",
    "bytes": 32868,
    "sha256": "68b8795192cdeb1bed9155fc58a4b4505135eed04e9898ae5919a07e5e7acf25"
  },
  {
    "path": "app/lib/ui/delivery/list/stop_list_workspace.dart",
    "bytes": 24597,
    "sha256": "f1d96edbc627632e48bae28efca0d6011e1a60fe7f4e5c867458007426c82531"
  },
  {
    "path": "app/lib/ui/delivery/list/stop_status_badge.dart",
    "bytes": 2072,
    "sha256": "acebc17b3c5de19404a6b58c101d5b14fcd14ec3d27f61f7422f597b247fd77f"
  },
  {
    "path": "app/lib/ui/delivery_view_model.dart",
    "bytes": 18196,
    "sha256": "07bc5b1431b3d732e152f57f262f39e168471d233ed5e6fb48f8bfa83f78aee9"
  },
  {
    "path": "harness/project/contracts.md",
    "bytes": 26888,
    "sha256": "3e4b6cd5bb3c5e739a9f584ebfad5d78461c5c70cd7ce98cdf1182c6a311a466"
  },
  {
    "path": "harness/runs/repair-20261011-prototype/browser/prototype-browse.png",
    "bytes": 176232,
    "sha256": "b251b749b0b762e716232907c3edfc9e02586829c383c2f1412a75cdef4396b8"
  }
]
```


---

## 最终冻结源复验（源码接受；不代签执行/原生）

本节更新前述判定；旧初审文字/身份保留。**本轮四项核心产品源码修正接受，未发现新的阻断性源码缺陷。首次确定notice缺陷及Tab两个明确分支已解决。真实双指/不同系统字号/原生图面是否通过仍须实际运行，本节不授予新G2。** 使用工程需求提取与 engineering-flutter-testing 的来源/证据分层原则；所有验证为读取，不执行SDK。

1. **notice几何已订阅。** `initState` 创建 `Listenable.merge([model,model.notice])`，根builder用它；showNotice与自动clear会重算listHeight/notice预留。没有改Repository通知或注入假model变更。新增Browse空queue Sync显示/清除的独立测试源码保留real UI操作和rect不相交断言；我没有运行它或以源码存在签执行通过。
2. **Tab是明确相机操作。** 详情关闭若来源恢复list，紧接closeList回map；原本已打开list不强关。当前search/Waiting不被清；postFrame用新result fit全部匹配+reference，max14，点击同Tab也执行。零匹配在根明确locate，并已改为固定zoom14；Fit按钮空匹配仍disabled，手动Fit自身仍守空输入。这个消费时序覆盖原型Tab意图，Back/terminalReturn来源恢复实现没有被替换成Tab逻辑。
3. **真实单列和安全lane。** 五个44pxaction+1分隔221px，全部同宽、Browse状态隐藏工具。compact/error coordinate-fit从x80至91，44px极值rect可落58..113；工具right57，右侧card/feedbackleft114，有各1px最小余量。单点center85.5，44pxrect63.5..107.5；52px单cluster中心rect59.5..111.5。此前x64..108的多点44px边界交叠已被更窄lane修正。剩余约束是极短area/cluster真实拓扑/像素舍入须由测试实测，不能在本次只读审查伪造设备通过。
4. **IgnorePointer是正确的hit-test边界。** 固定地理reference没有onTap/业务action，现只把该图形包在IgnorePointer中；业务_StopMarker手势保持原样，图形仍layout/paint。锁定Flutter源码 `rendering/proxy_box.dart:3797–3815` 的hitTest在ignoring时false，默认ignoringSemantics为null且visitChildrenForSemantics继续遍历，只阻止用户动作；内部Semantics标签 `Test reference, fixed heading 35 degrees`仍存在。因此不应为无点击行为的reference占住覆盖站点的pointer hit，亦没有以ExcludeSemantics隐藏其含义。既有map语义测试仍断言44×44、坐标/heading/语义标签；当前fresh实际结果待主控。
5. **双指与单指路径保留。** FlutterMap的all&~rotate配置保留，装配层未新增吞全图pointer的容器；新独立测试源码在upper-right/central两区域以两个同时touch pointer向外/内移动，分别断言实际camera.zoom增减、rotation不变、query/results不变，区别于+/-按钮。主控报告首次七项通过，但本职未读对应原始runner/log，故不把它写作独立执行已签；当前短图面站点真实hit复测亦不预签。
6. **Browse视觉层级符合原型方向。** 两份390×844网页原件已查看：正常map左栏纵向+/-/Fit/Locate/Sync，底部summary有Browse；Browse是整宽暖纸sheet/grip/固定title+count/客户优先连续row、address与distance/window/statusmetadata。新产品source匹配这些层级与相关颜色/字体/radius/rowspacing，默认重复queryblock已折叠，并保留真实44pxquery/Sync/Close入口与架构Waiting功能；不回退全局OS字体。row keys/客户编号Semantics/搜索/最近排序/来源session恢复仍沿用。

### 明确的边界与剩余核验项

- 最终只有**源码接受**。浏览器图面是设计输入，当前widgets是host机制证据；本职没有新SDK/原生执行，没有合并或关闭Issue权限。
- `prototype-observation.json`明确drawer rect为x0,y314,width390,height530,bottom844；初审PNG可见圆角主体约322的近似描述不应替代这份DOM几何。该JSON的rows=[]，因此不能用于证明实际row位置；row层级由真实PNG可视内容和源码交叉核对。
- Flutter sheet依实际map-area bottom0/fullwidth及可用高度，保留独立可见footer/SafeArea，不是原型whole-phone530px坐标完全相同。额外query与directSync action、compact标题内滚是合同明确的架构/可访问性扩展，需最终Flutter截图确认视觉结果。
- compact零匹配locate仍直接camera-center，不走fitPadding：固定reference可能在右侧overview之后。当前实现满足Tab零结果的实际fixedzoom14与定位语义；若验收还要求此分支reference44px整形无遮挡，应补一个实际held-out图面检查并按观察决定safe-lane偏置，不能据当前camera中心/zoom断言其图形可见。已告知主控，不把静态风险写成新native失败或削弱现门槛。
- 当前hostpinch与新hit-test补丁可说明机制；模拟器/设备两个pointer操作仍需要新的真实native记录，不能把旧381730的34case/历史CI/archive换成这次repair candidate。

最终读取时间：2026-10-11T07:29:55.888421+00:00；本节仅对以下冻结字节有效。追加前审查报告SHA256：0d98833c11092a81fad5f32d8d655089eb5081f440074242a905aea37a8b9ee7。

```json
[
  {
    "path": "app/lib/ui/delivery_screen.dart",
    "bytes": 40316,
    "sha256": "79f998acd1047a5eccba37432065da317cae2ada1512c412aaf78b10e6913358"
  },
  {
    "path": "app/lib/ui/delivery/map/delivery_map_workspace.dart",
    "bytes": 32998,
    "sha256": "8d7f300e29ad7309d7005e3cfd955dc0b9156a5d5b478d41d4a939d9c38ba292"
  },
  {
    "path": "app/lib/ui/delivery/list/stop_list_workspace.dart",
    "bytes": 24546,
    "sha256": "6cda0dc8be3a5e8609493723f84fb90189c4b639f7b9838f8ad6489a5d1bf95d"
  },
  {
    "path": "app/lib/ui/delivery/list/stop_status_badge.dart",
    "bytes": 2072,
    "sha256": "acebc17b3c5de19404a6b58c101d5b14fcd14ec3d27f61f7422f597b247fd77f"
  },
  {
    "path": "harness/project/contracts.md",
    "bytes": 26888,
    "sha256": "3e4b6cd5bb3c5e739a9f584ebfad5d78461c5c70cd7ce98cdf1182c6a311a466"
  },
  {
    "path": "app/test/review/prototype_map_interactions_test.dart",
    "bytes": 20017,
    "sha256": "6c7cb604861eff7fb208fa7ffec58bc22a4ef19f0b4746ce5e305938a37af753"
  },
  {
    "path": "app/test/map/delivery_map_workspace_test.dart",
    "bytes": 32654,
    "sha256": "773be7c889f32777b6ea8db31fabeff253a586a910217ba5b14e2146871c9510"
  },
  {
    "path": "harness/runs/repair-20261011-prototype/browser/prototype-map.png",
    "bytes": 347675,
    "sha256": "58f27fac37f6f70bb5ca55242105c607bba817e96bfe75b24b63007d3686ea0f"
  },
  {
    "path": "harness/runs/repair-20261011-prototype/browser/prototype-browse.png",
    "bytes": 176232,
    "sha256": "b251b749b0b762e716232907c3edfc9e02586829c383c2f1412a75cdef4396b8"
  },
  {
    "path": "harness/runs/repair-20261011-prototype/browser/prototype-observation.json",
    "bytes": 345,
    "sha256": "f7700486c3d4ccc4d309dd0c2416f9acde51613943f5752b01490acb43c0f8dc"
  }
]
```

主控最终范围决议（2026-10-11T07:30:17.164956+00:00)：零匹配locate保持原型camera中心reference/固定zoom14；compact图形可能在右lane之后作为明确自适应边界保留，always-visible footer仍提供reference/heading说明，不增加偏置。此项不再列为本轮四项源码阻断；不代表其图形无遮挡。主控运行中的quality原始失败与后续复测独立保留，本职未执行或重签其结果。新的四项交互证据不替代旧全34，也不重标381730历史。


---

## 私有UI驱动小修只读复核（后续新版仍待冻结）

读取时间：2026-10-11T07:39:12.990205+00:00

范围/角色：我是原native_acceptance_support部分历史支持代码作者；本节复核主控本次新增的readonly IconButton状态与展开路径，不冒称整个私有driver非作者，不签整体G2。无SDK/源码写入。

实际桥接变化只是在真实keyed IconButton的bounds记录加isSelected=widget.isSelected；list-query-controls的产品isSelected绑定真实_queryExpanded。requestData仍readonly，无VM字段写入、导航/查询/数据库注入，modelpanel/action日志和8秒/15秒边界未变。通过常驻header真实状态而非stop-search是否已构建判断展开/折叠，方向正确；deep typed Return后search从lazy缓存移除，不再被误当折叠而反向关掉query。

两处具体边界已发主控且其明确同意等待当前SDK终态后修正：

1. 现helper只require唯一List/Map，然后isSelected!=true即tap。字段缺失/null/非bool会被当折叠，不能满足“仅实际false才tap”。配对当前产品producer必出bool，所以不宣称现场故障，但应nativeRequire(isSelected is bool)，错误failclosed。
2. OpenListStop的展开后search暴露保留12次/15秒实际+160 scroll/journal、centerHit/面板校验，之后原enterText/query唯一匹配/target真实reveal+tap/来源断言都未变。但acceptanceList(status非null或Waitingtrue)调用QueryTools后立即tap filter-all/waiting-only；如果恢复深offset而query已展开，其lazy controls未构建/不可点击。不能只让OpenListStop后续上滚，reset分支也须先暴露。主控选定将**原有**search暴露循环移至QueryTools末尾，供两入口共享；不是新预算、session归零或模型清query。

因此当前小修方向接受，完整privatehelper源判定等待上述下一冻结字节。仍需实际N4/N7评定新版交互，不以旧driver成功签当前。

### 实际旧候选G1原件核验（明确不重标新版）

只读重算20261011T073423342808Z-quality的七份rawlog，全部sha256对应report且各stage exit0/passed，报告wrapper_reaped=true/group_alive=false。原始tooling terminal Ran161/OK(skipped=1)，此Mac skip须与Linux-only zombie边界区分；Flutter terminal +185 All tests passed。origin/execution/source-after字段记录如下，隔离clone清除为report原始事实；本职未访问/操作root当前lease或另作OS检查。

此候选是b3d2af5b...，发生在本次private两文件修正之前。新版finalquality仍需fresh报告；不能拿此PASS签新增isSelected/共享暴露循环，不能重标原native34。

```json
{
  "reviewed_sources": [
    {
      "path": "app/integration_test/support/native_workbench_bridge.dart",
      "bytes": 11858,
      "sha256": "89815dfac81a24f3add97efaebbedf3e1c8a3003d0e01a8fce60ebbfb45ff732"
    },
    {
      "path": "app/integration_test/support/native_acceptance_support.dart",
      "bytes": 24759,
      "sha256": "dda338a20f5629e0066f5ebc30cb83b0d1fb735ac3b0f09c75677adbbba351a9"
    },
    {
      "path": "app/lib/ui/delivery/list/stop_list_workspace.dart",
      "bytes": 24546,
      "sha256": "6cda0dc8be3a5e8609493723f84fb90189c4b639f7b9838f8ad6489a5d1bf95d"
    }
  ],
  "prior_quality_raw_readback": {
    "path": "harness/runs/20261011T073423342808Z-quality/report.json",
    "sha256": "f7413ccd36deaef0c22740b73f478def3ea54358981c8a615d6a5b35d5af6e1e",
    "candidate": {
      "source_fingerprint": "b3d2af5b9d084550ef3a55a2b9cba1dc81fd0474b7a2ab39404515411abcb2e5"
    },
    "candidate_after": {
      "source_fingerprint": "b3d2af5b9d084550ef3a55a2b9cba1dc81fd0474b7a2ab39404515411abcb2e5"
    },
    "execution_candidate_after": {
      "source_fingerprint": "b3d2af5b9d084550ef3a55a2b9cba1dc81fd0474b7a2ab39404515411abcb2e5"
    },
    "job": {
      "pid": 7763,
      "status": "passed"
    },
    "isolation": {
      "requested": true,
      "verified_fingerprint": "b3d2af5b9d084550ef3a55a2b9cba1dc81fd0474b7a2ab39404515411abcb2e5",
      "task_owned": true,
      "cleaned": true
    },
    "stages": [
      {
        "id": "repository",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "tooling-tests",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "sdk",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "pub",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "format",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "analyze",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      },
      {
        "id": "flutter-tests",
        "status": "passed",
        "exit_code": 0,
        "sha256_verified": true,
        "wrapper_reaped": true,
        "group_alive": false
      }
    ]
  }
}
```


## Final private helper review — frozen source

Disposition: accepted for the bounded private-support patch. Both previously reported actionable boundaries are fixed. The persistent `list-query-controls` button is observed through its actual `IconButton.isSelected`; exactly one record and a bool value are required before deciding whether to tap. Missing/null/non-bool state now fails closed. The bridge only adds that read-only widget property to existing bounds and does not mutate model or navigation state.

The original search exposure loop now lives in `acceptanceListQueryTools`, so filter resets in `acceptanceList` and the three direct search entries in `acceptance_driver.dart` use the same real-scroll path. An expanded query outside the lazy-list cache is brought into view without toggling it closed or resetting the restored list session. Exposure still requires the unique search control's actual `centerHit == true`, uses journalled primary-scroll +160 drags, and retains the original maximum 12 drags/15-second search lookup with remaining-budget timeouts and list-panel guard.

`acceptanceOpenListStop` retains its original separate -160 row-exposure path, maximum 12 drags/15-second lookup, unique/hittable row condition, unchanged panel/search/matched-count assertions, real reveal/tap, and final detail/list-origin/reference assertions. Moving the local `maxScrolls` declaration into that row lookup does not change the bound. The actual filter taps remain intact. No product/UI state injection, fake bounds, capture changes, relaxed business assertions, or changed 8-second action/15-second observation constants were found in this patch.

This is a review of the root-authored bounded delta, not independent acceptance of all previously authored support/test code. The four user-facing product requirements retain the static disposition above. Root's fresh final quality and native checks are still pending at this review; the earlier 073423 quality evidence belongs to its original candidate and does not sign these later private-helper bytes. This review does not claim native pinch, native layout/return acceptance, the old full 34-check aggregate, or production readiness. No SDK/test/build/native/lease operation or tracked write was performed by this reviewer.

Final source read bookends (initial read versus final reread):

```json
{
  "reviewed_at_utc": "2026-10-11T07:44:02.095372+00:00",
  "source_bookends": [
    {
      "path": "app/integration_test/support/native_acceptance_support.dart",
      "bytes": 24749,
      "sha256": "cfc58e6e12665c9f792693000cfa1c5e9500659995aba63a2950ba7899840b05",
      "read_bookends_equal": true
    },
    {
      "path": "app/integration_test/support/native_workbench_bridge.dart",
      "bytes": 11858,
      "sha256": "89815dfac81a24f3add97efaebbedf3e1c8a3003d0e01a8fce60ebbfb45ff732",
      "read_bookends_equal": true
    },
    {
      "path": "app/integration_test/acceptance_driver.dart",
      "bytes": 71037,
      "sha256": "cdc135700acd188e001189297f67c448156bdf1b12c35b35c10192b23bc5ff25",
      "read_bookends_equal": true
    },
    {
      "path": "app/integration_test/workbench_driver.dart",
      "bytes": 14781,
      "sha256": "100d11dadcdc5af3425a95195d0f536bbf0e9f4cc645cff13ccfaf0bb7a3375f",
      "read_bookends_equal": true
    }
  ]
}
```


## N4 actual targeted raw review

The five N4 checks on source `4213e29d98c9b6d2af5b9155fc70f33cf6a5770f46befa032e9f33df7a61fdaa` are accepted at this targeted scope after actual raw readback. See `N4-native-independent-review.md` and its JSON SHA `444284f67aa19ad7a3ae84e300cb8c358cda05446c40d154d40cacfbdaf0c194`: 140 native artifact hashes, 146 unchanged original files, all 41 raw assertions, 13 actual SQLite projections, four native and seven quality log hashes were independently recomputed. Three OS/VM processes match; single-column controls and framework two-pointer zoom 15→16.459431618637296→15 are observed. Deep list offset2929.5/focusTV-300023/source returns and immutable queue are verified. Pinch input is framework two-touch, not physical OS injection. The query PNG is expanded and is not a default/pixel-perfect claim. Current N7 and whole34/production remain unsigned; the original producer `business_acceptance:false` is retained. Earlier driver/support authorship is disclosed in the standalone report.
