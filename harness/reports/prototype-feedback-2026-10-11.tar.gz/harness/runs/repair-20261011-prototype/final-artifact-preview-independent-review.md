# Formal artifact and preserved-data preview independent review

Status: `passed`, limited to the formal Demo artifact and preserved-data simulator preview. Candidate `fcc573639cd8ba9fe4cf4a9951636cc5f8fbd1e94c8bc248f6906f2f27d9fff5`; committed source `a6d473d2b9b91126d4d689dddfc4b9b8ee19e48f`. Read-only reviewer `/root/harness_review`; no SDK, tests, device control, product/source edits or external publication.

Formal Demo `lib/main.dart` isolated debug iOS simulator build passed actual SDK/pub/build with unchanged source bookends and real wrapper/group cleanup. All261 fingerprint inputs match committed Git blobs byte for byte. The Runner archive and expanded tree all84 files were independently hashed and matched; archive SHA256 is `e94671cebc94ef02ab1feea15c775f90066c8a3550a965d627d0a305e8bbd2b2`.

Actual install/launch/show receipts bind that formal artifact, bundle and task UDID D2B958C6-486D-4C17-A0CE-A8135717F3A6 to PID25842 and its task-container Runner executable. Preserved stops/outbox bytes are identical:30 stops, zero outbox, SHA256 `12e316d3530c932343757024cea6bcf9be5fa2bd42e044493f70b20ae87d6584`, despite data-container UUID change. Equality is limited to these two captured tables; an empty outbox is not a queued-result upgrade test. No erase/uninstall appears in actual installation receipts. The initial terminate code3 explicitly recorded nothing running; it is not relabelled as a successful process termination.

Independent local PNG inspection shows initialized street map, All30/Pending23/Completed4/Failed3, five vertical map controls, Demo simulated-confirmations label and zero waiting. This is one formal initialized frame and recorded launch/PID evidence, not continuous monitoring or a full business acceptance run. Installation/capture leases are released, and the user-requested preview is intentionally retained. Original raw reference hashes were checked again before this review froze.

This frozen file does not review its containing handoff package. A separate independent handoff audit consumes it without a circular dependency. Historical381730 full34/old delivery evidence is not reused to sign currentfcc573. This review does not sign full34, physical G3, performance, release signing, real backend upload, publishing or production eligibility. `production_publish_allowed=false`.

Detailed checked paths, Git blobs, raw hashes and identities are retained in `final-artifact-preview-independent-review.json`. No old381730 binary handoff archive was read for this review.
