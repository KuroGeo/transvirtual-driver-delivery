2026-10-11 用户原型反馈返工，关联父 #14、集成 #25、独立验收 #27、PR #34。重新打开本 Issue 追踪地图范围，不新建重复任务。

当前问题：左侧工具曾因紧凑布局分成两列；顶部状态 Tab 只更新集合，没有像原型重新取景；用户报告双指不能缩放。参考 `prototype/app.js`、最终原型 CSS 和本轮 390×844 浏览器截图。目标：始终单列 44px 工具；明确点击 Tab 后适配当前匹配点与固定参考点，零结果定位参考点；以真实两触点事件验证缩放，不能仅检查 flags。

范围与负责人：root 写地图、共享页面取景/导航；独立 acceptance agent 只写交互测试与固定私有手势指令；requirements agent 只读复核。正常入口不加入测试指令。列表子任务见 #19。沿用既有查询、SQLite/outbox、被动反馈不移动相机合同。

Skill 接力：engineering-issue-authoring → flutter-development → engineering-flutter-testing → flutter-native-acceptance → engineering-release-handoff；Harness 负责候选指纹、SDK/设备 lease、隔离执行与原始失败保留。所有写入者冻结后才跑 SDK/原生验证。

验收增量：
- [ ] 390×844、SafeArea、最大系统字号下工具仍单列，每个控件至少 44×44，配送点可点击。
- [ ] 明确点击 All/Pending/Completed/Failed 按当前查询重新取景；从详情返回遵循最新原型；Toast/ACK/保存不触发取景。
- [ ] 两触点同时按下、成对移动后，相机 zoom 放大/缩小；明确区分 Flutter 框架输入与物理 OS 手势。
- [ ] 当前候选 quality、N4/N7 模拟器回归、正式 lib/main.dart Demo 构建与预览机重装证据齐全。

执行：`python3 harness/run.py quality --isolated`；`python3 harness/run.py native --scope workbench --driver-target integration_test/acceptance_driver.dart --scenario N4 --configuration demo --isolated`；同入口 N7 + 最大系统字号；正式 `build --configuration demo --entrypoint lib/main.dart --isolated`。

当前状态：代码已实现，聚焦 host 交互/几何回归通过；完整 quality 与本候选模拟器验证尚在进行。历史 34 项验收不迁移为当前版本通过。原始证据：`harness/runs/repair-20261011-prototype/` 与实际 Harness 运行目录。关闭前补当前 fingerprint、报告 hash、设备/截图及独立判定。生产 no-go 保持。
