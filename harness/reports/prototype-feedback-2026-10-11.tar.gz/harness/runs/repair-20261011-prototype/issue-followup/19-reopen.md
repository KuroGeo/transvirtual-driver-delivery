2026-10-11 用户反馈 Browse list 需对齐原型，关联父 #14、地图 #22、集成 #25、独立验收 #27、PR #34。重新打开本 Issue 追踪既有列表范围，避免重复任务。

当前问题：原列表搜索/筛选区域和行排版改变了原型默认观感。目标：底边连接的奶油白抽屉、grip、Stops on the map 标题/数量与 Nearest first、副标题、连续行的状态圆标/客户/地址/距离/时间窗/状态/箭头，对齐原型实际 390×844 截图。架构要求的搜索/Waiting/筛选保留在可展开工具中，不破坏默认列表。

写域：query_development agent 独占列表与列表测试；root 独占宿主抽屉、共享驱动/旧消费者适配；独立 requirements/acceptance agent 只读复核与持出测试。保留查询交集、列表来源返回、滚动/行焦点恢复、状态与 outbox 语义。

Skill 接力：engineering-issue-authoring → flutter-development → engineering-flutter-testing → flutter-native-acceptance → engineering-release-handoff。主控 Harness 统一执行；作者冻结，不并行争用 SDK 或设备。

验收增量：
- [ ] 默认标题、底部面板、行层级、状态符号与箭头对齐原型截图；距离最近优先、数据不篡改。
- [ ] 展开后旧搜索/筛选/Waiting/同步实际可操作；列表来源返回恢复滚动/焦点，关闭后回地图。
- [ ] 最大系统字号与 SafeArea 下实际文字不钳制，标题可滚动，关闭/工具至少 44×44；notice 出现/消失更新可用高度。
- [ ] 当前候选 quality、N4/N7 模拟器列表流程以及正式 Demo 重装证据完成。

执行入口：`python3 harness/run.py quality --isolated`；独立 `native --scope workbench --driver-target integration_test/acceptance_driver.dart --scenario N4/N7 --configuration demo --isolated`（场景分别调用）；正式 `build --configuration demo --entrypoint lib/main.dart --isolated`。

当前状态：列表源码冻结，8 项列表测试和新 notice 几何测试聚焦通过；完整 quality 与模拟器尚在进行。原始浏览器截图/源码审查在 `harness/runs/repair-20261011-prototype/`，关闭前补本候选版本、原生报告/截图 hash 与独立结论。网页截图是比较来源，不能签 Flutter 验收。生产 no-go 保持。
