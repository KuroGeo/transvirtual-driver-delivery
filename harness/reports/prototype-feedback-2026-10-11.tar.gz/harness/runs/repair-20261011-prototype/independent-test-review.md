# Prototype interaction repair: independent test preparation

Status: source and regression preparation only; SDK/format/analyze/test/native execution pending the root-owned frozen Harness run. No runtime PASS or current-cut native acceptance is claimed. Reviewer wrote only the new authorized widget-test path, the subsequently authorized three private gesture/registration files, and this ignored report. No Git commit, product edit, existing-test edit, device command, SDK execution, or root-lock action.

## Contract and actual baseline

Read `.agents/skills/engineering-flutter-testing/SKILL.md`, current map/screen/list/query sources, original map and formal-workbench fixtures, `prototype/assets/app.js`, `prototype/assets/map.js`, `prototype/index.html`, and the actual `prototype/evidence/round3-feedback/workspace/list.png` image.

The baseline map toolbar used two 44px columns and an 88px sync row. Its old map test explicitly asserted the same two-column geometry; root owns the correction of that contradictory old assertion. This user's “always one column” instruction takes precedence over the historical prototype detail-state two-column CSS. Baseline header status taps only called `model.setStatus`, while prototype `setFilter` explicitly syncs the markers and fits. Prototype Fit includes matching stops plus the fixed reference, with max zoom14. Empty matching sets retain the disabled Fit button, while an explicit header status tap follows the prototype empty-fit branch to the fixed reference at zoom14; passive search/query/notice/ACK rebuilds must not take over the camera.

Baseline map interaction flags already allow all gestures except rotation. That alone is not a pinch defect. The new tests exercise the formal DeliveryScreen, including its feedback-overlay region, to distinguish a real touch/overlay/recognizer problem from configuration assumptions. Existing fixtures generate local tile images, use approved Inter/icons, and mount the real formal factory/App with a private temporary SQLite file. No public tile service or customer database is used.

The viewed prototype Browse panel contains a grip, “Stops on the map”, “N stops · Nearest first”, customer/address rows, distance/window/status/waiting metadata and Close. Root/Query's approved additive Search-and-filters toggle preserves the old query keys without duplicating those controls in the default panel. Shared query, list origin, offset and focus remain business contracts.

## New widget regressions

`app/test/review/prototype_map_interactions_test.dart` adds six actual widget cases:

- One full-width, vertically ordered, at-least44px, fully map-contained/hittable tool column in overview and actual nearest-origin detail at normal scale.
- The same column at the real historical maximum iOS scale53/17 supplied through the test dispatcher, with approved Inter and no product scale clamp.
- Actual concurrent expanding/contracting touch pointers on the upper-right formal map area, reporting all four start/end hit paths and actual before/after camera values.
- The same two-touch input on central formal map space. Both tests require zoom changes in both directions and unchanged rotation/query/panel/queue; neither calls MapController.move or fitCamera.
- Actual header All/Pending taps fit a synthetic distant-versus-nearby search/status intersection plus fixed reference, with max zoom14. Real search input and passive model/notice changes retain camera, and explicit empty-match header taps locate the reference at zoom14 while the Fit button remains disabled. Repeating the selected header status closes actual detail and fits the same matching query. The synthetic far Pending stop makes fitting the whole status instead of current matches observably wrong.
- Actual Browse tap produces the prototype default header/rows, then real list-query-controls taps expose/collapse the preserved search. List-origin selection and Close retain search/status/session offset/focus, followed by actual Close-list returning to the map.

Tests use bounded frames and explicit fixture completion fences, not infinite pumpAndSettle or timing-only readiness. Hit-path/camera diagnostic JSON is printed in the actual test output and attached to failure reasons. Source is frozen preformat; root may format only these exact four files under its SDK lease. These assertions have not yet executed, so their reachability and runtime outcome are not self-certified.

## Fixed native gesture API

The previously fixed DoubleComplete command remains byte-identical. New `const MapPinchOut()` / `const MapPinchIn()` commands have exact kinds `oceanMapPinchOut` / `oceanMapPinchIn`, timeout8s, and corresponding MapPinchOutExtension/MapPinchInExtension registrations. The parser accepts only the exact command/timeout/optional isolateId fields. Coordinates, arbitrary finders, direction payload, business values and camera commands are rejected.

Each extension resolves one actual onstage delivery-map RenderBox, intersects its real rect with actual OS padding/keyboard viewport, rejects invalid geometry, and chooses a bounded upper-right or central pair whose start/end hit paths contain that map. It delivers two concurrent touch pointers, ten paired moves with matching timestamps, and actual releases; failure cleanup cancels remaining pointers. The response records direction, actual map rect, start/end points, hit paths, pointer IDs, completed pointers, paired steps/timestamps and elapsed time. It contains no bridge/model/controller mutation. A central fallback is explicit in its returned coordinates; the upper-right widget test has no such fallback.

This is real framework pointer delivery inside the simulator Dart process, not physical OS touchscreen injection. The readonly snapshot remains observation-only. A full inverse of the three additive integration edits restored their complete HEAD68dcbabec7460e0ce2724b176b24213641158b8b source bytes, including old DoubleComplete and registration behavior.

## Minimum native verification after freeze

Root can add the fixed commands to its existing native N7 actual-gesture action journal and preserve original N7 checks. Capture the readonly camera/query/selected source/outbox before each command, retain the completed command response, then observe a quiet actual camera after release. Require outward zoom increase and inward decrease, unchanged rotation and business state; retain actual OS PNG and SQLite projection. Run normal and maximum-text/reduce-motion device variants only through the serialized native Harness. A failed upper-right widget case must be diagnosed before treating a native central fallback as proof of that region.

For the remaining repairs, retain original N4/N7 assertions while recording actual single-column tool rectangles/hits in map/detail; perform explicit status taps with a current search and verify all matching coordinates plus reference are inside the fitted camera. Then actually Browse, observe the default panel, open the new query toggle before existing stop-search locators, select a real row and Close back to the same list source/query/offset/focus. Existing supporting-helper and other tests need authorized toggle adaptations by their owners. No new integration path is necessary for the proposed fixed commands; acceptance_driver/native_driver_support edits remain root-owned.

Old candidate G1/G2/archives remain historical. New product/test/gesture source requires a fresh candidate quality run and actual native evidence; this preparation does not rebind old leaves or certify physical input, production use, or full E08 for the new cut.

## Initial prepared preformat source hashes (historical)

| File | Preformat SHA-256 |
| --- | --- |
| `app/test/review/prototype_map_interactions_test.dart` | `92e2fd51cc3280cb9ffb356c44021da9fd5aa99281ff942fd0ca48db78bb2c41` |
| `app/integration_test/support/native_gesture_command.dart` | `d7ff0efd9b9405a7d7fe909e50f617c1f0dcb07194118c86b858c0f25e23bc15` |
| `app/integration_test/support/native_gesture_extension.dart` | `e55ee8eff287fd5a126485da5eb394f4b716847ca24d68f0d35abfb2b58b8bf5` |
| `app/integration_test/workbench_entry.dart` | `36667f78c832f00dae349a6b62e637f35559c1f9ebe45f084cfe9d0b28a4edca` |

Static whitespace checks produced no diagnostics. The no-index new-file diff has the ordinary changed-file exit1; it is not a test result. No Dart parser/compiler was executed by this reviewer. Root owns formatting and actual execution logs.

Contract correction before execution: the initial prepared test treated an explicit empty header tap as a no-op. Direct map.js fit() evidence includes the reference even when there are zero stops, then locate() sets zoom14. The final prepared test follows this behavior and retains disabled Fit. No actual failing runtime was overwritten; none has executed yet.

## Actual first focused run and test-fixture correction

Root's actual focused run `20261011T071133024704Z-test/attempts/000001` failed to load the new test. Its raw log (SHA-256 `5e1561a08e1cad7d0273db55cbec9507e59ff2dd05eca92914755a9725291217`) reports three nonexistent `DeliveryViewModel.queue` getters and a missing required `showNotice.kind`. This was an independent test author API mistake, not a product pinch failure: none of these new widget bodies had executed. The failed formatted test source SHA was `39c30f9da2bfbb12c744f9da22322125d6962262ab3de22c95c55ffc1bae3069`. Original raw failure remains unchanged.

Corrected only this owned test: assert public queueCount0 and the real formal repository.pendingUpdates() empty list through the bounded I/O helper; pass explicit NoticeKind.information. All prior interaction assertions remain. A seventh real Browse case taps the empty-queue list-sync control, observes its actual notice, requires the list panel/actions to lie below it without overlap, then clears only the actual notice ValueNotifier and requires the original panel bounds to return. It changes no query, stop, or business event to manufacture a relayout. This covers the root's identified feedback geometry/rebuild repair. Tests remain pending root rerun; no SDK execution by this reviewer.

Latest frozen source before root reformat:

- `app/test/review/prototype_map_interactions_test.dart`: `6c7cb604861eff7fb208fa7ffec58bc22a4ef19f0b4746ce5e305938a37af753`
- `app/integration_test/support/native_gesture_command.dart`: `d7ff0efd9b9405a7d7fe909e50f617c1f0dcb07194118c86b858c0f25e23bc15`
- `app/integration_test/support/native_gesture_extension.dart`: `6289fd7378a6627fda714fa5834bc0785c57d1a597d63c5f67af240980d66679`
- `app/integration_test/workbench_entry.dart`: `36667f78c832f00dae349a6b62e637f35559c1f9ebe45f084cfe9d0b28a4edca`
