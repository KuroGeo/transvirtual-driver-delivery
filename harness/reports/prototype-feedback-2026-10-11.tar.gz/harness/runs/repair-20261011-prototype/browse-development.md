# Browse stops prototype alignment — development handoff

Status: source frozen for root formatting, Harness execution and independent review. Author has not executed SDK/pub/tests/build/native and does not self-accept this repair.

Read `.agents/skills/flutter-development/SKILL.md` and the current `prototype/assets/map.css`, `refined.css`, `app.js`, `index.html` (plus relevant inherited app.css rules). Root approved a default prototype drawer with its auxiliary query tools collapsed; current user/prototype direction takes priority over historical duplicate-query layout.

The default panel now has the warm paper drawer, grip, `Stops on the map`, matched-count `N stop(s) · Nearest first`, and one nearest-first lazy list. Rows use customer as the first visible identity, address next, then distance, time window, status and optional waiting text. Reference remains in the stable row key and accessible row label. The leading outcome affordance uses the prototype30px ring/check/warning shape and warm status surfaces; the trailing14px arrow uses the existing Carbon component. Resolved map.css colours,16/14/13px text hierarchy,17×20px row padding,112px minimum row height and warm dividers are local to this component.

`list-query-controls` is a44px header IconButton, tooltip `Search and filters`; it expands/collapses the existing query controls without changing query/result. `stop-search`, `clear-search`, `filter-all/pending/completed/failed`, `waiting-only`, `stop-list-scroll`, `stop-<reference>`, `list-sync`, `close-list` remain. Optional sync still joins a busy run. Full OS text scaling is retained: at compact height/large text the complete heading moves into the primary scroll, while query/sync/close actions stay44px. No scale clamp, global cache, new dependency, VM/navigation/map/theme edit, or eager full-list build.

The approved Expando proposal was removed before freeze: query disclosure lives only in component State. Formal host already retains that State through Offstage. A standalone cold remount defaults to collapsed; existing listSession scroll/row focus restore remains unchanged. `StopStatusBadge` adds optional `showSymbol`/`textStyle`; both default to the existing shared appearance. Browse passes text-only because the leading outcome is already visible. Shared status helpers are unchanged.

Existing seven list regression names/assertions remain (identity/status semantics/queue, busy sync join, query intersections/empty reset, real deep offset/focus remount, filtered terminal fallback, cold focus/close,2x short-height scroll). Query consumers now explicitly tap the disclosure. Added regression uses267px panel,47/34SafeArea and53/17 OS text scale, actual bounded primary-scroll search/row lookup, visible customer tap, typed list origin, return with real offset/FocusNode and query preserved. The semantics handle is disposed in finally before the test callback returns.

Consumers outside owner write scope requiring root updates: `app/test/ui/overview_geometry_test.dart` title literals and search entry; `app/test/reliability/formal_workbench_test.dart` list-search inputs; `app/test/reliability/workbench_fault_combinations_test.dart` waiting-only; `app/integration_test/support/native_acceptance_support.dart` list-search reveal; `app/integration_test/acceptance_driver.dart` list query chain; `app/integration_test/workbench_driver.dart` list-search entry. Root/independent test owner received exact keys and scope. These sources were not edited here.

Actual author validation: `git diff --check` on these three files exit0. No Dart formatter/analyzer/test runtime was invoked under the source-writer restriction. Root must format these scopes and run the focused list regressions plus unified Harness; source hashes below are pre-root-format. No native/production acceptance is claimed.

| Owned file | SHA256 at development freeze |
|---|---|
| `app/lib/ui/delivery/list/stop_list_workspace.dart` | `f5bba38730d9736a391e3ea4f2cfac0f32690a8581e7b636c1390ade578082c1` |
| `app/lib/ui/delivery/list/stop_status_badge.dart` | `acebc17b3c5de19404a6b58c101d5b14fcd14ec3d27f61f7422f597b247fd77f` |
| `app/test/list/stop_list_workspace_test.dart` | `84d45dbf17f6eb5f91d5c9cd7c386c915ac59e6182e30acb33a36640aff95415` |
