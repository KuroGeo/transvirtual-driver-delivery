from pathlib import Path
import sys,json,hashlib,subprocess,sqlite3,os,time
root=Path.cwd().resolve();sys.path.insert(0,str(root));from harness import checks,state
candidate='fcc573639cd8ba9fe4cf4a9951636cc5f8fbd1e94c8bc248f6906f2f27d9fff5'
udid='D2B958C6-486D-4C17-A0CE-A8135717F3A6';bundle='dev.oceandelivery.oceanDelivery'
out=root/'harness/runs/repair-20261011-prototype/preview';out.mkdir(exist_ok=True)
leaf=Path(sys.argv[1]).resolve();report=json.loads((leaf/'report.json').read_text())
assert report['job']['status']=='passed' and report['candidate']['source_fingerprint']==candidate
assert checks.fingerprint(root)==candidate
artifact=leaf/'artifact-ios-build';manifest=json.loads((artifact/'manifest.json').read_text());app=artifact/'Runner.app'
assert manifest['candidate']['source_fingerprint']==candidate and manifest['entrypoint']=='lib/main.dart'
assert manifest['configuration']=='demo' and manifest['ios_target']=='simulator' and not manifest['signed_for_production']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(manifest['path']))==manifest['sha256']
actual={p.relative_to(app).as_posix() for p in app.rglob('*') if p.is_file() or p.is_symlink()}
assert actual=={i['path'] for i in manifest['files']}
for f in manifest['files']:
 p=app/f['path']
 if 'symlink' in f:assert p.is_symlink() and os.readlink(p)==f['symlink']
 else:assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
records=[]
def run(argv,lease,required=True):
 p=subprocess.run(argv,capture_output=True,text=True,timeout=180,pass_fds=tuple(lease['lock_fds']))
 i={'argv':argv,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr};records.append(i)
 (out/'install-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if required and p.returncode:raise RuntimeError(i)
 return p.stdout.strip()
def business(container):
 db=Path(container)/'Documents/ocean_delivery-demo.sqlite'
 conn=sqlite3.connect(f'file:{db}?mode=ro',uri=True);conn.row_factory=sqlite3.Row
 try:return {t:[dict(row) for row in conn.execute('SELECT * FROM '+t+' ORDER BY rowid')] for t in ('stops','outbox')}
 finally:conn.close()
before=json.loads((out/'before-business.json').read_text())
with state.lease(['app-workspace','device:ios-task-simulator','device:'+udid],out/'install-lease',root/'harness/runs/locks') as lease:
 devices=json.loads(run(['xcrun','simctl','list','devices','--json'],lease))
 found=[d for group in devices['devices'].values() for d in group if d['udid']==udid]
 assert len(found)==1 and found[0]['name']=='Ocean Delivery Preview';device=found[0]
 if device['state']=='Shutdown':run(['xcrun','simctl','boot',udid],lease)
 run(['xcrun','simctl','bootstatus',udid,'-b'],lease)
 before_container=run(['xcrun','simctl','get_app_container',udid,bundle,'data'],lease)
 assert business(before_container)==before
 run(['xcrun','simctl','terminate',udid,bundle],lease,required=False)
 run(['xcrun','simctl','install',udid,str(app)],lease)
 container=run(['xcrun','simctl','get_app_container',udid,bundle,'data'],lease)
 installed_before_launch=business(container);assert installed_before_launch==before
 stdout=out/'launch.stdout.log';stderr=out/'launch.stderr.log'
 launch=run(['xcrun','simctl','launch','--stdout='+str(stdout),'--stderr='+str(stderr),udid,bundle],lease)
 pid=int(launch.rsplit(':',1)[1].strip())
 screenshot=out/'installed-preview.png'
 run(['xcrun','simctl','io',udid,'screenshot',str(screenshot)],lease)
 after=business(container);assert after==before
 (out/'after-business.json').write_text(json.dumps(after,indent=2)+'\n')
 receipt={'status':'installed-and-launched','candidate':candidate,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'entrypoint':'lib/main.dart','configuration':'demo','device':device,'bundle':bundle,'pid':pid,'artifact_manifest':str((artifact/'manifest.json').relative_to(root)),'manifest_sha256':sha(artifact/'manifest.json'),'archive_sha256':manifest['sha256'],'artifact_files_verified':len(manifest['files']),'before_data_container':before_container,'data_container':container,'business_data_equal':after==before,'stops_count':len(after['stops']),'outbox_count':len(after['outbox']),'before_business_sha256':sha(out/'before-business.json'),'after_business_sha256':sha(out/'after-business.json'),'screenshot':str(screenshot.relative_to(root)),'screenshot_sha256':sha(screenshot),'signed_for_production':False,'foreground_open_pending':True,'scope':'Formal Demo preserved-data simulator preview; initialized map screenshot requires independent visual inspection'}
 (out/'preview.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
