# PR34 data, sync, VM and bootstrap review

Base: `3e0300848fcded055abcc47448c06a165d0472d6`
Reviewed HEAD: `3233a2e0f99bde286fe1faa710e9f3955d1da628`

**Verdict: approve in reviewed scope. No actionable P1/P2 findings.**

Read-only static review of the complete assigned production code and its relevant full PR diff, contract, and tests. No SDK, test, build or device operations were run by this reviewer. Root must use actual candidate quality and CI results for final merge qualification.

## Contract checks

- D1: Terminal writes atomically couple status/reason/note/recorded_at and immutable outbox identity; concurrent and repeated attempts reject; observer exceptions cannot reject a committed write.
- D2: ACK checks operationId, datasetId and stopId against the queued item; persisted ACK timestamp and deletion share one transaction; unknown, duplicate, stale and rollback outcomes retain appropriate queue identity.
- D3: v1 upgrade adds fields/settings transactionally, leaves stable IDs/operation IDs/seq/terminal data intact, and only backfills time windows on matching asset identity; read/validation/SQL failures remain retryable without clearing the old file.
- D4: Settings writes serialize; online flag is published and coordinator paused/resumed only after persistence; viewport is validated and dataset-scoped; connection and map-position errors are distinct; failed Online intention survives unrelated successful viewport writes.
- D5: Sync single owner coalesces explicit wakeups, rereads an empty snapshot if new work arrived, allows matching in-flight ACK on pause, releases on actual request deadline, ignores late ACK/error and counts only persisted ACKs.
- D6: VM load/submit/sync reserve futures before reentrant notifications; refresh serializes and rejects older snapshot versions; committed result plus read failure is a known terminal projection with recording disabled until Reload.
- D7: VM close removes observers, pauses once, joins own initialization/submission/sync/settings/refresh futures and closes once without a post-close read or send; App bootstrap coalesces retry taps and closes a model that arrives after unmount.
- D8: Formal factory defaults to UnavailableTransport, demo uses a separate file and explicit simulated transport, and production main imports no integration driver. Query intersections, global queue truth and typed return/session contexts remain independent of viewport.
- D9: Reviewed data/query/sync/lifecycle/reliability tests use controlled Completers and actual SQLite file/trigger rollbacks; previously existing lifecycle/coordinator assertions are retained. Formal held-response fixtures explicitly extend only their test timeout; actual production default remains 5 seconds and timeout/late-response tests cover it.

## Reviewed-file coverage

35 files read; 28 changed files in the assigned scope. The JSON report records content SHA-256, line count, change status, and read coverage for every file.
- `app/integration_test/support/delivery_fault_fixtures.dart` — complete source and applicable full PR diff.
- `app/lib/app/ocean_delivery_app.dart` — complete source and applicable full PR diff.
- `app/lib/app/runtime_configuration.dart` — complete source and applicable full PR diff.
- `app/lib/data/delivery/delivery_repository.dart` — complete source and applicable full PR diff.
- `app/lib/data/delivery/delivery_settings_store.dart` — complete source and applicable full PR diff.
- `app/lib/data/delivery/sqlite_delivery_repository.dart` — complete source and applicable full PR diff.
- `app/lib/data/delivery/sync_coordinator.dart` — complete source and applicable full PR diff.
- `app/lib/data/services/demo_transport.dart` — complete source and applicable full PR diff.
- `app/lib/main.dart` — complete source and applicable full PR diff.
- `app/lib/models/delivery.dart` — complete source and applicable full PR diff.
- `app/lib/models/workbench.dart` — complete source and applicable full PR diff.
- `app/lib/ui/delivery/query/workbench_query.dart` — complete source and applicable full PR diff.
- `app/lib/ui/delivery/query/workbench_session.dart` — complete source and applicable full PR diff.
- `app/lib/ui/delivery_view_model.dart` — complete source and applicable full PR diff.
- `app/test/bootstrap/runtime_configuration_test.dart` — complete source and applicable full PR diff.
- `app/test/data/delivery_migration_test.dart` — complete source and applicable full PR diff.
- `app/test/data/delivery_result_snapshot_test.dart` — complete source and applicable full PR diff.
- `app/test/data/delivery_settings_test.dart` — complete source and applicable full PR diff.
- `app/test/data/legacy_repository_fixture.dart` — complete source and applicable full PR diff.
- `app/test/data/repository_fixture.dart` — complete source and applicable full PR diff.
- `app/test/data/sqlite_delivery_repository_test.dart` — complete source and applicable full PR diff.
- `app/test/query/query_repository_fixture.dart` — complete source and applicable full PR diff.
- `app/test/query/workbench_query_test.dart` — complete source and applicable full PR diff.
- `app/test/query/workbench_view_model_test.dart` — complete source and applicable full PR diff.
- `app/test/reliability/confirmation_mode_combinations_test.dart` — complete source and applicable full PR diff.
- `app/test/reliability/formal_workbench_test.dart` — complete source and applicable full PR diff.
- `app/test/reliability/workbench_fault_combinations_test.dart` — complete source and applicable full PR diff.
- `app/test/support/delivery_risk_fixture.dart` — complete source and applicable full PR diff.
- `app/test/support/formal_workbench_fixture.dart` — complete source and applicable full PR diff.
- `app/test/sync/demo_transport_test.dart` — complete source and applicable full PR diff.
- `app/test/sync/sync_coordinator_test.dart` — complete source and applicable full PR diff.
- `app/test/sync/sync_wakeup_timeout_test.dart` — complete source and applicable full PR diff.
- `app/test/ui/delivery_view_model_lifecycle_test.dart` — complete source and applicable full PR diff.
- `app/test/ui/fake_delivery_repository.dart` — complete source and applicable full PR diff.
- `app/test/widget_test.dart` — focused lines 420-620: bootstrap retry coalescing and saved/refresh failure.

## Limits

- Existing tests were read, not rerun. This review does not restate historical native or quality reports as current execution.
- Unavailable local-client, explicit Demo separation, and production no-go remain deliberate contracts; merging source into main is distinct from external publishing.
- Parent owns the remaining full PR review partitions and fresh Browse arrow delta.
