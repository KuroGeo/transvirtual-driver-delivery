# UI-01 bounded map fix

Status: development complete; awaiting root execution and another independent source review. Original request-changes review is retained unchanged.

The root ran and retained the red Harness test at `harness/runs/20261011T085040509646Z-test/attempts/000001/report.json`, candidate `79711386e2d9b3b9e7ec6e3266b2aa6883c017b53995d5c21c9b05f314278ed7`. I read this actual report: sdk/pub passed, Flutter tests exit1, wrappers reaped and app-workspace lease released. Root confirmed both actual-drag component cases fail on unreachable Sync and the formal landscape case fails marker geometry. Raw Flutter log SHA256: `c35d4e59ba02be335f4d25ab94bb027eda467fa8c8555d161d89812fdabd77ea`.

Only `app/lib/ui/delivery/map/delivery_map_workspace.dart`, `app/test/map/delivery_map_workspace_test.dart` and `app/test/map/map_fixture.dart` changed under this assignment. The toolbar keeps its original clipped Material and44px single-column targets. Its viewport is now bounded by actual map height minus top/bottom margin, with vertical user scrolling. It does not resize/rearrange tools, write camera on scroll or change any public API.

The component regressions use actual pointer drags and actual Sync/Locate/Zoom taps, require contained/hittable44px targets, assert no camera drift during tool scrolling, and preserve one-column geometry. Root owns the complementary formal landscape camera padding fix/test. I executed no SDK/test/build/device commands and cannot accept my own map increment. All counted source writes are frozen for root formatting/testing and independent review.

