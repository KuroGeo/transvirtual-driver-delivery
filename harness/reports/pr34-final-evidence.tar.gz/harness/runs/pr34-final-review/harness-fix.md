# PR34 Harness gate repair

Source frozen. Only `harness/gate.py` and `harness/tests/test_gate.py` changed. HREV-1 now requires the producer's actual typed stage completion/reap/group facts; HREV-2 now requires full verbose row count for both zero-skip Linux and the exact Darwin platform-NA case. No producer protocol, existing evidence or delivery scope was widened.

Portable regressions pass hash-valid altered reports/logs through the raw reader. A separate six-case `harness-raw-refusal/manifest.json` packet uses genuine075012 logs and stage fields: positive actualDarwin, missing/contradictory completion, zero-skip summary-only, zero-skip missing row and Darwin missing row. Original report/log hashes remain unchanged. These fixtures are derived negative-policy examples with the original historical source identity; they are not new/currentG1 or business acceptance.

AST parsing and diff whitespace checks passed. SDK, test suites, native devices and gate fixtures were not executed by the author. Independent replay and final gate acceptance belong to the data reviewer/root. Original finding reports remain unchanged.
