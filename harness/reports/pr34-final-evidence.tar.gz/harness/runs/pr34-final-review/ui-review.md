# PR34 UI/models review

Reviewed base `3e0300848fcded055abcc47448c06a165d0472d6` to HEAD `3233a2e0f99bde286fe1faa710e9f3955d1da628`, plus root's uncommitted Browse trailing arrow. This was a read-only source and behavioral-test review; I executed no Flutter SDK, build, test or device commands.

Verdict: **request changes** for one P2. No additional actionable P1/P2 defect found in the reviewed UI/models paths.

## [P2] Keep the complete vertical toolbar reachable in landscape

Location: `app/lib/ui/delivery/map/delivery_map_workspace.dart:547-551`; compact fit padding also `app/lib/ui/delivery_screen.dart:246-250` and `:266-270`.

The iOS Info.plist advertises LandscapeLeft/Right, Android allows rotation, and the app has no orientation lock. Rotating to roughly 844×390 leaves substantially less than 233px of map height after the header, SafeArea and 44px footer. The map's clipped Stack still positions an unconditional 221px tool column at top12px. Locate and Sync are therefore clipped and cannot receive user input. The same short map also subtracts fixed top170/bottom24 fit padding, consuming its entire padded fit height. Existing formal geometry and native N7 cases cover portrait; N7 explicitly requires height>=600.

Preserve 44px single-column targets while bounding the toolbar viewport to available height and allowing vertical scroll/reveal. Fit padding needs an actual short-map budget. Root should first add a formal 844×390 regression with realistic SafeArea, verify each actual tool can be reached and tapped, and check explicit Fit/selection/return/Browse behavior. An orientation restriction is possible only through an explicit support-scope decision. Source evidence is high confidence; this reviewer did not execute the regression.

## Reviewed behavior

- Immutable Stop/PendingUpdate/Ack and settings/viewports; no UI database coupling
- WorkbenchQuery search/status/waiting intersection, global queue count, Haversine ordering and immutability
- ViewModel load/submit/sync/online/viewport serialized tails, stale read guard, postcommit known-fact fallback, close lifecycle
- Root screen typed origin returns, explicit Tab camera action, passive notice/query/ack no refit, mounted Offstage list/focus exclusion, reload and map-information controls
- List default prototype rows and collapsed tools, stable scroll/context/focus, empty/error/large-text behavior
- Detail terminal read-only state, in-flight close guards, rollback and postcommit refresh distinction
- Failure validation/Other conversion, retained draft, route close/save guards, keyboard/responsive scroll, reduced-motion transition
- Map original coordinates, mixed status clusters, pointer routing, fixed reference IgnorePointer, actual user gesture/persistence, frame-aligned tile event stream, retained controller/provider and tile-only clear
- BrandIcon local licensed glyphs, Inter variable font/theme, labels/tooltips/status semantics, platform motion flags
- Root working-tree Browse arrow uses TextButton.icon with trailing arrow, retains callback/key and decorative unlabeled icon
- Independent two-touch widget tests use actual touch pointers and inspect camera delta rather than writing a camera
- Private native commands strict deserialize fixed fields; pinch emits paired framework touch events and labels physical OS limitations
- Native bridge snapshot-only observation and actual bounds/centerHit/MediaQuery; acceptance actions operate real UI, fail deadlines and retain raw before/after captures

## Evidence boundaries

- No CI/native/physical device or release certification claimed
- No latest candidate acceptance inferred from historical evidence
- Portrait prototype is an input; mobile platform currently advertises landscape support

The companion JSON lists the behavior test files examined and exact reproduction guidance. This review is merge-safety feedback and does not grant production qualification.

