# PR34 independent Harness review

Verdict: changes requested. No P1 found; two concrete P2 gate refusal gaps. Reviewed runtime/checks/gate/native/state/run source, related regression coverage, private driver/bridge/gesture sources and report/skill evidence boundaries. No SDK/test suite/device mutations.

## [P2] Require the actual stage completion receipt before accepting G1/G2

harness/gate.py:311–314

Validator.runner accepts status=passed/exit_code=0 and a positive job_pid without inspecting completion. With the genuine 075012 quality report and genuine stage log hashes, removing every completion object, or replacing it with wrapper_reaped=false, returncode=null, group_alive=true and nonempty cleanup_errors, still returns accepted. Local/production delivery must reject this unknown or contradictory cleanup state even if the outer envelope claims success. The same shared reader handles native runner evidence.

Fix: Validate typed completion.spawned=true, wrapper_pid/process_group==job_pid, wrapper_reaped=true, returncode=0, group_alive=false and cleanup_errors=[]; add hash-valid mutations to the gate tests. Existing fixture positive reports must carry honest synthetic completions.

## [P2] Do not accept a summary-only log for the current verbose G1 command

harness/gate.py:140–142

Current quality commands fix unittest discovery to -v, but declared==0 returns True without requiring verbose row count equal Ran N. Ran 161 tests in 0.1s followed by OK alone, or one retained successful row plus Ran161/OK, is accepted as a full current test run. The exact platform skip branch correctly counts rows. The existing legacy_plain_success positive test codifies this compatibility, but it creates an inconsistent current fail-closed policy and accepts missing zero-skip results. Historical legacy raw compatibility should not replace required current verbose evidence.

Fix: Require len(rows)==int(summary[1]) before both zero/one-skip acceptance; preserve strict row final outcomes; turn legacy summary-only into a refusal for current G1.

The direct read-only probes retained original log bytes and hashes; no filesystem evidence or source was rewritten. The full381730 native matrix remains historical; fcc current scope is only targetedN4/N7. Main merge is authorized after fixes and current verification; production no-go remains.
